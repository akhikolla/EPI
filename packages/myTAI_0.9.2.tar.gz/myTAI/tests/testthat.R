library(testthat)
library(myTAI)

test_check("myTAI")
