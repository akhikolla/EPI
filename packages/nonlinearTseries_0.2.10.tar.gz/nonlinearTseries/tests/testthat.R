library(testthat)
library(nonlinearTseries)

test_check("nonlinearTseries")
