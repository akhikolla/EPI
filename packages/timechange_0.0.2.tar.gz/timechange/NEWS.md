
Version 0.0.2
=============

## New Features:

 - New function `time_get()` for extraction of date-time components

## Bug Fixes:

 - [#8](https://github.com/vspinu/timechange/issues/8) Correctly handle infinite date-times

## Changes:

 - Rename global option "week_start" -> "timechange.week_start"

Version 0.0.1
=============

Initial Release
