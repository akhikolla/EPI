# interep 0.3.1 [2020-04-19]

* Reference lists have been updated.

# interep 0.3.0 [2019-10-12]

* Solve the valgrind issue.
* Update related references.

# interep 0.2.0 [2017-10-14]

* Provide c++ implementation for generalized estimating equation, which significantly increased the speed of cross-validation functions in this package.

# interep 0.1.1 [2017-05-23]






