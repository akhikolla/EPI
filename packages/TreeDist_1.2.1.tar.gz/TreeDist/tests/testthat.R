library("testthat")
library("TreeDist")

test_check("TreeDist")
