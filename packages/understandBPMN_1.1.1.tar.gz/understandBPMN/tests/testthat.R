library(testthat)
library(understandBPMN)

test_check("understandBPMN")
