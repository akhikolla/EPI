# 0.0.1 (2018-04-16)
* First version. APIs can be changed later.

# 0.0.2 (2018-06-21)
* Bug fix. (covariance matrix, random seed)