#' @useDynLib curstatCI
#' @importFrom Rcpp sourceCpp
NULL
