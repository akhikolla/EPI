#' @useDynLib oneclust, .registration = TRUE
NULL

#' @importFrom Rcpp sourceCpp
NULL
