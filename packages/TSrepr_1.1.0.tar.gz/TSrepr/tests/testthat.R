library(testthat)
library(TSrepr)

test_check("TSrepr")
