#include <Rcpp.h>
using namespace Rcpp;

List rleC(NumericVector y);
