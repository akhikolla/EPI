library(testthat)
library(dann)

test_check("dann")
