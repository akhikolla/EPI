# dann v 0.2.1 (10-08-2020)
	Ties in distance are broken by most common class.
	Updating vignettes.
	
# dann v 0.2.0 (03-14-2020)
	Moving to RcppArmadillo for performance improvements.

# dann v 0.1.0 (12-10-2019)
	Initial release.
