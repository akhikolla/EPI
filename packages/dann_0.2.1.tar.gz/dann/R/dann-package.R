## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib dann, .registration = TRUE
## usethis namespace: end
NULL
