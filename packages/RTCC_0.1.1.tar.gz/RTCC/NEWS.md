# RTCC 0.1.1

* Added a `NEWS.md` file to track changes to the package.

## Bug fixes
* Modification of a sorting step of `table3` prior to main function execution on functions `rtcc2` and `rtcc3`. 
* Removal of unused arguments on the `rtcc1` function call. 
