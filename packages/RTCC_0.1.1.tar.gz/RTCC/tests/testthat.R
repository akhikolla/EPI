library(testthat)
library(RTCC)

test_check("RTCC")
