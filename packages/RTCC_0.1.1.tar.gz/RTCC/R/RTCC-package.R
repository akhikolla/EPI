## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
