library(testthat)
library(SAR)

test_check("SAR")
