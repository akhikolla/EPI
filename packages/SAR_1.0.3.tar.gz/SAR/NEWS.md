# SAR 1.0.3

* Update maintainer email address.

# SAR 1.0.2

* Compatibility update for rlang/tibble changes.

# SAR 1.0.1

* Allow resource group/subscription methods to work without SAR package on search path.
* Fix a bug in cold item prediction.

# SAR 1.0.0

* Initial release to CRAN
