# cdcsis 2.0.3
* Bug fix
* Output conditional distance covariance/correlation vector 

# cdcsis 2.0.2
* Bug fix

# cdcsis 2.0.1
* optimize the internal bandwidth selection strategy
* C internal change

# cdcsis 2.0

* Provide statistical inference method for conditional dependence   
* Supply user-friendly and flexible feature screening interface for R users   
* More concise output of cdcov and cdcor function   
