library(testthat)
library(cdcsis)

test_check("cdcsis")
