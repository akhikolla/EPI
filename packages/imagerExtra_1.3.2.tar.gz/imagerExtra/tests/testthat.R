library(testthat)
library(imagerExtra)
test_check("imagerExtra")