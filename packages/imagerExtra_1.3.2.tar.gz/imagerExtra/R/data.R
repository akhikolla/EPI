
#' Photograph of a dog from GAHAG
#'
#' This photograph was downloaded from http://gahag.net/img/201603/03s/gahag-0062116383-1.jpg.
#' Its size was reduced by half to speed up loading and save space.
#' @format an image of class cimg
#' @source \url{http://gahag.net/img/201603/03s/gahag-0062116383-1.jpg}
"dogs"

#' Photograph of a paper
#' 
#' This photograph was filmed by Shota Ochi.
#' @format an image of class cimg
"papers"