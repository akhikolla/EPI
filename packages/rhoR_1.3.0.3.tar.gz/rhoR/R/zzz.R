# .onLoad <- function(libname, pkgname) {
#   globalVariables(c("additional_attributes"))
# }
