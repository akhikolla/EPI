library(testthat)
library(rhoR)

test_check("rhoR")
