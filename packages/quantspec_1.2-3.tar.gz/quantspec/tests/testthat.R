library(testthat)
library(quantspec)

test_check("quantspec")
