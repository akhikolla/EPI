# Load reference values
refdata <- system.file("extdata", "ref-results.rdata", package="quantspec")
load(refdata)
