library(tools)
package_native_routine_registration_skeleton("./", "./src/init.c")



