library(testthat)
library(palm)

test_check("palm")
