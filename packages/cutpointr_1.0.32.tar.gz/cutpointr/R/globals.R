utils::globalVariables(c("x.sorted", "m", "subgroup", "Sensitivity",
                         "Specificity", "value", "metric", "Precision",
                         "Recall", "optimal_cutpoint", "ymin", "ymax",
                         "m_unsmoothed"))