library(testthat)
library(cutpointr)

test_check("cutpointr")
