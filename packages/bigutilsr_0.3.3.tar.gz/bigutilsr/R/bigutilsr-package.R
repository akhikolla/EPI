#' @useDynLib bigutilsr, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom bigassertr stop2
#' @importFrom stats quantile median mad qchisq qnorm pnorm dnorm rnorm ppoints
#' @keywords internal
"_PACKAGE"
