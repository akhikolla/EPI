library(testthat)
library(TransPhylo)

test_check("TransPhylo")
