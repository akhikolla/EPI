## ----eval=FALSE----------------------------------------------------------
#  devtools::install_github('xavierdidelot/TransPhylo')

## ------------------------------------------------------------------------
library('TransPhylo')

