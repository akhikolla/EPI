# Test maptt widget
library(testthat)
source_dir("maptt", env = test_env("SMITIDvisu"))
#test_dir('maptt', package = "SMITIDvisu", load_package = "installed")
