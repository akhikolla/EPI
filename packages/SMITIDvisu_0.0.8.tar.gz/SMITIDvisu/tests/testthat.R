library(testthat)
library(SMITIDvisu)
test_check("SMITIDvisu")
