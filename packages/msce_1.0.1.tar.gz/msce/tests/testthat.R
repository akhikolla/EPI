library(testthat)

cat("Starting tests for 'msce' package ...")

test_check("msce")