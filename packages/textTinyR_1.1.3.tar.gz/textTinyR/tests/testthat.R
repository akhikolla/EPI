library(testthat)
library(textTinyR)

test_check("textTinyR")
