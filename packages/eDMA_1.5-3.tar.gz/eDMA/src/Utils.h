#ifndef UTILS_H
#define UTILS_H
int MaxFinder(arma::vec vX);
int int_pow(int base, int exp);
#endif
