library(testthat)
library(TestDesign)

test_check("TestDesign")
