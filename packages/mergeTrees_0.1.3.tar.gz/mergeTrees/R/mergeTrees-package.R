#' @useDynLib mergeTrees
#' @importFrom Rcpp sourceCpp
NULL
