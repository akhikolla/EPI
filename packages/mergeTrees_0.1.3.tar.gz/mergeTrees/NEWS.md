# Changes in 0.1.3 (07/10 2019)

  -  

# Changes in 0.1.2 (07/03 2019)

  - check the labels of the trees so that the function stop if the trees do not have the same leaves labels.

# Changes in 0.1.1 (07/02 2019)

  - Added Example in mergeTrees description (CRAN submission warning otherwise)
