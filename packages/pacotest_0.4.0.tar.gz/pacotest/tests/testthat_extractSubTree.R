
library("testthat")
library("pacotest")

test_check("pacotest", filter = "extractSubTree")
