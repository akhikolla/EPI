## pacotest
![build](https://github.com/MalteKurz/pacotest/workflows/build/badge.svg) [![CRAN\_Status\_Badge](https://www.r-pkg.org/badges/version/pacotest)](https://cran.r-project.org/package=pacotest) [![Coverage Status](https://img.shields.io/codecov/c/github/MalteKurz/pacotest/master.svg)](https://codecov.io/github/MalteKurz/pacotest?branch=master)

### You can install:
-   the latest released version from CRAN with

    ``` r
    install.packages("pacotest")
    ```

-   the latest development version from GitHub using install_github from the R-package devtools with
    ``` r
    install.packages("devtools")
    devtools::install_github(repo = "MalteKurz/pacotest")
    ```
