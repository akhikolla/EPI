# cpss 0.0.2

* Resubmitted to CRAN.
  - omitted the redundant "An R Package" from the title.
  - uncommented some code lines in examples, and wrapped them in `\donttest`.

# cpss 0.0.1

* Submitted to CRAN.
