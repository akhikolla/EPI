
<!-- README.md is generated from README.Rmd. Please edit that file -->

# cpss

<!-- badges: start -->

<!-- badges: end -->

An R Package for Change-Point Detection by Sample-Splitting Methods.
