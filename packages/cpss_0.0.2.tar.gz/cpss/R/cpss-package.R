## usethis namespace: start
#' @useDynLib cpss, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
