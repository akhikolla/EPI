library(testthat)
library(prospectr)
library(resemble)

test_check("resemble")
