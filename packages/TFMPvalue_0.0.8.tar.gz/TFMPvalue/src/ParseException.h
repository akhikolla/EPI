/*
 *  ParseException.h
 *  pvalue
 *
 *  Created by Jean-Stéphane Varré on 02/07/07.
 *  Copyright 2007 LIFL-USTL-INRIA. All rights reserved.
 *
 */

#ifndef __PARSEEXCEPTION__
#define __PARSEEXCEPTION__

#include <iostream>

using namespace std;

class ParseException { };

#endif
