# ced 1.0.1

- Add "GNU make" to DESCRIPTION.

# ced 1.0.0

- Inital release.
