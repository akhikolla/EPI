#pragma once

#include <compact_enc_det/compact_enc_det.h>
using namespace CompactEncDet;
