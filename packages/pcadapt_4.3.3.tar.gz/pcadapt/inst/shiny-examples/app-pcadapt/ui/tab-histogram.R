tabPanel(
  strong("p-values histogram"), 
  plotly::plotlyOutput("histPlot"),
  value = 4
)