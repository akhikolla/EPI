tabPanel(
  strong("R command"), 
  verbatimTextOutput("rcommand"),
  value = 6
)