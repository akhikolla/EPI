tabPanel(
  strong("Screeplot"), 
  plotlyOutput("screePlot"),
  value = 1
)