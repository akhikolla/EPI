.onLoad <-function (lib, pkg) {
  library.dynam("iBST", pkg, lib)
}