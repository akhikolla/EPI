library(testthat)
library(dils)

test_package("dils")
