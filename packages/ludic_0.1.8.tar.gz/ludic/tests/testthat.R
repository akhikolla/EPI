library(testthat)
library(ludic)

test_check("ludic")
