# News about the `ludic` R package


### Main changes in Version 0.1.8 (2019-12-04) --- *this is only a minor release*:

* better args checks for R 4.0.0

### Main changes in Version 0.1.7 (2019-08-20):

* *test_combine()* function performs probabilistic association testing  


### Main changes in Version 0.1.6 (2017-01-28):

* *RA* data added  


### Main changes in Version 0.1.5 (2016-12-29) --- *this is only a minor release*:

* CITATION info added
