<!-- badges: start -->
[![Travis build status](https://travis-ci.org/Blunde1/dgumbel.svg?branch=master)](https://travis-ci.org/Blunde1/dgumbel)
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
[![GitHub license](https://img.shields.io/badge/license-GPL%20(%3E%3D%202)-blue)](https://www.gnu.org/licenses/gpl-3.0.html)
---------

# dgumbel
The Gumbel density, distribution, quantile and random generating functions and corresponding gradient functions.
