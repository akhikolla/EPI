library(strat)
context("Ranking Strata")

