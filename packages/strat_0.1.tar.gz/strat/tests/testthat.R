library(testthat)
library(strat)

test_check("strat")
