## ----include=FALSE------------------------------------------------------------
require(knitr)
opts_chunk$set(warning = FALSE, message = FALSE, error = FALSE, dev='svg')

