.onUnload <- function (libpath) {
  library.dynam.unload("rivr", libpath)
}
