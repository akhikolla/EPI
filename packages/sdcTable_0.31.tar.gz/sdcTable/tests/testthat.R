library(testthat)
test_check("sdcTable")