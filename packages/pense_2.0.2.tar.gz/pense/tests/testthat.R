library(testthat)
library(pense)

test_check("pense")
