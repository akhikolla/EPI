#' @useDynLib pense, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
