//
//  rcpp_integration.hpp
//  pense
//
//  Created by David Kepplinger on 2019-01-30.
//  Copyright © 2019 David Kepplinger. All rights reserved.
//

#ifndef RCPP_INTEGRATION_HPP_
#define RCPP_INTEGRATION_HPP_

#include "rcpp_utils_forward.hpp"

#include "nsoptim.hpp"

#include "rcpp_utils.hpp"
#include "rcpp_parse_config.hpp"


#endif  // RCPP_INTEGRATION_HPP_
