library(testthat)
library(iprior)

test_check("iprior")
