library(testthat)
#library(microsamplingDesign)

#source("generateTestData.R")

#test_check("microsamplingDesign")

testthat::test_check("microsamplingDesign")




