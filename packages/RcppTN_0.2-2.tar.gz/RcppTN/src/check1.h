# ifndef CHECK1_H
# define CHECK1_H
 
bool check1(const double mean,
	    const double sd,
	    const double low,
	    const double high
    ) ;

# endif
