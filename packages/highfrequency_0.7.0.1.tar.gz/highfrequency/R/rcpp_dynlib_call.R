#' @useDynLib highfrequency
#' @importFrom Rcpp sourceCpp
NULL