library(testthat)
library(highfrequency)

test_check("highfrequency")
