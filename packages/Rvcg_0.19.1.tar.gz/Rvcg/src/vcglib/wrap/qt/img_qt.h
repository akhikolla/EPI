#ifndef IMG_QT_INCLUDES_H_
#define IMG_QT_INCLUDES_H_

// includes all img and all qt wrap  headers

#include "img/img.h"

#include "wrap/qt/img_qt_convert.h"
#include "wrap/qt/img_qt_io.h"

#endif /*IMG_QT_INCLUDES_H_*/
