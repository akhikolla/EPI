
#include "residual.h"


Residual::Residual(double sum_,
                   IndexT sCount_) :
  sum(sum_),
  sCount(sCount_) {
}


