##' Photograph of sailing boats from Kodak set
##'
##' This photograph was downloaded from http://r0k.us/graphics/kodak/kodim09.html. Its size was reduced by half to speed up loading and save space.
##' @format an image of class cimg
##' @source \url{ http://r0k.us/graphics/kodak/kodim09.html }
"boats"
