library(testthat)
library(bigrquery)

test_check("bigrquery")
