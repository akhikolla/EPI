
#ifndef ___USER_INTERRUPT_H___
#define ___USER_INTERRUPT_H___


#include <Rcpp.h>

bool check_user_interrupt();


#endif
