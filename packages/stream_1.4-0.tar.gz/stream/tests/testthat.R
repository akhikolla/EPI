library("testthat")

library("stream")
test_check("stream")

