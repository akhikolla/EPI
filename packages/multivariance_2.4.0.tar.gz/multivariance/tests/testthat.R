library(testthat)
library(multivariance)

test_check("multivariance")
