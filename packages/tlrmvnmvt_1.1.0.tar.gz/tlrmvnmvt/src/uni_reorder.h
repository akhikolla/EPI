#ifndef UNIREORDER_H
#define UNIREORDER_H
int uni_reorder(int n, double *B, int ldB, double *a, double *b, double &p, double
        *y, int *oldIdx, double *workM, int lworkM);
#endif
