library(testthat)
library(bmotif)

test_check("bmotif")
