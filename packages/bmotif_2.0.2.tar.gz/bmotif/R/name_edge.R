name_edge <- function(v1, v2) {
  s <- paste(v1, " -- ", v2, sep = "")
  s
}
