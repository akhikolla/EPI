multtensor <- function(A, B){ # Cikl = Aij * Bjkl
  tensor::tensor(A,B,2,1)
}
