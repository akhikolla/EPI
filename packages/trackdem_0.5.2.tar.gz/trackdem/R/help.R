#'trackdem - Particle Tracking and Demography
#'
#'@author Marjolein Bruijning, Caspar A. Hallmann, Marco D. Visser, Eelke Jongejans
#'@docType package
#'@name trackdem
#'@importFrom Rcpp evalCpp
#'@useDynLib trackdem
NULL
