library(testthat)
library(inplace)

test_check("inplace")
