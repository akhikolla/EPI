
Contains pictures and scripts used in the README.md file under home directory.
