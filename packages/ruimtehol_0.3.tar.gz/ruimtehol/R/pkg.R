#' @importFrom Rcpp evalCpp
#' @importFrom utils read.delim 
#' @importFrom graphics legend plot points hist
#' @importFrom stats ave quantile
#' @useDynLib ruimtehol
NULL


