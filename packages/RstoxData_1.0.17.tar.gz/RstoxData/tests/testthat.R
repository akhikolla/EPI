library(testthat)
library(RstoxData)

test_check("RstoxData")
