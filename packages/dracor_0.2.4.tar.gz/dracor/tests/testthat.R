library(testthat)
library(dracor)

test_check("dracor")
