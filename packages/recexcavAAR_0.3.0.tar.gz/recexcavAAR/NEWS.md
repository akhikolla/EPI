recexcavAAR 0.3.0
----------------------------------------------------------------

* added coordinate transformation function and related vignette

* improved vignettes

* added some basic 3D drawing functions

recexcavAAR 0.2.2
----------------------------------------------------------------

* bugfixes as a reaction to CRAN checks

* replaced plotly with rgl in the vignettes

recexcavAAR 0.2.1
----------------------------------------------------------------

* preparations for CRAN release

recexcavAAR 0.2.0
----------------------------------------------------------------

* creation of some functions for the analysis of Kakcus-Turjan - see vignette

* reorganisation of previous functions (renaming, translation into Rcpp)

recexcavAAR 0.1.0
----------------------------------------------------------------

* creation of some functions for the analysis of Ifri el Baroud - see vignette