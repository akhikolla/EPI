library(testthat)
library(recexcavAAR)

test_check("recexcavAAR")
