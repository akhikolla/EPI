utils::globalVariables(c("`%mypar%`", "cv_mean", "cv_sd", "lambda.min", "lambda.1se", 
                         "lambda.opt", "wh_min", "sd", "lambda", "lambda1", "lambda2",
                         "nloglike", "y_expected", "y_mat", "y_names", "y_sum", "martingale",
                         "uid", "gid"))
