# mrfDepth
[![CRAN_Status_Badge](https://www.r-pkg.org/badges/version/mrfDepth)](https://cran.r-project.org/package=mrfDepth)

The latest development version of *mrfDepth* may be installed from GitHub using

```
install.packages("devtools")

devtools::install_github("PSegaert/mrfDepth")
```
When installing the development version from GitHub on Windows, make sure that [Rtools](https://cran.r-project.org/bin/windows/Rtools/) is installed first.
