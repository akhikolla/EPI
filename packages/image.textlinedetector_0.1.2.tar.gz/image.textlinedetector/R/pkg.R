
#' @importFrom Rcpp evalCpp
#' @importFrom magick image_data image_info image_read
#' @useDynLib image.textlinedetector
NULL
