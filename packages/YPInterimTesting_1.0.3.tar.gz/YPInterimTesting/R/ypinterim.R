ypinterim <- function(...) UseMethod("ypinterim")
