library(testthat)
library(samc)

test_check("samc")
