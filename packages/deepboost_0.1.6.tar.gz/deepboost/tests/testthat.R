library(testthat)
library(deepboost)

test_check("deepboost")
