library(testthat)
library(genio)

test_check("genio")
