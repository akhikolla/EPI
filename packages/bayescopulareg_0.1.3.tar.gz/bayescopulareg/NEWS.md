# bayescopulareg 0.1.3

* Fixed a bug that broke the chain for sampling


# bayescopulareg 0.1.2

* Fixed a bug that broke the chain for sampling


# bayescopulareg 0.1.2

* Fixed a valgrind bug