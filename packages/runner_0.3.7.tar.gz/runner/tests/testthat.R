library(testthat)
library(runner)

test_check("runner")
