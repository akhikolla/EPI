#' @useDynLib runner
#' @importFrom Rcpp sourceCpp
NULL
