library(testthat)
library(neatRanges)

test_check("neatRanges")
