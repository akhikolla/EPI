library(testthat)
library(discretecdAlgorithm)

test_check("discretecdAlgorithm")
