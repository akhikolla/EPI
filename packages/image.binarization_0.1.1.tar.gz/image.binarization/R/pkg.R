#' @importFrom Rcpp evalCpp
#' @importFrom magick image_info image_read image_data
#' @importFrom grDevices as.raster
#' @useDynLib image.binarization
NULL


