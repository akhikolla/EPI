## CHANGES IN udpipe VERSION 0.1.1

- Fix compilation issue on Mac version 10.13 about the use of get in Parameters.hpp

## CHANGES IN udpipe VERSION 0.1

- Initial release based on Doxa commit 610841de2130cc10f461c1d9d09eee346cb0f599
