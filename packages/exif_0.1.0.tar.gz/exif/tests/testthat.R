library(testthat)
library(exif)

test_check("exif")
