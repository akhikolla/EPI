library(testthat)
library(multinets)

test_check("multinets")
