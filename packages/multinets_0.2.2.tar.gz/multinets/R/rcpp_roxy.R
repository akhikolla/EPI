#' @useDynLib multinets
#' @importFrom Rcpp sourceCpp
NULL
