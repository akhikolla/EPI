#' Molecular Function terms
#' A dataset of molecular function terms.
#' @name MF_terms
"MF_terms"