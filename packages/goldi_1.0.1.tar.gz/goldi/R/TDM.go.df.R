#' Term document matrix of Gene Ontology Molecular Function terms
#'
#' This is a provided data set for speeding up computations and also for use in unit testing. It has been compiled through the scripts available in \code{raw-data}
#'
"TDM.go.df"