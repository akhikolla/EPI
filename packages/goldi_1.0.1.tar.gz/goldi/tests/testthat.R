library(testthat)
library(goldi)

test_check("goldi")
