# `goldi` v1.0.1

* This is a minor release intended to fix an issue with unstated `-llapack` dependency which caused issues on solaris platforms. Please see `Makevars` and `Makevars.win` for changes.
