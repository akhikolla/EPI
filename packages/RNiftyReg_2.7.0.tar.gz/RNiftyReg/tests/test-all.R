library(testthat)
test_check("RNiftyReg")
