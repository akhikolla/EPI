# filling 0.2.2

* Fixed graphic parameter setting for CRAN.

# filling 0.2.1

* Added a `NEWS.md` file to track changes to the package.
* Modification according to changes from `CVXR` package.
