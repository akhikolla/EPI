/*
 * Author: Andreas Alfons
 *         KU Leuven
 */

#ifndef _sparseLTSEigen_SPARSELTSEIGEN_H
#define _sparseLTSEigen_SPARSELTSEIGEN_H

#define EIGEN_MATRIX_PLUGIN "MatrixAddons.h"	// extend class MatrixBase with additional member functions
#include <RcppEigen.h>

#endif
