#ifndef STRICT_R_HEADERS
#define STRICT_R_HEADERS
#endif

#include <RcppArmadillo.h>
