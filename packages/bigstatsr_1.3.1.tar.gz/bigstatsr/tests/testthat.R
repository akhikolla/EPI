library(testthat)
library(bigstatsr)

test_check("bigstatsr")
