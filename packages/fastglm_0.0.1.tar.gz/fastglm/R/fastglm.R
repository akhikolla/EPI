#' @importFrom Rcpp evalCpp
#' @import stats
#' @useDynLib fastglm, .registration = TRUE
NULL