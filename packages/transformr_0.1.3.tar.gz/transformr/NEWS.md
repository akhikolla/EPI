# transformr 0.1.3

* Added additional guards in `add_points()`

# transformr 0.1.2

* Add guards to avoid errors when malformed coordinates are passed to sf
