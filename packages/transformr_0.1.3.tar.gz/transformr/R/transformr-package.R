#' @useDynLib transformr
#' @importFrom Rcpp sourceCpp
#'
'_PACKAGE'
