library(testthat)
library(gsisdecoder)

test_check("gsisdecoder")
