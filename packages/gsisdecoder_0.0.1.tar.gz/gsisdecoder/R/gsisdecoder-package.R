## usethis namespace: start
#' @useDynLib gsisdecoder, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
