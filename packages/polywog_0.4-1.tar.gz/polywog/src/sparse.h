#ifndef POLYWOG_SPARSE_H
#define POLYWOG_SPARSE_H

#include <Rcpp.h>

Rcpp::NumericVector columnFromSparse(Rcpp::S4 X, int j);

#endif  // POLYWOG_SPARSE_H
