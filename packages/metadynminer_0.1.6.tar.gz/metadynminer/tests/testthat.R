library(testthat)
library(metadynminer)

test_check("metadynminer")
