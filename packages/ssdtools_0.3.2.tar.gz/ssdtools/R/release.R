release_questions <- function() {
  c(
    "Have you confirmed Apache 2.0 license at the top of all code files?",
    "Have you confirmed Creative Commons license for all non-code files?"
  )
}
