# clere 1.2.0

## Minor improvements and fixes

* Manually use roxygen2 to generate documentation
* Now properly imports packages
* Fix CRAN checks notes, warnings and errors from R-devel
* Add `README`
* Add `CITATION`
* Remove S4 methods `[` and `[<-`

