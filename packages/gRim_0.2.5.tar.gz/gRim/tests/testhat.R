library(testthat)

if (T){
    library(gRim)
    test_check("gRim")
}
