#' @title Internal functions for the gRim package
#' 
#' @name internal
#' 
#' @aliases %>% 
#' 
NULL
