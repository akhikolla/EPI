# gRim
R package for gRaphical independence models
