## minimal R interface to redis using the hiredis library

## ensure module gets loaded
loadModule("Redis", TRUE)

