
## 0.1.1

- Resolved the warnings issues found in [check results](https://www.r-project.org/nosvn/R.check/r-release-windows-ix86+x86_64/mixR-00check.html).


## 0.1.0

- First version
