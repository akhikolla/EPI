library("testthat")
library("rpart")
library("fastAdaboost")

test_check("fastAdaboost")
