
# v0.0.1, CRAN submission

- Provide interface to Eigen solvers
  - Direct: LU, QR, Cholesky
  - Iterative: Conjugate Gradient, BiCGSTAB, Least Squares CG
