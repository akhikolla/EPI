# physiology

## Version 1.1

* ETT lumen volume calculation
* Added body surface area variants, thanks to Bill Denney
* Added eGFR calculations, thanks to Bill Denney

## Version 1.0

* Everest summit physiology vignette
* Simplified date and age handling
* better test coverage
* some physics and atomspheric pressure calculations
* Added a `NEWS.md` file to track changes to the package.
