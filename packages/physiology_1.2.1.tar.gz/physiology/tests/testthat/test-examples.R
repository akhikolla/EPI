context("examples")

test_examples()
