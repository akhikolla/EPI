library(lvec)
library(testthat)

test_check("lvec")

