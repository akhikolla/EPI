#ifndef tempfile_impl_h
#define tempfile_impl_h

#include <string>

std::string tempfile_impl();

#endif
