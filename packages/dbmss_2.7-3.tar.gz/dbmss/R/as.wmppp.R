as.wmppp <-
function (X, ...)
{
  UseMethod("as.wmppp")
}
