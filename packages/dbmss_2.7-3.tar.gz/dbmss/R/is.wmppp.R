is.wmppp <-
function (X) {
  inherits(X, "wmppp")
}
