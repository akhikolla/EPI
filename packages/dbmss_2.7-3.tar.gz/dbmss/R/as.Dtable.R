as.Dtable <-
function (X, ...)
{
  UseMethod("as.Dtable")
}
