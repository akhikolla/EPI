library(testthat)
library(dbmss)

testthat::test_check("dbmss")
