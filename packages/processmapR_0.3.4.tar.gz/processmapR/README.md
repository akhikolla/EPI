# processmapR
R package for creating process maps. Part of the bupaR eco-system for business process analysis.

[Read more](https://www.bupar.net)
