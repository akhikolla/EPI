library(testthat)
library(smerc)
test_check("smerc")
