#' smerc
#'
#' *S*tatistical *ME*thods for *R*egional *C*ounts
#'
## usethis namespace: start
#' @useDynLib smerc, .registration = TRUE
## usethis namespace: end
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
#' @name smerc
#' @docType package
NULL

