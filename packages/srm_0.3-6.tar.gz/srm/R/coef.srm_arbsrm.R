## File Name: coef.srm_arbsrm.R
## File Version: 0.01


coef.srm_arbsrm <- function(object, ...)
{
    return(object$coef)
}
