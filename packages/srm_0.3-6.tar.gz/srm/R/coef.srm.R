## File Name: coef.srm.R
## File Version: 0.01


coef.srm <- function(object, ...)
{
    return(object$coef)
}
