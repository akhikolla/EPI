## File Name: vcov.srm.R
## File Version: 0.01


vcov.srm <- function(object, ...)
{
    return(object$vcov)
}
