## File Name: SRM_CLOSE_SINK.R
## File Version: 0.01

SRM_CLOSE_SINK <- function(file=NULL)
{
    if (!is.null(file)){ sink() }
}
