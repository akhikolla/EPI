library(testthat)
library(easyVerification)

test_check("easyVerification")
