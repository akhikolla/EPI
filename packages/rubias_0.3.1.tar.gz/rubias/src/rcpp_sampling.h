#include <Rcpp.h>
using namespace Rcpp;

IntegerVector samp_from_mat(NumericMatrix M) ;
