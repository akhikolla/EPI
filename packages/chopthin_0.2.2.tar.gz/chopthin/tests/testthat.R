library(testthat)
library(chopthin)
test_check("chopthin")
