library(testthat)
library(rust)

test_check("rust")
