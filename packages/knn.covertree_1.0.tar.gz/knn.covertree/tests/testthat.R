library(testthat)
library(knn.covertree)

test_check('knn.covertree')
