#' @title The Genie Package
#'
#' @description
#' See \code{\link{hclust2}()} for details.
#'
#'
#' @name genie-package
#' @rdname genie-package
#' @aliases genie
#' @docType package
#' @author Marek Gagolewski, Maciej Bartoszuk, Anna Cena
#'
#' @useDynLib genie, .registration=TRUE
#' @importFrom Rcpp evalCpp
invisible(NULL)
