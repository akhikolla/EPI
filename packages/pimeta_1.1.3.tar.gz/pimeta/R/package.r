#' Prediction Intervals for Random-Effects Meta-Analysis
#'
#' @author
#' Kengo Nagashima, Hisashi Noma, and Toshi A. Furukawa
#' @name pimeta-package
#' @rdname pimeta-package
#' @aliases pimeta-package
#' @docType package
#' @keywords package
#' @useDynLib pimeta, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
