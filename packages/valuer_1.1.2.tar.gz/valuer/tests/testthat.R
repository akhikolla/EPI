library(testthat)
library(valuer)

test_check("valuer")
