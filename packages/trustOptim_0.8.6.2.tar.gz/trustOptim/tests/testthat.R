library(testthat)
library(trustOptim)

test_check("trustOptim")
