#' @name binary-data
#' @title Sample simulated data for binary choice model in vignette
#' @description Simulated data.  See vignette.  Generated from data-raw/binary.R
#' @docType data
NULL
