library(testthat)
library(bnclassify)

test_check("bnclassify")