context("predict")

test_that("Maximum a posteriori", {   
  # gRain implementation change
  # skip_if_not_installed('gRain')
  # h <- nbvote()
  # pred <- predict(h, voting, prob = TRUE)
  # p <- map(pred)
  # accu <- sum(p == voting$Class) / nrow(voting)
  # expect_equal(accu, 0.9034483, tolerance = 1e-7) 
  # gRain implementation change
})