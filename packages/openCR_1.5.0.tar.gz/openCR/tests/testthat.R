library(testthat)

test_check("openCR")