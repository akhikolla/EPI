library(testthat)
library(treeducken)
test_check("treeducken")
