#include "Math.h"


void swap(int &x,int &y){int k=x;x=y;y=k;}
