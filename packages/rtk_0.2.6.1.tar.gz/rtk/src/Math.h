#pragma once
#include <stdio.h>
//#include <tchar.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
//#include <string.h>
#include <string>
#include <map>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <random>


const bool verbose=1;


int getRand(int until);

void swap(int &x,int &y);
