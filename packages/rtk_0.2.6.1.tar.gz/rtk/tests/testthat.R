library(testthat)
library(rtk)

test_check("rtk")
