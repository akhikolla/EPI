#' @importFrom Rcpp sourceCpp
#' @useDynLib matricks, .registration = TRUE
NULL
