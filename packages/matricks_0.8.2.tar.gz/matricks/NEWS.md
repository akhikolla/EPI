# matricks 0.8.1
* minor chnages for CRAN submission

# matricks 0.8.0
* `neighbour_idx()` restored
* `runifm()` added
* refactorization

# matricks 0.7.0
* `is_idx_possible()` added
* `seq_matrix()` added
* `matrix_idx()` added

# matricks 0.6.0
* `with_same_dims()` added
* `plot_matrix()` and `plot.matrix()` added
* `runifm()` added
* `rboolm()` added

# matricks 0.5.0
* `at()` and `at<-` functions added
* refactoring and bugfixes

# matricks 0.4.0
* `antidiag<-` function added
* `neighbour_idx()` function added

# matricks 0.3.0  
* `NEWS.md` file added to track changes to the package.
* `antidiag()` function bugfix
* `row_bind()` function added
