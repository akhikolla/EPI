library(testthat)
library(matricks)

test_check("matricks")
