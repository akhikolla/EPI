library(testthat)
library(mbbefd)

test_check("mbbefd")
