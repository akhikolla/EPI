library(testthat)
library(datafsm)

test_check("datafsm")
