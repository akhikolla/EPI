library(testthat)
library(miceFast)
library(data.table)
library(dplyr)
library(magrittr)

test_check("miceFast")
