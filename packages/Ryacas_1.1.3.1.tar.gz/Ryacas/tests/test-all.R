library(testthat)
test_check('Ryacas')
