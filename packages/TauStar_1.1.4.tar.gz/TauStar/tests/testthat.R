library(testthat)
library(TauStar)

test_check("TauStar")
