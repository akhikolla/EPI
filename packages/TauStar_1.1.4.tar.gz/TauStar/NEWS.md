# TauStar 1.1.4

## Bugfix
* Fixed some failing tests caused by a recent change in the way R's sample function is implemented.