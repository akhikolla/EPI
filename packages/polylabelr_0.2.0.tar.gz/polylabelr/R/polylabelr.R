#' @importFrom Rcpp evalCpp
#' @useDynLib polylabelr, .registration = TRUE
#' @keywords internal
"_PACKAGE"
