# polylabelr 0.2.0

## New features

* `poi()` supports simple features objects from the `sf` package (#2, thanks @kent37).

## Bug fixes

* The `CITATION` file now correctly displays the year of the package.

# polylabelr 0.1.0

* First release.
