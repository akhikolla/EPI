library(testthat)
library(polylabelr)

test_check("polylabelr")
