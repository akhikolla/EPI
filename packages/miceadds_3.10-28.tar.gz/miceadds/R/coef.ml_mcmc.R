## File Name: coef.ml_mcmc.R
## File Version: 0.02

coef.ml_mcmc <- function(object, ...)
{
    return(object$coef)
}
