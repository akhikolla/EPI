## File Name: vcov.lmer_vcov.R
## File Version: 0.01

vcov.lmer_vcov <- function(object, ...)
{
    return(object$vcov)
}
