## File Name: coef.lmer_vcov.R
## File Version: 0.01

coef.lmer_vcov <- function(object, ...)
{
    return(object$coef)
}
