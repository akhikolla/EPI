## File Name: vcov.ml_mcmc.R
## File Version: 0.02

vcov.ml_mcmc <- function(object, ...)
{
    return(object$vcov)
}
