## File Name: mice.impute.tricube.pmm2.R
## File Version: 0.273

mice.impute.tricube.pmm2 <- function(...){
    .Defunct(new="mice.impute.tricube.pmm", package="miceadds")
}
