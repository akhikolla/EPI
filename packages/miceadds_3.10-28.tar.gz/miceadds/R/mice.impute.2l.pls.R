## File Name: mice.impute.2l.pls.R
## File Version: 0.20
mice.impute.2l.pls <- function(...){
    .Defunct(new="mice.impute.pls", package="miceadds")
}
