library(testthat)
library(futureheatwaves)

test_check("futureheatwaves")
