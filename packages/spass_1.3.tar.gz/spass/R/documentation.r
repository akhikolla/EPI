#' @useDynLib spass
#' @importFrom Rcpp evalCpp
NULL
