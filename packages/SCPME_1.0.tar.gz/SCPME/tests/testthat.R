library(testthat)
library(SCPME)

test_check("SCPME")
