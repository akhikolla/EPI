library(testthat)
library(humanleague)
test_check("humanleague")
