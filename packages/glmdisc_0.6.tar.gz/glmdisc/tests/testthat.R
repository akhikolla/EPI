library(testthat)
library(glmdisc)

test_check("glmdisc")
