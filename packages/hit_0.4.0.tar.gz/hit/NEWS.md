## hit v0.4.0 (Release date: 2016-11-16)

Changes: 

* ``hit``: second path for lambda estimation, with a new lambda for each sample split.


## hit v0.3.1 (Release date: 2016-09-15)

Changes: 

* ``reorder``: a more general reorder function for hierarchy



## hit v0.3.0 (Release date: 2016-08-29)

Changes:

* ``hit``: remove the alpha optimization and allow only one alpha value

* ``hit``: allow the response variable (y) to be Poisson distributed

* ``summary.hit``: bug fix  



## hit v0.2-2 (Release date: 2016-04-26)

Changes:

* ``hit``: bug fixes in summary and some other small fixes



## hit v0.2-1 (Release date: 2016-01-11)

Changes:

* ``hit``: sticks to cross-validation as selection method

* ``hit``: arguments have changed



## hit v0.2-0 (Release date: 2015-12-04)

Changes:

* ``fast.anova``: a new ``fast.glmanova`` method for GLM's

* ``hit``: now is able to deal with binomial responses

* ``hit``: a new selection method for the active set
