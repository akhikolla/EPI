library(testthat)
library(hit)

test_check("hit")
