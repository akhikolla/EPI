

seqN_by <- function(x) {
  do_cumsum_reset_sorted_int(x)
}

