library(testthat)
library(hutilscpp)

test_check("hutilscpp")
