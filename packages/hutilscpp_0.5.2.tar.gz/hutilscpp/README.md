 [![Coverage status](https://codecov.io/gh/HughParsonage/hutilscpp/branch/master/graph/badge.svg)](https://codecov.io/github/HughParsonage/hutilscpp?branch=master)
 [![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/HughParsonage/hutilscpp?branch=master&svg=true)](https://ci.appveyor.com/project/HughParsonage/hutilscpp)

# hutilscpp

Under development

## Highlights

This package is designed to accompany data in the order of 100M rows. For the 
sake of example, we will be using the `gdata` (1979-2013) file.

```
http://data.gdeltproject.org/events/index.html
```


