#library(lavaSearch2)
suppressPackageStartupMessages(library("testthat"))
test_check("lavaSearch2")
