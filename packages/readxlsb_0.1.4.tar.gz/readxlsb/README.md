# readxlsb
Import 'Excel' binary (.xlsb) workbooks into R

```
library(readxlsb)
read_xlsb(path = system.file("extdata", "TestBook.xlsb", package="readxlsb"), range="PORTFOLIO")
```
