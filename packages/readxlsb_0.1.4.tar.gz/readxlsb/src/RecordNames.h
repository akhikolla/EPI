#include <string>

namespace readxlsb {

std::string TokenLabel(uint32_t record_id);

}
