library(testthat)
library(sparsio)
test_check("sparsio")
