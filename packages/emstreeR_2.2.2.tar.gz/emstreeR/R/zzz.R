.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Please, do not forget to appropriately cite 'emstreeR' when using it in an academic research. See citation(package = 'emstreeR').")
}
