#include <Rcpp.h>
using namespace Rcpp;

float convert_lat(std::string str);
float convert_lon(std::string str);
bool is_negative(std::string s);
