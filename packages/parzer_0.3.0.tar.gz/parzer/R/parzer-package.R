#' @title parzer
#' @description parse geographic coordinates
#'
#' @useDynLib parzer
#' @importFrom Rcpp sourceCpp
#' @name parzer-package
#' @aliases parzer
#' @docType package
#' @keywords package
#' @author Scott Chamberlain
NULL
