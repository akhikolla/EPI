library(testthat)
library(rstanemax)

# options(lifecycle_verbosity = "error")
test_check("rstanemax")
