#include <RcppArmadillo.h>
using namespace Rcpp;
#include "modelprior.h"
#include "likelyhood.h"
#include "zigzag_logit.h"
#include "zigzag_rr.h"
#include "bps_logit.h"
#include "bps_rr.h"
