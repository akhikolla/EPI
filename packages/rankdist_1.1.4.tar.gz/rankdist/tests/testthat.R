library(testthat)
library(rankdist)

test_check("rankdist")
