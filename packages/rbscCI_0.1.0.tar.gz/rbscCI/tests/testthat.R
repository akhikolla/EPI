library(testthat)
library(rbscCI)

test_check("rbscCI")
