library(testthat)
library(SuperpixelImageSegmentation)

test_check("SuperpixelImageSegmentation")
