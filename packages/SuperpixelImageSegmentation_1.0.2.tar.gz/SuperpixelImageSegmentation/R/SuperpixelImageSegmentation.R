#' @useDynLib SuperpixelImageSegmentation, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
