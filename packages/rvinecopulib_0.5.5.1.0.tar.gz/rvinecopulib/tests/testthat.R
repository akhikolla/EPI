library(testthat)
library(rvinecopulib)

test_check("rvinecopulib")
