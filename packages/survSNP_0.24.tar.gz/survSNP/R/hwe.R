hwe <-
function(raf)
  {
    c((1-raf)^2,2*raf*(1-raf),raf^2)    
  }

