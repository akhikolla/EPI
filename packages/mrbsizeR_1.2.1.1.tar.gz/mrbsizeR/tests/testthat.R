library(testthat)
library(mrbsizeR)

test_check("mrbsizeR")
