# bravo
 An R package that performs Bayesian iterated screening and/or variable selection for ultra-high dimensional Gaussian linear regression models
