# coda.base

[https://mcomas.github.io/coda.base/](https://mcomas.github.io/coda.base/)

## Installation

``` r
# Install release version from CRAN
install.packages("coda.base")
```

```r
# Install development version from GitHub
remotes::install_github("mcomas/coda.base")
```
