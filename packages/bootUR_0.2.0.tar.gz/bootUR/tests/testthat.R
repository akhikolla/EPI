library(testthat)
library(bootUR)

test_check("bootUR")
