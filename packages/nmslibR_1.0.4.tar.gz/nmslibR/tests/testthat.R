library(testthat)
library(nmslibR)

test_check("nmslibR")
