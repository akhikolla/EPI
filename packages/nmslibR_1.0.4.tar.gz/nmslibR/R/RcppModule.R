#' @useDynLib nmslibR, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
