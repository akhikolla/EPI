#' HAL9000 Quotes from "2001: A Space Odyssey"
#'
#' Curated selection of quotes from the HAL9000 computer, from the critically
#' acclaimed epic science-fiction film "2001: A Space Odyssey" (1968).
#'
#' @format A vector of quotes.
#'
"hal_quotes"
