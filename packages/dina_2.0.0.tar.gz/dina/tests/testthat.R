library(testthat)
library(dina)

test_check("dina")
