#' @useDynLib "dina", .registration=TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom simcdm sim_dina_items attribute_classes sim_q_matrix sim_subject_attributes
#' @aliases dina-package
"_PACKAGE"