library(testthat)
library(indelmiss)

test_check("indelmiss")
