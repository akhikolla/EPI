#ifndef UU_LAYOUT_XYZCOORDINATES_H_
#define UU_LAYOUT_XYZCOORDINATES_H_

namespace uu {
namespace net {

struct XYZCoordinates
{
  public:
    double x;
    double y;
    double z;
};

}
}

#endif
