#include "core/olap/selection/Indexes.hpp"

namespace uu {
namespace core {
namespace sel {

Indexes::
Indexes(
)
{
}

/**  */

void
Indexes::
eval(
    size_t size
)
{
    (void)size;
}

/**  */
bool
Indexes::
has_next(
) const
{
    return false;
}


/**  */
size_t
Indexes::
next(
)
{
    return 0;
}

}
}
}

