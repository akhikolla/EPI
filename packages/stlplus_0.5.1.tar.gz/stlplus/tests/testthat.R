library(testthat)

test_check("stlplus")
