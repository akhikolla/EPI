library(testthat)
library(waspr)

test_check("waspr")
