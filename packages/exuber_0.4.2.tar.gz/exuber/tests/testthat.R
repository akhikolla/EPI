library(testthat)
library(exuber)

test_check("exuber")
