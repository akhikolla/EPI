#' @export weighted_ntile
hutils::weighted_ntile
