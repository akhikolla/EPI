library(testthat)
library(YPPE)

test_check("YPPE")
