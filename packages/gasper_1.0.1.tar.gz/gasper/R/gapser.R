#' @useDynLib gasper
#' @importFrom Rcpp sourceCpp
#' @import ggplot2
NULL
#' @keywords internal
"_PACKAGE"
