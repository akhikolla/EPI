gasper News

gasper 1.0.1.9000 dev version
=============================

gasper 1.0.1 release (07/27/2020)
=================================

-   fix warnings bug SUREthresh functions
-   adapt DESCRIPTION to meet CRAN’s expectations (i.e., omit the
    redundant “in R” from the title, use the Authors@R field and declare
    Maintainer, Authors and Contributors with their appropriate roles
    with person() calls, do not start the description with “This
    package”, package name, title or similar. Just start with “Provides
    …” or similar, do not start the description with “This package”,
    package name, title or similar).
-   optionally specify a RNG seed (for reproducible experiments) in
    swissroll.R
-   remove adjacency\_mat N arg
-   Cran resubmission

gasper 1.0.0 release (07/23/2020)
=================================

-   First release
-   Cran submission
