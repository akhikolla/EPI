# Based on https://github.com/hadley/testthat#integration-with-r-cmd-check

library(testthat)
library(fdadensity)

test_check("fdadensity")
