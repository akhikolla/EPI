
// Macros

#define RCPP_ARMADILLO_RETURN_COLVEC_AS_VECTOR //armadillo vectors as R vectors!
