class MariaResultImpl;
typedef MariaResultImpl DbResultImpl;
