#ifndef __RMARIADB_MARIA_TYPES__
#define __RMARIADB_MARIA_TYPES__

enum MariaFieldType {
  MY_INT32,
  MY_INT64,   // output only
  MY_DBL,
  MY_STR,
  MY_DATE,
  MY_DATE_TIME,
  MY_TIME,
  MY_RAW,
  MY_LGL     // input only
};

MariaFieldType variable_type_from_field_type(enum_field_types type, bool binary);
std::string type_name(MariaFieldType type);
SEXPTYPE type_sexp(MariaFieldType type);

std::string r_class(RObject x);
MariaFieldType variable_type_from_object(const RObject& type);


#endif
