library(testthat)
library(agtboost)

test_check("agtboost")
