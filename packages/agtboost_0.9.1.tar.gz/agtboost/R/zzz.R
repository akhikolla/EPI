#' @import Rcpp
NULL

loadModule("aGTBModule", TRUE)