#' @useDynLib empichar
#' @importFrom Rcpp sourceCpp
NULL
