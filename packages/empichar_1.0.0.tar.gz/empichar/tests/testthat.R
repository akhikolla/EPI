library(testthat)
library(empichar)

test_check("empichar")
