#' @useDynLib mrf2d
#' @importFrom Rcpp sourceCpp
#' @importFrom methods setClass setMethod
#' @importFrom Rdpack reprompt
#' @importFrom stats na.omit
NULL
