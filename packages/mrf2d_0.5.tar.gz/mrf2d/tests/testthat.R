library(testthat)
library(mrf2d)

test_check("mrf2d")
