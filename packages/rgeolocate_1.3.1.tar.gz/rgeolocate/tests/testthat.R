library(testthat)
library(rgeolocate)

test_check("rgeolocate")
