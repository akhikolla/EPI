library(testthat)
library(TreeBUGS)

test_check("TreeBUGS")
