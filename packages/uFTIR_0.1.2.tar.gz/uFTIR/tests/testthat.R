if(requireNamespace('testthat', quietly = TRUE)){
  
  library(testthat)
  library(uFTIR)
  
  test_check("uFTIR")
  
}