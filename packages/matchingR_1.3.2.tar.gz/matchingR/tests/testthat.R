library(testthat)
library(matchingR)

test_check("matchingR")
