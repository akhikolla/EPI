library(testthat)
library(rbridge)

test_check("rbridge")
