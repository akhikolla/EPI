library(testthat)
library(leontief)

test_check("leontief")
