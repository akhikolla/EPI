library(testthat)
library(readstata13)

test_check("readstata13")
