# kernelTDA version 1.0.0

## Bug fixed

* predict function 

## Major Changes

* changed one-vs-all strategy