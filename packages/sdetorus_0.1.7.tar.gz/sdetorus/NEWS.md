# sdetorus 0.1.6

* Initial version

# sdetorus 0.1.7

* Fix the redefinition of arma::mat forwardSweepPeriodicTridiag() as arma::vec raising an "additional issue" on CRAN.
