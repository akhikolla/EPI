#include <jmotif.h>
#include <Rcpp.h>
using namespace Rcpp;
