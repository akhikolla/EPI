library(testthat)
library(jmotif)

test_check("jmotif")
