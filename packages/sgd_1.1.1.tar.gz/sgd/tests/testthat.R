library(testthat)
test_check("sgd")