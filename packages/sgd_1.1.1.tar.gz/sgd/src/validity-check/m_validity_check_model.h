#ifndef VALIDITY_CHECK_M_VALIDITY_CHECK_MODEL_H
#define VALIDITY_CHECK_M_VALIDITY_CHECK_MODEL_H

#include "../basedef.h"
#include "../data/data_set.h"
#include "../model/m_model.h"

bool validity_check_model(const data_set& data, const mat& theta, unsigned t,
  const m_model& model) {
  // TODO
  return true;
}

#endif
