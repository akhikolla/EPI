#ifndef VALIDITY_CHECK_GMM_VALIDITY_CHECK_MODEL_H
#define VALIDITY_CHECK_GMM_VALIDITY_CHECK_MODEL_H

#include "../basedef.h"
#include "../data/data_set.h"
#include "../model/gmm_model.h"

bool validity_check_model(const data_set& data, const mat& theta, unsigned t,
  const gmm_model& model) {
  // TODO
  return true;
}

#endif
