library(testthat)
library(catsim)

test_check("catsim")
