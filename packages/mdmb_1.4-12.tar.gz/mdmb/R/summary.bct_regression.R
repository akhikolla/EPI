## File Name: summary.bct_regression.R
## File Version: 0.06

summary.bct_regression <- function( object, digits=4, file=NULL, ...)
{
    mdmb_regression_summary( object=object, digits=digits, file=file, ...)
}

