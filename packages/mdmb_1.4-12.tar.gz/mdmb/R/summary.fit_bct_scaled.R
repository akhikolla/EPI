## File Name: summary.fit_bct_scaled.R
## File Version: 0.05

summary.fit_bct_scaled <- function( object, digits=4, file=NULL, ...){
    fit_mdmb_distribution_summary( object=object, digits=digits, file=file, ...)
}

