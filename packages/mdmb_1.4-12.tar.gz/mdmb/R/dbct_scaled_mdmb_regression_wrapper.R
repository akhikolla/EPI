## File Name: dbct_scaled_mdmb_regression_wrapper.R
## File Version: 0.03


dbct_scaled_mdmb_regression_wrapper <- function(probit=FALSE, ...)
{
    res <- dbct_scaled(...)
    return(res)
}
