## File Name: summary.oprobit_regression.R
## File Version: 0.05

summary.oprobit_regression <- function( object, digits=4, file=NULL, ...)
{
    mdmb_regression_summary( object=object, digits=digits, file=file, ...)
}

