library(testthat)
library(YPBP)

test_check("YPBP")
