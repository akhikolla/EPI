library(testthat)
library(rdist)

test_check("rdist")
