## ----echo=TRUE-----------------------------------------------------------
system.file("exec", package = "TexExamRandomizer")

## ----eval=FALSE----------------------------------------------------------
#  vignette("ExamOptions", package = "TexExamRandomizer")

## ----eval=FALSE----------------------------------------------------------
#  vignette("GradingExams", package = "TexExamRandomizer")

