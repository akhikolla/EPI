## ----echo=TRUE-----------------------------------------------------------
system.file("exec", package = "TexExamRandomizer")

