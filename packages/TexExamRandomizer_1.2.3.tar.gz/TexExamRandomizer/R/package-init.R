# Author Alejandro Gonzalez Recuenco
# e-mail <alejandrogonzalezrecuenco@gmail.com>
# (C) 2017
#### ROxigen DynLib link file
####
####


#' @useDynLib TexExamRandomizer
#' @importFrom Rcpp sourceCpp
NULL
