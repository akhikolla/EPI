#WebGestalt 0.4.4
20200723 -- Minor bug fix.
#WebGestalt 0.4.3
20200116 -- Bug fixes. Add a few advanced options for GSEA.
#WebGestalt 0.4.2
20190916 -- Bug fixes.
#WebGestalt 0.4.1
20190703 -- Add option to save downloaded data in cache. Bug fixes.
#WebGestalt 0.4.0
20190422 —— Support of multiple databases for ORA and GSEA. Adjusted column names of the returned data frame.
#WebGestalt 0.3.1
20190314 —— Bug fixes. The version with NAR update manuscript
#WebGestalt 0.3.0
20190116 —— Major updates in HTML report and for 2019 publication
#WebGestalt 0.1.1
Stable version in WebGestalt 2017 update
#WebGestalt 0.0.1
20170207 —— First submit to CRAN
