library(testthat)

test_check("volesti")
