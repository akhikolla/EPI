#' Apply rounding to a convex polytope (H-polytope, V-polytope or a zonotope)
#' 
#' Given a convex H or V polytope or a zonotope as input this function brings the polytope in rounded position based on minimum volume enclosing ellipsoid of a pointset.
#' 
#' @param P A convex polytope. It is an object from class (a) Hpolytope or (b) Vpolytope or (c) Zonotope.
#' @param settings Optional. A list to parameterize the method by the random walk. 
#' \itemize{
#' \item{\code{random_walk} }{  The random walk to sample uniformly distributed points: (a) \code{'CDHR'} for Coordinate Directions Hit-and-Run, (b) \code{'RDHR'} for Random Directions Hit-and-Run or (c) \code{'BiW'} for Billiard walk. The default random walk is \code{'CDHR'} for H-polytopes and \code{'BiW'} for the rest of the representations.}
#' \item{\code{walk_length} }{ The walk length of the random walk. The default value is \eqn{10 + 10d} for \code{'CDHR'} or \code{'RDHR'} and 2 for \code{'BiW'}.}
#' \item{\code{seed} }{ Optional. A fixed seed for the number generator.}
#' }
#' 
#' @return A list with 4 elements: (a) a polytope of the same class as the input polytope class and (b) the element "T" which is the matrix of the inverse linear transformation that is applied on the input polytope, (c)  the element "shift" which is the opposite vector of that which has shifted the input polytope, (d) the element "round_value" which is the determinant of the square matrix of the linear transformation that is applied on the input polytope.
#'
#' @references \cite{I.Z.Emiris and V. Fisikopoulos,
#' \dQuote{Practical polytope volume approximation,} \emph{ACM Trans. Math. Soft.,} 2018.},
#' @references \cite{Michael J. Todd and E. Alper Yildirim,
#' \dQuote{On Khachiyan’s Algorithm for the Computation of Minimum Volume Enclosing Ellipsoids,} \emph{Discrete Applied Mathematics,} 2007.}
#'
#' @examples
#' # rotate a H-polytope (2d unit simplex)
#' A = matrix(c(-1,0,0,-1,1,1), ncol=2, nrow=3, byrow=TRUE)
#' b = c(0,0,1)
#' P = Hpolytope(A = A, b = b)
#' listHpoly = round_polytope(P)
#' 
#' # rotate a V-polytope (3d unit cube) using Random Directions HnR with step equal to 50
#' P = gen_cube(3, 'V')
#' ListVpoly = round_polytope(P)
#' 
#' # round a 2-dimensional zonotope defined by 6 generators using ball walk
#' Z = gen_rand_zonotope(2,6)
#' ListZono = round_polytope(Z)
#' @export
round_polytope <- function(P, settings = list()){
  
  seed = NULL
  if (!is.null(settings$seed)) {
    seed = settings$seed
  }
  
  ret_list = rounding(P, settings, seed)
  
  #get the matrix that describes the polytope
  Mat = ret_list$Mat
  
  # first column is the vector b
  b = Mat[, 1]
  
  # remove first column
  A = Mat[, -c(1), drop = FALSE]
  
  type = P@type
  if (type == 'Vpolytope') {
    PP = list("P" = Vpolytope(V = A), "T" = ret_list$T, "shift" = ret_list$shift, "round_value" = ret_list$round_value)
  }else if (type == 'Zonotope') {
    PP = list("P" = Zonotope(G = A), "T" = ret_list$T, "shift" = ret_list$shift, "round_value" = ret_list$round_value)
  } else {
    PP = list("P" = Hpolytope(A = A, b = b), "T" = ret_list$T, "shift" = ret_list$shift, "round_value" = ret_list$round_value)
  }
  return(PP)
}
