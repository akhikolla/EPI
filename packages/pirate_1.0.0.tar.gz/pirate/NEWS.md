pirate 1.0.0
------------

This is a newly released package.
