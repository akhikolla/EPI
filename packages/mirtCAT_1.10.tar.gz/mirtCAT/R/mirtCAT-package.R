#' Computerized Adaptive Testing with Multidimensional Item Response Theory
#'
#' Provides tools to generate an HTML interface for creating adaptive and 
#' non-adaptive educational and psychological tests using the shiny package. Suitable for 
#' applying unidimensional and multidimensional computerized adaptive tests using item 
#' response theory methodology and for creating simple questionnaires forms to collect
#' response data directly in R. 
#' 
#' Users interested in the most recent version of this package can visit
#' \url{https://github.com/philchalmers/mirtCAT} and follow the instructions
#' for installing the package from source (additional details about installing from 
#' Github can be found at \url{https://github.com/philchalmers/mirt}). 
#' Questions regarding the package can be sent to the mirt-package Google Group, located at
#' \url{https://groups.google.com/forum/#!forum/mirt-package}.
#' 
#' @references 
#' 
#' Chalmers, R., P. (2012). mirt: A Multidimensional Item Response Theory
#' Package for the R Environment. \emph{Journal of Statistical Software, 48}(6), 1-29.
#' \doi{10.18637/jss.v048.i06}
#' 
#' Chalmers, R. P. (2016). Generating Adaptive and Non-Adaptive Test Interfaces for 
#' Multidimensional Item Response Theory Applications. \emph{Journal of Statistical Software, 71}(5), 
#' 1-39. \doi{10.18637/jss.v071.i05}
#'
#' @name mirtCAT-package
#' @docType package
#' @title Computerized Adaptive Testing with Multidimensional Item Response Theory
#' @author Phil Chalmers \email{rphilip.chalmers@@gmail.com}
#' @useDynLib mirtCAT
#' @import mirt shiny methods lattice Rcpp
#' @importFrom stats approx na.omit pnorm qnorm reshape runif spline
#' @importFrom lpSolve lp
#' @importFrom pbapply pblapply
#' @keywords package
NULL
