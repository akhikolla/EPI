#' @title A package for reading various common forms of request log
#' @description see the \href{https://github.com/Ironholds/webreadr/blob/master/vignettes/Introduction.Rmd}{introductory vignette}
#' for more details!
#' @name webreadr
#' @useDynLib webreadr
#' @importFrom Rcpp sourceCpp
#' @import readr
NULL