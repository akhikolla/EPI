library(testthat)
library(webreadr)

test_check("webreadr")
