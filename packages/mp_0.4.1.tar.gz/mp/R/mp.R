#'@title Multidimensional Projection Techniques
#'@description Implementation of multidimensional projection techniques
#'@docType package
#'@name mp
#'@import Rcpp
NULL
