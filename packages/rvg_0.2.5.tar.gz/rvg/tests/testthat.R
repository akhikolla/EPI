library(testthat)
library(rvg)

test_check("rvg")
