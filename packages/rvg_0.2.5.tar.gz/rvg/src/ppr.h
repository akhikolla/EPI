class ppr
{
public:
  ppr (double, double );
  std::string a_tag();

  double hadj;
  double lineheight;
};
