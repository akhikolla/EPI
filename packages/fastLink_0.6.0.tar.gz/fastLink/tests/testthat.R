library(testthat)
library(fastLink)

test_check("fastLink")
