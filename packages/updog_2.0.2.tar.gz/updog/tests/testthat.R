library(testthat)
library(updog)

test_check("updog")
