#include <RcppArmadillo.h>
using namespace arma; 
using namespace Rcpp;
using std::exp;
using std::sqrt;
using std::log;
using arma::pow;
using arma::mat;
using arma::size;
using arma::sign;
using arma::max;
using arma::accu;
using arma::sum;
using arma::field;
using arma::norm;
