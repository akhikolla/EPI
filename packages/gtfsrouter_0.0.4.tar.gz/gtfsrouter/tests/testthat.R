library(testthat)
library(gtfsrouter)

test_check("gtfsrouter")
