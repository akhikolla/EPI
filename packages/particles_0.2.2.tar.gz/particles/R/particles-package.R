#' @useDynLib particles
#' @importFrom Rcpp sourceCpp
#' @aliases particles_package
#'
#' @references See also the [GitHub page](https://github.com/d3/d3-force) for
#' the original JavaScript implementation in D3 by Mike Bostock
'_PACKAGE'
