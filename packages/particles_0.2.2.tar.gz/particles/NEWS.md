# particles 0.2.2

* Fix a bug in trap_force where particles on the edge of a polygon would get 
  an NA velocity



