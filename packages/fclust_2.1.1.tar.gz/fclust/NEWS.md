# fclust 2.1.0

- Fixed bugs

# fclust 2.0.2

- Fixed bugs

# fclust 2.0.1

- Fixed C++ issues.

# fclust 2.0

- New C++ routines.
- Automatic selection of the number of clusters.
- Added `NEFRC()`and `NEFRC.noise()`functions for fuzzy relational clustering algorithms.
- Added `Fclust.compare()` function for fuzzy clustering similarity measures.
