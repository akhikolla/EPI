#' @rdname ULIDgenerate
#' @export
generate <- ULIDgenerate

#' @rdname ULIDgenerate
#' @export
ulid_generate <- ULIDgenerate