0.3.0
* Updated libary
* Uses R C random bits vs `std::rand()`
* Vignette
* Converted to {tinytest}

0.2.0
* Polished version

0.1.0 
* Initial release
