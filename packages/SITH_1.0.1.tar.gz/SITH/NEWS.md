## Version 1.0.1 July 1, 2020 

This patch contains bug fixes. In addition, the dependence on R 4.0.0 is switched to 3.6.0, so that users on the old release can use the package.

Bug fixes:

  * An ambiguous call to the overloaded `pow()` in "post_processing.h" causes a compilation error on Solaris. 

## Version 1.0.0 June 29, 2020

Initial submission to CRAN. 
