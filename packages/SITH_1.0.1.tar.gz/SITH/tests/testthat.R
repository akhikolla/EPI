library(testthat)
library(SITH)

test_check("SITH")
