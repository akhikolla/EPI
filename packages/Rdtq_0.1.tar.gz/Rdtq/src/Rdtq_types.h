#include <Rcpp.h>

typedef double (*funcPtr)(const double& x);

