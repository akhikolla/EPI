# rflexscan 0.3.0

* Updated help for `rflexscan` method.

# rflexscan 0.2.0

* Added a `NEWS.md` file to track changes to the package.
* Renamed `flexscan` method to `rflexscan` to be consistent with the class name.
* Avoided writing/reading temporary files in `rflexscan` method for speed-up.
* Implemented `print.rflexscan` method.
* Implemented `print.rflexscanCluster` method.
