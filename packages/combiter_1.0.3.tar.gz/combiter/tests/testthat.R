library(testthat)
library(combiter)

test_check("combiter")
