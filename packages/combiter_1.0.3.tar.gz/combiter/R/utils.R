#' @useDynLib combiter, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL


