#include <Rcpp.h>
#include <vector>

std::vector<int> NextComb(std::vector<int> x, int n);
std::vector<int> PrevComb(std::vector<int> x, int n);
