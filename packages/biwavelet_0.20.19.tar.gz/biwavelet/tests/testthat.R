library(testthat)
library(biwavelet)

test_check("biwavelet")
