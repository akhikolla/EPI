.onLoad <- function(libname, pkgname) {
  .htdpinit()
}
