library(testthat)
library(stepR)

test_check("stepR")