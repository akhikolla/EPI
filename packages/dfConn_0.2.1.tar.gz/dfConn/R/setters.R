# Setters which summary to use This function to assign which type of summary function to use param type 'average' or 'coverage' return summary functions to use keywords
# internal



set_summary <- function(type) {
    table_summarize <- table_summarize.coverage
    table_summarize
}




