test_that("multiplication works", {
  vapour::vapour_srs_wkt("+init=epsg:4326")
})
