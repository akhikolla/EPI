library(testthat)
library(kernelboot)

test_check("kernelboot")
