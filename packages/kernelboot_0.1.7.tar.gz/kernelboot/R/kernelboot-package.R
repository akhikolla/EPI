
#' @useDynLib kernelboot
#' @importFrom Rcpp sourceCpp
NULL
