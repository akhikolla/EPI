
library(spatialwarnings)
if ( require("testthat") ) { 
  test_check("spatialwarnings")
}
