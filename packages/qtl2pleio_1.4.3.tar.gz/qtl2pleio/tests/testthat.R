library(testthat)
library(qtl2pleio)

test_check("qtl2pleio")
