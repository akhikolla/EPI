#ifndef TreeTools_H_GEN_
#define TreeTools_H_GEN_

#include <Rcpp.h>
using namespace Rcpp;

#include "TreeTools/types.h"
#include "TreeTools/root_tree.h"


#endif // TreeTools_H_GEN_
