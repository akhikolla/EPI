library(testthat)
library(rstpm2)

test_check("rstpm2")
