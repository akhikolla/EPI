.onUnload <- function (libpath) {
  library.dynam.unload("rstpm2", libpath)
}
