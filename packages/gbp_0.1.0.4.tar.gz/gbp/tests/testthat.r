library(testthat)
library(gbp)

test_check("gbp")
