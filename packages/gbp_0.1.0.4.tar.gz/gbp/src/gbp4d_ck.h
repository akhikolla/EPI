#ifndef __BINPACK_BINPACK4D_CK__
#define __BINPACK_BINPACK4D_CK__


#include "gbp4d.h"
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
// using namespace arma;


bool gbp4d_checkr(gbp4d sn);

bool gbp4q_checkr(gbp4q sn);


#endif // __BINPACK_BINPACK4D_CK__
