#ifndef __BINPACK_BINPACK2D_CK__
#define __BINPACK_BINPACK2D_CK__


#include "gbp2d.h"
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
// using namespace arma;


bool gbp2d_checkr(gbp2d sn);

bool gbp2q_checkr(gbp2q sn);


#endif // __BINPACK_BINPACK2D_CK__
