#ifndef __BINPACK_BINPACK3D_CK__
#define __BINPACK_BINPACK3D_CK__


#include "gbp3d.h"
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
// using namespace arma;


bool gbp3d_checkr(gbp3d sn);

bool gbp3q_checkr(gbp3q sn);


#endif // __BINPACK_BINPACK3D_CK__
