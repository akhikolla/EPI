.onUnload <- function (libpath) {
  library.dynam.unload("bssm", libpath)
}
