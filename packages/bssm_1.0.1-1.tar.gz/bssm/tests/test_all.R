library("testthat")
test_check("bssm")
