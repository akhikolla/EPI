
library(testthat)
library(rpact)

test_check("rpact")
