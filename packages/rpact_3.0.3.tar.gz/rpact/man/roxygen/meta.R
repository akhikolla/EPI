
rd_family_title <- list(
	design   = "Design functions",
	analysis = "Analysis functions",
	"analysis functions" = "Analysis functions"
)

list(r6 = FALSE)

