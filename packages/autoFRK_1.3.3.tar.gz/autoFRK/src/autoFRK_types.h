#include <RcppEigen.h>

typedef Eigen::VectorXd MapVecd;
