#' @import RNifti
#' @importFrom Rcpp evalCpp
#' @useDynLib divest, .registration = TRUE, .fixes = "C_"
NULL
