#include <RcppArmadillo.h>

int getsign(double);

arma::uvec findzerocol(arma::mat, int);
