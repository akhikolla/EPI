Bugfixes and features added by

* Gustavo Burin (exp.t support for time machine)
* Jonathan Rolland (time dependent support for GeoSSE)
