#!/usr/bin/env Rscript
set.seed(1)
suppressMessages({
  library(testthat)
  library(diversitree)
})
test_dir(".")
