void logistic(int neqs, double *pars, double *y, double *dydt);
