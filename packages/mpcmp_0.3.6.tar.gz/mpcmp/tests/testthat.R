library(testthat)
library(mpcmp)

test_check("mpcmp")

