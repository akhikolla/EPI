setGeneric("getWeight", function(obj) standardGeneric("getWeight"))
setGeneric("getOutliers", function(obj) standardGeneric("getOutliers"))
setGeneric("getClassLabels", function(obj, i) standardGeneric("getClassLabels"))
setGeneric("getCutoff", function(obj) standardGeneric("getCutoff"))
