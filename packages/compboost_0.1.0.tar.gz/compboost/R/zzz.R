#' @useDynLib compboost, .registration = TRUE
NULL

#' @import Rcpp
NULL
