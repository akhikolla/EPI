## ---- include=FALSE------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE)
# devtools::load_all()
library(compboost)

