library(testthat)
library(compboost)

test_check("compboost")
