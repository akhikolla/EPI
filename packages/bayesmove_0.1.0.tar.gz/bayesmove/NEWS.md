# bayesmove 0.1.0 (2020-09-21)

* First release of bayesmove package.


# bayesmove 0.0.0.9000 (2020-06-02)

* Bayesmove package in development.
