library(testthat)
library(bayesmove)

test_check("bayesmove")
