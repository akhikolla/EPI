library(testthat)
library(fcaR)

test_check("fcaR")
