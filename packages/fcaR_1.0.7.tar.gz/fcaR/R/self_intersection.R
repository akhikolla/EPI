.self_intersection <- function(x, y) {

  self_intersection_C(x_i = x@i,
                      x_p = x@p,
                      y_i = y@i,
                      y_p = y@p)

}
