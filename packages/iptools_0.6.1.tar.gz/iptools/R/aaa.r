# CRAN checks

cidr <- ip <- mask <- in_cidr <- NULL