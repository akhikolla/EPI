library(testthat)
library(detectRUNS)

test_check("detectRUNS")
