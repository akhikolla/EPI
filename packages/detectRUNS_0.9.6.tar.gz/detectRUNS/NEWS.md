
# detectRUNS 0.9.3

## Major changes

* First submission to CRAN

## Bug fixes

* No bugs identified at the moment
