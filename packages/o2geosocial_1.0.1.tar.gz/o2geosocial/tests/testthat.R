library(testthat)
library(o2geosocial)

test_check("o2geosocial")
