# o2geosocial 1.0.1

* Fix: Remove dependencies to unused packages in DESCRIPTION File.
* Fix: Remove checks in cpp_move_swap_cases.
* Fix: Consensus tree for imported cases in "summary()": the value of the column "from" for an imported case is now NA.

# o2geosocial 1.0.0

* initial release
