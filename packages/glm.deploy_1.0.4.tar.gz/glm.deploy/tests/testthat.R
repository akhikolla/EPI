library(testthat)
library(glm.deploy)

test_check("glm.deploy")
