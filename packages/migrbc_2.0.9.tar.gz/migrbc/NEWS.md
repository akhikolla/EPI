# migrbc 2.0.9

* Fixed a potential memory error, raised from Valgrind (CRAN)

# migrbc 2.0.8

* First version on Statistic GitHub