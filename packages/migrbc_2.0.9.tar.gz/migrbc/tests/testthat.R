library(testthat)
library(migrbc)

test_check("migrbc")
