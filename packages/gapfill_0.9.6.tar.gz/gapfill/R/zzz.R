.onAttach <- function(...) {
    packageStartupMessage("--> See ?Gapfill and https://doi.org/10.1109/TGRS.2017.2785240 <--")
  }
