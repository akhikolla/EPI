#' @useDynLib compas, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' 
NULL
