#ifndef MYUTILS_HPP
#define MYUTILS_HPP


//double dABS (double arg);
//float fABS (float arg);
//int iABS (int arg);

#endif // MYUTILS_HPP

