SCOPer
-------------------------------------------------------------------------------

SCOPer provides a computational framework for the identification of B cell 
clonal relationships from Adaptive Immune Receptor Repertoire sequencing 
(AIRR-Seq) data. It includes methods for assigning clonal identifiers using
sequence identity, hierarchical clustering, and spectral clustering.
SCOPer is part of the [Immcantation](http://immcantation.readthedocs.io) 
analysis framework.

Contact
-------------------------------------------------------------------------------

For help and questions please contact the 
[Immcantation Group](mailto:immcantation@googlegroups.com)
