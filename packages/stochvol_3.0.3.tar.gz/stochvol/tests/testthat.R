library(testthat)
library(stochvol)

test_check("stochvol")
