#ifndef _TYPE_DEFINITIONS_H_OLD_STOCHVOL_
#define _TYPE_DEFINITIONS_H_OLD_STOCHVOL_

#include "type_definitions.hpp"
#include "expert.hpp"

#endif
