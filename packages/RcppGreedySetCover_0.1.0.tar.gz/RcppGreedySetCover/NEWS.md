# RcppGreedySetCover 0.1.0

* Initial release of implementation of the greedy set cover algorithm via Rcpp.




