library(testthat)
library(lfmm)

test_check("lfmm")
