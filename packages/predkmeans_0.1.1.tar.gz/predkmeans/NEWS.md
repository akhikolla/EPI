# predkmeans 0.1.1

* Replaced checks of the form `class(.)==*` with `inherits()`.
* Corrected an error in the creation of CV groups in `createCVgroups()` when using row names to identify observations.
* Added this NEWS.md file to document package changes.

# predkmeans 0.1.0

* Initial package release