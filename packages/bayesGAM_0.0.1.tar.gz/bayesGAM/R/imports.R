#' @importMethodsFrom rstan plot extract show summary 
#' @importFrom cluster clara
#' @importFrom graphics abline
#' @importFrom corrplot corrplot.mixed
#' @importFrom boot inv.logit
#' @import geometry
#' @import stats
#' @import SemiPar
#' @import ggplot2
NULL
