library(testthat)
library(bayesGAM)
library(SemiPar)

test_check("bayesGAM")
