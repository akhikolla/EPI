library(testthat)
library(shapr)

test_check("shapr")
