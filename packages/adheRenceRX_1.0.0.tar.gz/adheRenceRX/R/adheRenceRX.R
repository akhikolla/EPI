#' @useDynLib adheRenceRX
#' @importFrom Rcpp evalCpp
#' @exportPattern "^[[:alpha:]]+"
NULL