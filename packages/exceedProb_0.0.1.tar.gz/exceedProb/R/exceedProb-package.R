## usethis namespace: start
#' @useDynLib exceedProb, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
