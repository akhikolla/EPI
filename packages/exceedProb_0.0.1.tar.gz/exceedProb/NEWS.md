# exceedProb 1.0.0

This is the initial release of exceedProb.