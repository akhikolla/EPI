#' sparta: Sparse Tables
#'
#' Fast Multiplication and Marginalization of Sparse Tables.
#'
#' @importFrom Rcpp sourceCpp
#' @useDynLib sparta, .registration = TRUE
"_PACKAGE"

