library(testthat)

test_check("hmlasso")
