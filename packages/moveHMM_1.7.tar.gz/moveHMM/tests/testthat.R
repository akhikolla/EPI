library(testthat)
library(moveHMM)

test_check("moveHMM")
