#' @importFrom Rcpp evalCpp
#' @useDynLib image.dlib
NULL










