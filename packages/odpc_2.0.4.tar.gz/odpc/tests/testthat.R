library(testthat)
library(odpc)

test_check("odpc")
