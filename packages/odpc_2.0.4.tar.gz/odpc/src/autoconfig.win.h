/* confdefs.h */
#define PACKAGE_NAME "odpc"
#define PACKAGE_TARNAME "odpc"
#define PACKAGE_VERSION "1.0.9000"
#define PACKAGE_STRING "odpc 1.0.9000"
#define PACKAGE_BUGREPORT ""
#define PACKAGE_URL ""
#define STDC_HEADERS 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STRINGS_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDINT_H 1
#define HAVE_UNISTD_H 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
/* #undef HAVE_OPENMP_C */
/* #undef HAVE_OPENMP_CXX */
#define HAVE_UINT8_16_MAX 1
#define HAVE_UINT32_MAX 1
#define RESTRICT __restrict__
