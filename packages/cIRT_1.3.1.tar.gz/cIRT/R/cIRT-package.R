#' @useDynLib cIRT, .registration=TRUE
#' @importFrom Rcpp evalCpp
#' @aliases cIRT-package
"_PACKAGE"
