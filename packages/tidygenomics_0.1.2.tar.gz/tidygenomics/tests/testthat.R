library(testthat)
library(tidygenomics)

test_check("tidygenomics")
