#ifndef projOp_H
#define projOp_H


#include <RcppArmadillo.h>

arma::vec projOp(arma::vec v,arma::vec u);

#endif
