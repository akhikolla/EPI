# tidyfast 0.2.1

* Initial release of `tidyfast`!

