#include <RcppArmadillo.h>

RcppExport SEXP subMat(SEXP x, SEXP nx, SEXP ny, SEXP nz, SEXP nper);
