
`print.mult` <- function(x,...){
 X <- list()
 X$sigTests <- as.numeric(x$sigTests)
 print(X,...)
}