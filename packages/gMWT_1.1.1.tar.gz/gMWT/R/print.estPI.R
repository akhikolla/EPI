# Version: 30-11-2012, Daniel Fischer

`print.estPI` <- function(x,...){
 X <- list()
 X$probs <- x$probs
 print(X,...)
}