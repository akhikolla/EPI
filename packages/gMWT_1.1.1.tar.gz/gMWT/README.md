# gMWT
Generalized Mann-Whitney type tests based on probabilistic indices and new diagnostic plots
