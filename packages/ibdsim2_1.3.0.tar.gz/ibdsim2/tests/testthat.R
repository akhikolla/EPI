library(testthat)
library(ibdsim2)

test_check("ibdsim2")
