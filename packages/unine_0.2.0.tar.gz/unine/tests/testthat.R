library(testthat)
library(unine)

test_check("unine")
