# unine 0.2.0

* fix bug in removing stem inside words (C++ code)

# unine 0.1.0

* First version of Unine, stem for 7 languages

