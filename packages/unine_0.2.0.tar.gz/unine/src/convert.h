#pragma once

std::wstring utf8_to_utf16(const std::string& utf8);
