#' @name unine
#' @useDynLib unine, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @import methods
"_PACKAGE"
