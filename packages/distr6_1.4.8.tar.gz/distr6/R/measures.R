# cvmDist <- function(dist1, dist2) {
#
# } # TO DO
#
# hellingerDist <- function(dist1, dist2) {
#
# } # TO DO
#
# kolmogorovDist <- function(dist1, dist2) {
#
# } # TO DO
#
# totalVarDist <- function(dist1, dist2) {
#
# } # TO DO
#
# kullbackLeiblerDist <- function(dist1, dist2) {
#
# } # TO DO
