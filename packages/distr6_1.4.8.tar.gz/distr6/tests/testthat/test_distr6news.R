# library(testthat)
#
# context("distr6news")
#
# test_that("distr6news", {
#   expect_silent(distr6News())
# })
# #
