library(testthat)
library(RcppXsimd)

test_check("RcppXsimd")
