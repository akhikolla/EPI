# RcppXsimd 7.1.4

Patch for compilation error on Solaris

# RcppXsimd 7.1.3

Initial CRAN submission
