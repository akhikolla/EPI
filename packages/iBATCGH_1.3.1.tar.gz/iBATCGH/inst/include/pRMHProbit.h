#ifndef __pRMHProbit_h__
#define __pRMHProbit_h__

#include "iBATCGH_RcppExports.h"
double prProbit(int choice,int m,int chg,double alpha0,double alpha1,double* mSum,int* mR,int mg);

#endif // __pRMHProbit_h__

