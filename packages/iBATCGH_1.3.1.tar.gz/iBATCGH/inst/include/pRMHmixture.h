#ifndef __pRMHmixture_h__
#define __pRMHmixture_h__

#include "iBATCGH_RcppExports.h"
double pr(int choice,int m,int chg,double add0,double add1,double* mGam,double* mOm1,double* mOm2,int* mRnew,int* mR,int mg);

#endif // __pRMHmixture_h__

