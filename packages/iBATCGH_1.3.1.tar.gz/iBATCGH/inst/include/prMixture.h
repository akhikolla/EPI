#ifndef __prMixture_h__
#define __prMixture_h__

#include "iBATCGH_RcppExports.h"
double pRedge(double gamma, double omega, int rgm, int rgma, double add);
double pRmiddle(double gamma, double omega1, double omega2, int rgm, int rgmm, int rgmp, double add);

#endif // __prMixture_h__

