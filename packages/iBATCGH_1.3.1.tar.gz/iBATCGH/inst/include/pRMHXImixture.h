#ifndef __pRMHXImixture_h__
#define __pRMHXImixture_h__

#include "iBATCGH_RcppExports.h"

double pr2(int choice,int m,int chg,double add,double* mGam,double* mOm1,double* mOm2,double* mGamNew,double* mOm1New,double* mOm2New,int* mR, int mg);

#endif // __pRMHXImixture_h__

