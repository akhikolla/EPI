#ifndef GAMMLN_H_INCLUDED
#define GAMMLN_H_INCLUDED

long double gammln(long double xx);

#endif // GAMMLN_H_INCLUDED
