verticesBarycenter <-
function (vertices)
{
    colMeans(vertices)
}
