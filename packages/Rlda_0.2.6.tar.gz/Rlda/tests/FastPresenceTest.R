#data<- dat<-read.csv('data/fake data 10.csv',as.is=T)
#data$loc.id<-dat$loc.id<-seq(1,nrow(dat))
#loc.id<-'loc.id'
#n_community<- 10
#alpha0<- 1
#alpha1<- 1
#gamma<- 0.1
#n_gibbs<- 8000
#ll_prior = TRUE
#display_progress = TRUE
#library(Rcpp)
#sourceCpp("src/aux1.cpp")

#data<-as.data.frame(data)
#library(Rlda)
#res<-rlda.fastbernoulli(data, loc.id, n_community, alpha0, alpha1, gamma, n_gibbs, ll_prior = TRUE, display_progress = TRUE)

#plot(res)
