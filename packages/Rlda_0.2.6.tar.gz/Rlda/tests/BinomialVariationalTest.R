
#rm(list=ls())
#setwd('C:\\Users\\Pedro Albuquerque\\Desktop\\Denis')
#tmp=as.data.frame(data.matrix(read.csv('fake data 7.csv',as.is=T)))
#res<- rlda.binomialVB(data=tmp, loc.id='loc.id', n_community=10, alpha0=0.01, alpha1=0.99, gamma=0.1, maxit=100, thresh=0.0001)
#plot(res)

