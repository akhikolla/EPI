library(testthat)
library(partition)

test_check("partition")
