library(testthat)
library(catlearn)
suppressWarnings(RNGversion("3.5.0"))
test_check("catlearn")
