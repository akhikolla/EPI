library(testthat)
library(eulerr)
test_check("eulerr")
