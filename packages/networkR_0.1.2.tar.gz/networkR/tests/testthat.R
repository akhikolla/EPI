library(testthat)
library(networkR)

test_check("networkR")
