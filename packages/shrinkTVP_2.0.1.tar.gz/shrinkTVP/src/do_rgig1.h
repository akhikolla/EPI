#ifndef DO_RGIG1_H
#define DO_RGIG1_H

double do_rgig1(double lambda, double chi, double psi);

#endif
