library(testthat)
library(shrinkTVP)

test_check("shrinkTVP")
