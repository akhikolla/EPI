# rlme 0.5

* Added a `NEWS.md` file to track changes to the package.
* Cleaned up package to pass R cmd check on R 3.4.3



