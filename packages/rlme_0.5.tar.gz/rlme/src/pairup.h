#include "Rcpp.h"
using namespace Rcpp;

NumericMatrix pairup(NumericVector vec, String type = "less");
