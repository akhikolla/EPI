jmake <- function(n) {
    jmake = matrix(rep(1, n^2), ncol = n)
    jmake
}
