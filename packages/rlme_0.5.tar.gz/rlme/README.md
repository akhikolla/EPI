# rlme: Rank-Based Estimation and Prediction in Random Effects Nested Models
# [![Travis-CI Build Status](https://travis-ci.org/herbps10/rlme.svg?branch=master)](https://travis-ci.org/herbps10/rlme)