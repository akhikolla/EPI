library(testthat)

test_check("rlme")