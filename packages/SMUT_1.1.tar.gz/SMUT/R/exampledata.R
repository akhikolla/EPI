#' A example genotype data
#'
#' @format A matrix with 100 rows and 200 columns. Each row is an individual; each column is a SNP.
#' \describe{
#'   Example genotype data for SMUT. It is a matrix with 100 rows and 200 columns. Each row is an individual; each column is a SNP.
#'   ...
#' }
#' @source 
"Genotype_data"
