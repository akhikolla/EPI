#' @useDynLib estudy2
#' @importFrom Rcpp sourceCpp
NULL
