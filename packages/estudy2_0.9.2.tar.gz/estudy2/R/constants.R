# constants:
const_q1 <- qnorm(1 - 0.10/2); lockBinding("const_q1", environment())
const_q2 <- qnorm(1 - 0.05/2); lockBinding("const_q2", environment())
const_q3 <- qnorm(1 - 0.01/2); lockBinding("const_q3", environment())

