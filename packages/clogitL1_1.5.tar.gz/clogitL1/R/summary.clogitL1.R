summary.clogitL1 = function(object, ...){
	list(Coefficients=object$beta, Lambda=object$lambda)
}