bool getGDALDataType(std::string datatype, GDALDataType &gdt);
