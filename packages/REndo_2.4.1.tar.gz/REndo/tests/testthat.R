library(testthat)
library(REndo)
library(Formula)

test_check("REndo")
