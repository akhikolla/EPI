library(testthat)
library(gretel)

test_check("gretel")
