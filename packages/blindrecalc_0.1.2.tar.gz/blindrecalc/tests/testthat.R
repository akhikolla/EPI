library(testthat)
library(blindrecalc)

test_check("blindrecalc")
