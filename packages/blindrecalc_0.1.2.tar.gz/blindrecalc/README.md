[![Travis build status](https://travis-ci.com/imbi-heidelberg/blindrecalc.svg?branch=master)](https://travis-ci.com/imbi-heidelberg/blindrecalc)
[![Codecov test coverage](https://codecov.io/gh/imbi-heidelberg/blindrecalc/branch/master/graph/badge.svg)](https://codecov.io/gh/imbi-heidelberg/blindrecalc?branch=master)

# blindrecalc
Compute characteristics and plots for blinded sample size recalculation
