eBsc <-
function(y, q = NULL, method = "N", parallel = FALSE, R0 = NULL, zero_range = c(-45,1), ARpMAq = c(0,0), trace = FALSE, tol.lambda = 0.01, tol.rho = 0.01, max.iter = 50) UseMethod("eBsc")
