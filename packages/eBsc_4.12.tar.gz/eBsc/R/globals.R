utils::globalVariables(c("neBsc", "EeBsc", "BasiseBsc"))
