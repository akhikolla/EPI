library(testthat)
library(junctions)

test_check("junctions")
