# goffda 0.0.5

* Initial version

# goffda 0.0.6

* Comply with _R_CLASS_MATRIX_ARRAY_=true
* Roxygen 7.0.1

# goffda 0.0.7

* Added option refit_lambda in flm_test
* Added Lee et al. (2020) test
* Extended applications
* Fixes in documentation
