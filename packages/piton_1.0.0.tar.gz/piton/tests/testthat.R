library(testthat)
library(piton)

test_check("piton")
