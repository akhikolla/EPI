library(testthat)
library(scoringRules)

test_check("scoringRules")
