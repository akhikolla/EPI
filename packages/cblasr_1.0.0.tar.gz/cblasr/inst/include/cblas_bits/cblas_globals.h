#ifndef CBLAS_GLOBAL_H_
#define CBLAS_GLOBAL_H_

static int CBLAS_CallFromC = 0;
static int RowMajorStrg = 0;

#endif
