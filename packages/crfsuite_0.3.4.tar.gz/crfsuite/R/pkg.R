#' @importFrom Rcpp evalCpp
#' @importFrom data.table setDT data.table rbindlist tstrsplit ':=' setDF setDT shift as.data.table
#' @importFrom utils download.file head tail combn
#' @importFrom tools file_path_sans_ext
#' @importFrom stats na.exclude weighted.mean
#' @useDynLib crfsuite
NULL


