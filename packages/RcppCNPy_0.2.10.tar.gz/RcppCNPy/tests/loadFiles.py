#!/usr/bin/python

import os
import numpy as np

# simple float and integer arrays
print np.load("fmat.npy")
print np.load("imat.npy")

# simple float and integer vectors
print np.load("fvec.npy")
print np.load("ivec.npy")
