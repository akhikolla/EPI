
# Function .onLoad
.onLoad <- function(libname, pkgname) {
  options(spaces = c("<->", "->", "+"))
  invisible()
}
