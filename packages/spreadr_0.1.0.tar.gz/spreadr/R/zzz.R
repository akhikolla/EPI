#' @useDynLib SpANR
#' @importFrom Rcpp sourceCpp
NULL
