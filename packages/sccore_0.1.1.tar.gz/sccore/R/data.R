#' UMAP embedding 
#'
"umapEmbedding"

#' Conos graph 
#'
"conosGraph"

#' Conos cell annotations
#'
"cellAnnotations"

#' Conos clusters list
#' 
"conosClusterList"