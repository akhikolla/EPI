library(sccore)

testthat::test_check("sccore")