#' @importFrom  jiebaR worker segment
#' @import Rcpp
#' @useDynLib jiebaRapi
NULL

