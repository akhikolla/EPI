library(testthat)
test_check("jiebaR")