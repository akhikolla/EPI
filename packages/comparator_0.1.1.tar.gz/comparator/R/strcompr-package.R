#' @keywords internal
"_PACKAGE"

#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @importFrom methods new
#' @useDynLib comparator
NULL