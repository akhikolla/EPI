library(testthat)
library(comparator)

test_check("comparator")
