# sharpeRratio
R package to compute Sharpe ratios with the total drawdown duration of a price time series
