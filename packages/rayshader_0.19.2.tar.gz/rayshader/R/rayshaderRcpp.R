#' @useDynLib rayshader, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL