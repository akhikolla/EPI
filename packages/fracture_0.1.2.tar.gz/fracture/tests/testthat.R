library(testthat)
library(fracture)

test_check("fracture")
