expect_survfit <- function(x) expect_s3_class(x, "survfit.stanjm")
