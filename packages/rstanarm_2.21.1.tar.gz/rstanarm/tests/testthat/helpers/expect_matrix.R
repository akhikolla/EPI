expect_matrix <- function(x) expect_true(is.matrix(x))
