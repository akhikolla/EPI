#ifndef _unmarked_NLL_LIKTRANS_H
#define _unmarked_NLL_LIKTRANS_H

#include <RcppArmadillo.h>

RcppExport SEXP get_lik_trans(SEXP I_, SEXP I1_);

#endif
