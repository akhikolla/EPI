#ifndef _unmarked_NLL_MULTPROB_H
#define _unmarked_NLL_MULTPROB_H

#include <RcppArmadillo.h>

RcppExport SEXP get_mlogit(SEXP lp_mat_, SEXP type_, SEXP S_, SEXP guide_);

#endif
