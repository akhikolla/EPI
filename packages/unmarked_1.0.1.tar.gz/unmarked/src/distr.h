
#ifndef _unmarked_DISTR_H
#define _unmarked_DISTR_H

// Zero-inflated Poisson
double dzip(int x, double lambda, double psi);


#endif
