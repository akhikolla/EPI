#ifndef _unmarked_UTILS_H
#define _unmarked_UTILS_H

#include <RcppArmadillo.h>

arma::mat inv_logit( arma::mat inp );

#endif
