# seal registry
rrecsysRegistry$seal_entries()
#dataSetRegistry$seal_entries()