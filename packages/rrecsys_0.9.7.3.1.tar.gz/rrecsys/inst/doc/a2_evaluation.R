## ---- eval=FALSE---------------------------------------------------------
#  e <- evalModel(smallML, folds = 5)

## ---- eval=FALSE---------------------------------------------------------
#  evalPred(e, "ibknn", neigh = 5)

## ---- eval=FALSE---------------------------------------------------------
#  evalRec(e, "funk", k = 5, positiveThreshold = 3, topN = 3)

