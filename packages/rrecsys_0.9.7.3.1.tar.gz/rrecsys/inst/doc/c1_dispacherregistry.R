## ----global_options, include=FALSE---------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(rrecsys)

## ---- eval=FALSE---------------------------------------------------------
#  # Usage
#  rrecsys(data, alg, ...)

## ------------------------------------------------------------------------
rrecsysRegistry

