## ---- eval=FALSE---------------------------------------------------------
#  wALS <- rrecsys(smallML, "wALS", k = 5, lambda = 0.01, scheme = "uni", delta = 0.04)
#  wALS

## ---- eval=FALSE---------------------------------------------------------
#  setStoppingCriteria(nrLoops = 10)

## ---- eval=FALSE---------------------------------------------------------
#  setStoppingCriteria(autoConverge = TRUE, deltaErrorThreshold = 1e-5, minNrLoops = 10)

