
# RcppDynProg 0.2.0 2020/12/15

 * Check API invarients, inspired by Akila Chowdary Kolla's fuzz testing.

# RcppDynProg 0.1.6 2020/11/13

 * Remove old test fn.

# RcppDynProg 0.1.5 2020/10/17

 * Move to tinytest.

# RcppDynProg 0.1.4 2020/08/11

 * Badges.

# RcppDynProg 0.1.3 2019/07/24

 * Adjust license.

# RcppDynProg 0.1.2 2019/03/31

 * Clean up testing pattern a bit.
 * Move ggplot2 out of the vingettes as ggplot2 is breaking things with "VECTOR_ELT() can only be applied to a 'list', not a 'double'".

# RcppDynProg 0.1.1 2019/02/02

 * Add logistic scoring.
 * No k-bound variation.
 * Add a logistic fitter.
 * Switch to RUnit testing.
 * Stricter floating point.
 * Introduce input_summary class.

# RcppDynProg 0.1.0 2019/01/01

 * Initial version.


