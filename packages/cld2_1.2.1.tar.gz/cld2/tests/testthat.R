library(testthat)
library(cld2)

test_check("cld2")
