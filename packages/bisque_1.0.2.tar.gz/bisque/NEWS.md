# bisque 1.0.2 (2020-02-03)

## Enhancements

* Removing dependencies on orphaned packages (doRNG).


# bisque 1.0.1 (2019-04-25)

## Bug fixes

* Fixing buffer overflow in spatial composition sampler.
