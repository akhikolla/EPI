// disable eigen assertions
#define EIGEN_NO_DEBUG
