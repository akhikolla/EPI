library(testthat)
library(kernelPSI)

test_check("kernelPSI")
