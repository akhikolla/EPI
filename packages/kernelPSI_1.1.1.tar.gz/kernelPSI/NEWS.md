# kernelPSI 1.1.1
Now compatible with the upcoming R version 4.0.0

# kernelPSI 1.1.0
The computational complexity in the functions HSIC and quadHSIC is
reduced from cubic to quadratic in the number of samples. This 
results in a dramatic speed increase for large datasets. 

# kernelPSI 1.0.0
Initial release of the kernelPSI package
