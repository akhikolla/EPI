library(testthat)
library(hans)

test_check("hans")
