#pragma once

/**************************************************************/
/*  This is the generic header to be included in the binders  */
/*  in order to call keops routines                           */
/**************************************************************/

#include "utils.h"
#include "checks.h"
#include "switch.h"
