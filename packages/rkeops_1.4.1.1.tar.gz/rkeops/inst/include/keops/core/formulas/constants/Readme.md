The file where the elementary constants are defined. Available constants are :
*      Zero<DIM>					: zero-valued vector of dimension DIM
*      IntConstant<N>				: constant integer function with value N
