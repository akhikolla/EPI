# dummy function for rekops binder pseudo-package
rkeops_binder <- function() {
    print("Hello from rkeops binder pseudo-package.")
}