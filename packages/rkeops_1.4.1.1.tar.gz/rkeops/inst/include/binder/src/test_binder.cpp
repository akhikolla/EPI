#include <Rcpp.h>

// [[Rcpp::export]]
int test_binder() {
    return(1);
}
