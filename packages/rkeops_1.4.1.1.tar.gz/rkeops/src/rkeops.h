#include <Rcpp.h>
#include <RcppEigen.h>

#ifndef _USE_RCPP
#define _USE_RCPP 1
#endif
