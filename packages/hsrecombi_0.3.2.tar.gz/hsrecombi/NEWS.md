# hsrecombi 0.3.2

* update vignette

# hsrecombi 0.3.1

* vignette describing the workflow

# hsrecombi 0.3.0

* new feature for detecting candidates of misplacement in the underlying genome 
   assembly

# hsrecombi 0.2.0

* new feature for comparing estimates of recombination rate directly with 
   output from hsphase::pm 
* approximation of genetic positions based on recombination rates

# hsrecombi 0.1.3

* First release
