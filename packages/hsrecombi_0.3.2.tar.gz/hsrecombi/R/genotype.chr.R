#' @title targetregion: progeny genotypes
#' @name genotype.chr
#' @docType data
#' @description matrix of progeny genotypes in target region on chromosome BTA1
"genotype.chr"
