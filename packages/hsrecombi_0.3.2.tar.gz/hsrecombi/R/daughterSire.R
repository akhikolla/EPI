#' @title targetregion: allocation of paternal half-sib families
#' @name daughterSire
#' @docType data
#' @description Vector of sire ID for each progeny
"daughterSire"
