#' @title targetregion: sire haplotypes
#' @name hapSire
#' @docType data
#' @description matrix of sire haplotypes in target region on chromosome BTA1
"hapSire"
