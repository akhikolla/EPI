library(testthat)
library(impactflu)

test_check("impactflu")
