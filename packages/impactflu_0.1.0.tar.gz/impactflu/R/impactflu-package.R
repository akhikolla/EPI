## usethis namespace: start
#' @useDynLib impactflu, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
#' @importFrom dplyr lag mutate group_by summarise ungroup
#' @importFrom lubridate ymd
#' @importFrom magrittr "%>%"
NULL
