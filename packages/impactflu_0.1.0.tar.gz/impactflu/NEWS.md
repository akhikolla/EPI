# 0.1.0

First release

* Data simulation from [Tokars (2018)](https://doi.org/10.1016/j.vaccine.2018.10.026) reference model. Both deterministic and stochastic versions.

* Impact (averted cases) counting methods 1 (current) and 3 (least biased) implemented.
