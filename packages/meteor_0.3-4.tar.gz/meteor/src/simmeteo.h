
std::vector<double> simmeteo_rain(std::vector<double> rain, std::vector<double> raindays, int years, double markov, unsigned seed);
