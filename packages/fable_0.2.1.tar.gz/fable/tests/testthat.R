library(testthat)
library(fable)

test_check("fable")
