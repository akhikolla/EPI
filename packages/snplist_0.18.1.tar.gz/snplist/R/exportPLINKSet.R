exportPLINKSet <- function(geneSets, fname){
	.Call( "exportPLINKSet", geneSets, fname)
}

