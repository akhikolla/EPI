library(testthat)
library(recurse)

test_check("recurse")
