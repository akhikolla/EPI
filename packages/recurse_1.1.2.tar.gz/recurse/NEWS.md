## Changes in recurse version 1.1.1
### Bug fixes
- fix problem with deprecated C++, change from bind1st() to bind()

## Changes in recurse version 1.1.1
### Bug fixes
- fix problem with plotting when there are some locations with 0 revisists

## Changes in recurse version 1.1.0

### New features
- add getRecursionsInPolygon function to calculate revisits to a convex polygon
- added citation DOI: 10.1111/ecog.03618

## Changes in recurse version 1.0.1

### Bug fixes
- fix problem with vignette building on R-oldrelease

## Changes in recurse version 1.0.0

### New features
- first version of recurse with functionality to calculate revisits to the movement trajectory or other locations