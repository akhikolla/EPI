.onAttach <- function(libname, pkgname) {
  packageStartupMessage("qs v0.23.4.")
}
