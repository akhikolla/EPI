# Changes in v0.5.1

* topics() now returns factor with NA for empty documents
* Fix a bug in initializing LDA that leads to incorrect phi (#4 and #6)

# Changes in v0.5

* Implement original LDA estimator using the LDAGibbs++ library
