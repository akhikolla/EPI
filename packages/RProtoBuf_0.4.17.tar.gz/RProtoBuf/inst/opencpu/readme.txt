These scripts illustrate how protocol buffers can be used as a data interchange format
or as the basis of an RPC protocol. 