#ifndef LENGTH_H
#define LENGTH_H

// for now, we just typedef Length as a double.
// in the future, something more elaborate may be
// needed, as in TeX
typedef double Length;

#endif
