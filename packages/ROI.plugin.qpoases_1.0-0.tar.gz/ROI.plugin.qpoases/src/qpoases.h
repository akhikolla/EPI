
#include <R.h>
#include <Rcpp.h>
#include <qpOASES.hpp>

using namespace Rcpp;
using namespace std;



