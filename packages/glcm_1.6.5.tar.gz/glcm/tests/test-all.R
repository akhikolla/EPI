library(testthat)
test_check('glcm')
