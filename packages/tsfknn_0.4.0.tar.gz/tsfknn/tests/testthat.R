library(testthat)
library(tsfknn)

test_check("tsfknn")
