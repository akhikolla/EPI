amt2ade <- function(x) {

}

amt2ctmm <- function(x) {

}

amt2crawl <- function(x) {

}


amt2move <- function(x) {

}

amt2bcpa <- function(x) {

}

amt2trip <- function(x) {

}

amt2movehmm <- function(x) {

}
