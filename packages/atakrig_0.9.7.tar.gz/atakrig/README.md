# atakrig
This package is for area-to-area/area-to-point (co)kriging. 

Point-scale variogram/cross-variogram can be automatically deconvoluted from irregular/regular spatial support according to Goovaerts, (2008). "Kriging and semivariogram deconvolution in the presence of irregular geographical units." Mathematical Geosciences 40 (1): 101-128.

                       Install from GitHub :  devtools::install_github("maoguihu/atakrig") or install.packages("atakrig")

