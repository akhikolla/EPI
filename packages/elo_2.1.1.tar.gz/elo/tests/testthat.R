library(testthat)
library(elo)

test_check("elo")
