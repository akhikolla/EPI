# benchr 0.2.5

- Fix ggplot tests related with the changes in ggplot2 3.3.0.

# becnhr 0.2.4

- Fix check eeror on R devel (due stringsAsFactors).

# becnhr 0.2.3

- Switch tests framework from the `testthat` to `tinytest`.

# becnhr 0.2.2

- Fix tests related with the `ggplot2` 3.0.0 release.

# becnhr 0.2.1

- Update `Rcpp` mininal version requirements to 0.12.11.
- User `drat` repo to install devel version.

# benchr 0.2.0

- Added progress bar (using `RcppProgress` package) (#14).
- Fixed limits when plotting with the log trnasformation (#19).
- Some fixes related with R 3.3.4 release.

# benchr 0.1.0

- Initial release.
