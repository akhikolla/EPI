#ifndef HELPER_FUNCTIONS_H
#define HELPER_FUNCTIONS_H

arma::cube rinvwish(int n, int v, arma::mat S);

#endif
