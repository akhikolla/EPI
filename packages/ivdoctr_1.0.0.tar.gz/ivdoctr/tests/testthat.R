library(testthat)
library(ivdoctr)

test_check("ivdoctr")
