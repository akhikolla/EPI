library(testthat)
library(sirus)

test_check("sirus")
