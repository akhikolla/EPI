library(testthat)
library(disaggR)

test_check("disaggR")
