library(testthat)
library(rxylib)

test_check("rxylib")
