#' @keywords internal
"_PACKAGE"
#' @docType package
NULL
