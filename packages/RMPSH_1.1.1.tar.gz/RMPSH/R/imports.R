#' @useDynLib RMPSH, .registration = TRUE
#' @importFrom Rcpp sourceCpp

NULL
