#' Cluster example
#'
#' An example, 2-dimensional dataset containing the 100 points for each of five
#'   bivariate normal distributions arranged equidistant along the outline of a
#'   circle.
#'
#' To inspect execute \code{plot(cluster_example)}.
"cluster_example"
