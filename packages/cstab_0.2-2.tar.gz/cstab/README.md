
# cstab

Selection of Number of Clusters via Resampled Normalized Cluster Stability; the corresponding paper can be found on arXiv: https://arxiv.org/abs/1608.07494
