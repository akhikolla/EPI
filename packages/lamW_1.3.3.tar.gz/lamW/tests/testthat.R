library(testthat)
library(lamW)

test_check("lamW")
