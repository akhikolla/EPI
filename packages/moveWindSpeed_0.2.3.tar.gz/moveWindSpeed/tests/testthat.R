library('testthat')
library('moveWindSpeed')

test_check("moveWindSpeed")