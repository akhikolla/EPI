# moveWindSpeed 0.2.3

* Fix for new R release

# moveWindSpeed 0.2.2

* Update vignette title

# moveWindSpeed 0.2.1

* Fix typo in description

# moveWindSpeed 0.2.0

* Did a lot of improvement to make the package more modular and reusable
* Defaults for thermalling function changed
* Added functions to estimate the autocorrelation and a vignette to illustrate it
* Added a `NEWS.md` file to track changes to the package.

# moveWindSpeed 0.1.0

* Initial release
