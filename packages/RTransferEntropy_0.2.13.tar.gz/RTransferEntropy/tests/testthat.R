library(testthat)
library(RTransferEntropy)

test_check("RTransferEntropy")
