globalVariables(c("theCall", "ALT.M", "ALT.B", "y",
                  "rainfall", "RAIN", "alt", "ast",
                  "SeaLevel", "Y", "SO2", "pst",
                  "makeCluster", "detectCores", "stopCluster"))

globalVariables(c("rainfall", "Y", "ALT.B"))

globalVariables(c("xend", "yend", "th", "u", "x", "..density..", "r", "ex"))

globalVariables(c("p","qu","chibar","m","absz"))

globalVariables(c("H", "V", "xval", "yval", ".XXidXX.", "xlab", "ylab",
                  "penalty", "error"))
