#!/bin/sh

rm -rf ./Onigmo
git clone https://github.com/k-takata/Onigmo.git

rm -rf ./libsailr
git clone https://github.com/niceume/libsailr.git

