#include "node.h"

void tree_free(TreeNode*, int);
