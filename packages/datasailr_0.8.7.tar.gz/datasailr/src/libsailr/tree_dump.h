#include "node.h"

void tree_dump( TreeNode*, int );
char* rep_spaces( int );
