#ifndef VM_ASSIGN_H
#define VM_ASSIGN_H

#include "vm_stack.h"

int vm_stack_store_val(vm_stack* stack);

#endif
