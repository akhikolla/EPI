#ifndef VM_REXP_H
#define VM_REXP_H

#include "vm_stack.h"

int vm_rexp_match(vm_stack* vmstack);

#endif /* VM_REXP_H */
