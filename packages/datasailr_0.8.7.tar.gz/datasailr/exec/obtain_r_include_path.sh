#!/bin/sh

"${R_HOME}/bin/Rscript" -e "cat(R.home('include'))"
