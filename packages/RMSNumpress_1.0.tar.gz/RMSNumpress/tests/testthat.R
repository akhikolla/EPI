library(testthat)
library(RMSNumpress)

test_check("RMSNumpress")
