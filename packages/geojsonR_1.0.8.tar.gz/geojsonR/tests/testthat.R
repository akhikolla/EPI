library(testthat)
library(geojsonR)

test_check("geojsonR")
