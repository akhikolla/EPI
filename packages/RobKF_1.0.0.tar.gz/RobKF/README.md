# Robkf

An R package containing additive and/or innovative outlier robust Kalman filters. 
