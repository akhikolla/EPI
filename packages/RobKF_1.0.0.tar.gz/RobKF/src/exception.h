
#ifndef ___CAPA_EXCEPTION_H___
#define ___CAPA_EXCEPTION_H___

#include <string>

void throw_exception(const std::string&);

#endif
