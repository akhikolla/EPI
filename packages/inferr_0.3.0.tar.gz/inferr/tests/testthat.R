library(testthat)
library(inferr)

test_check("inferr")
