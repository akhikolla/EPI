# partialCI Version 1.2.0
- We fully rework test.pci. For details see test.pci manuel file
- We drop include.alpha for consistency reasons



# partialCI Version 1.1.1
- Replaced the Fast Kalman Filter (package: FKF) by the Kalman filter implementation of the package KFAS

