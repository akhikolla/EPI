library(testthat)
library(disclapmix)

test_check("disclapmix")
