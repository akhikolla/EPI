summary.npsf <- function( object, ... ) {
  class( object ) <- "summary.npsf"
  return( object )
}