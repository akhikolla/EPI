.onAttach <- function(libname, pkgname) {
  packageStartupMessage("If you installed Rlibeemd from CRAN, consider installing again from GitHub if you wish to support for parallel computations: https://github.com/helske/Rlibeemd.")
}