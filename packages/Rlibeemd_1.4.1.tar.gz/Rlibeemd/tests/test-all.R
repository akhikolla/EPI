library(testthat)
test_check("Rlibeemd")
