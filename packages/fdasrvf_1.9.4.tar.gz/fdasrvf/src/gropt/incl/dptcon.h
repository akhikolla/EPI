#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dptcon_(integer *n, doublereal *d__, doublereal *e, doublereal *anorm, doublereal *rcond, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
