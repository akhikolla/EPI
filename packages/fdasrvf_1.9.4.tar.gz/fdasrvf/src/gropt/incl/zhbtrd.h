#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zhbtrd_(char *vect, char *uplo, integer *n, integer *kd, doublecomplex *ab, integer *ldab, doublereal *d__, doublereal *e, doublecomplex *q, integer *ldq, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
