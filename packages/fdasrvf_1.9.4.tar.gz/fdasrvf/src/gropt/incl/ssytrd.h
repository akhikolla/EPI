#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssytrd_(char *uplo, integer *n, real *a, integer *lda, real *d__, real *e, real *tau, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
