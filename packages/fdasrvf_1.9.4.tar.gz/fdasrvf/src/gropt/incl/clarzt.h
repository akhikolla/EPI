#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clarzt_(char *direct, char *storev, integer *n, integer *k, complex *v, integer *ldv, complex *tau, complex *t, integer *ldt);

#ifdef __cplusplus
}
#endif
