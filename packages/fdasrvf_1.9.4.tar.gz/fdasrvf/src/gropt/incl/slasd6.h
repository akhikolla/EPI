#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slasd6_(integer *icompq, integer *nl, integer *nr, integer *sqre, real *d__, real *vf, real *vl, real *alpha, real *beta, integer *idxq, integer *perm, integer *givptr, integer *givcol, integer *ldgcol, real *givnum, integer *ldgnum, real *poles, real *difl, real *difr, real *z__, integer *k, real *c__, real *s, real *work, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif
