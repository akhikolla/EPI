#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dsytrf_(char *uplo, integer *n, doublereal *a, integer *lda, integer *ipiv, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
