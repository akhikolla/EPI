#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgecon_(char *norm, integer *n, real *a, integer *lda, real *anorm, real *rcond, real *work, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif
