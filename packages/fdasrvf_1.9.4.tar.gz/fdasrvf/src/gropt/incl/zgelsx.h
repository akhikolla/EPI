#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgelsx_(integer *m, integer *n, integer *nrhs, doublecomplex *a, integer *lda, doublecomplex *b, integer *ldb, integer *jpvt, doublereal *rcond, integer *rank, doublecomplex *work, doublereal *rwork, integer *info);

#ifdef __cplusplus
}
#endif
