#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgetc2_(integer *n, doublereal *a, integer *lda, integer *ipiv, integer *jpiv, integer *info);

#ifdef __cplusplus
}
#endif
