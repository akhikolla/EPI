#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csptrf_(char *uplo, integer *n, complex *ap, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif
