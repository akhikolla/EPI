#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgerc_(integer *m, integer *n, complex *alpha, complex *x, integer *incx, complex *y, integer *incy, complex *a, integer *lda);

#ifdef __cplusplus
}
#endif
