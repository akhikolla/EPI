#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int strevc_(char *side, char *howmny, logical *select, integer *n, real *t, integer *ldt, real *vl, integer *ldvl, real *vr, integer *ldvr, integer *mm, integer *m, real *work, integer *info);

#ifdef __cplusplus
}
#endif
