#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlapmt_(logical *forwrd, integer *m, integer *n, doublereal *x, integer *ldx, integer *k);

#ifdef __cplusplus
}
#endif
