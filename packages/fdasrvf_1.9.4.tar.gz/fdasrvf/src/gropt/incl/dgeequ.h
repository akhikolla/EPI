#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgeequ_(integer *m, integer *n, doublereal *a, integer *lda, doublereal *r__, doublereal *c__, doublereal *rowcnd, doublereal *colcnd, doublereal *amax, integer *info);

#ifdef __cplusplus
}
#endif
