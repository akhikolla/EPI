#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slarft_(char *direct, char *storev, integer *n, integer *k, real *v, integer *ldv, real *tau, real *t, integer *ldt);

#ifdef __cplusplus
}
#endif
