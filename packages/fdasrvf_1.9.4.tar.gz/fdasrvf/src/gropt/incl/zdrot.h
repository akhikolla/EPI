#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zdrot_(integer *n, doublecomplex *cx, integer *incx, doublecomplex *cy, integer *incy, doublereal *c__, doublereal *s);

#ifdef __cplusplus
}
#endif
