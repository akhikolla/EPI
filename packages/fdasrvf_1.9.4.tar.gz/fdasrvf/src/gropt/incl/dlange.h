#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dlange_(char *norm, integer *m, integer *n, doublereal *a, integer *lda, doublereal *work);

#ifdef __cplusplus
}
#endif
