#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zhetf2_(char *uplo, integer *n, doublecomplex *a, integer *lda, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif
