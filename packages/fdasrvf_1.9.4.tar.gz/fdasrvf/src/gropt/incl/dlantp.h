#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dlantp_(char *norm, char *uplo, char *diag, integer *n, doublereal *ap, doublereal *work);

#ifdef __cplusplus
}
#endif
