#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slasq5_(integer *i0, integer *n0, real *z__, integer *pp, real *tau, real *dmin__, real *dmin1, real *dmin2, real *dn, real *dnm1, real *dnm2, logical *ieee);

#ifdef __cplusplus
}
#endif
