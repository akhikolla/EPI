#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal zlansp_(char *norm, char *uplo, integer *n, doublecomplex *ap, doublereal *work);

#ifdef __cplusplus
}
#endif
