#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssygv_(integer *itype, char *jobz, char *uplo, integer *n, real *a, integer *lda, real *b, integer *ldb, real *w, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
