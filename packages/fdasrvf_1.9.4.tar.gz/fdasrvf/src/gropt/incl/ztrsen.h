#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ztrsen_(char *job, char *compq, logical *select, integer *n, doublecomplex *t, integer *ldt, doublecomplex *q, integer *ldq, doublecomplex *w, integer *m, doublereal *s, doublereal *sep, doublecomplex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
