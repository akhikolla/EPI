#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zherk_(char *uplo, char *trans, integer *n, integer *k, doublereal *alpha, doublecomplex *a, integer *lda, doublereal *beta, doublecomplex *c__, integer *ldc);

#ifdef __cplusplus
}
#endif
