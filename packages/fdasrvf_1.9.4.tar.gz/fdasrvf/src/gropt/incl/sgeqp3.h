#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgeqp3_(integer *m, integer *n, real *a, integer *lda, integer *jpvt, real *tau, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
