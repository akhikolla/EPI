#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int strsna_(char *job, char *howmny, logical *select, integer *n, real *t, integer *ldt, real *vl, integer *ldvl, real *vr, integer *ldvr, real *s, real *sep, integer *mm, integer *m, real *work, integer *ldwork, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif
