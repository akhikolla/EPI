#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dtrmv_(char *uplo, char *trans, char *diag, integer *n, doublereal *a, integer *lda, doublereal *x, integer *incx);

#ifdef __cplusplus
}
#endif
