#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlasd8_(integer *icompq, integer *k, doublereal *d__, doublereal *z__, doublereal *vf, doublereal *vl, doublereal *difl, doublereal *difr, integer *lddifr, doublereal *dsigma, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
