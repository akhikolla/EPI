#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlaqge_(integer *m, integer *n, doublecomplex *a, integer *lda, doublereal *r__, doublereal *c__, doublereal *rowcnd, doublereal *colcnd, doublereal *amax, char *equed);

#ifdef __cplusplus
}
#endif
