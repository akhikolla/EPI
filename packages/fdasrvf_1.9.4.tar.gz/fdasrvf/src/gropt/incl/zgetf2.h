#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgetf2_(integer *m, integer *n, doublecomplex *a, integer *lda, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif
