#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlarzt_(char *direct, char *storev, integer *n, integer *k, doublereal *v, integer *ldv, doublereal *tau, doublereal *t, integer *ldt);

#ifdef __cplusplus
}
#endif
