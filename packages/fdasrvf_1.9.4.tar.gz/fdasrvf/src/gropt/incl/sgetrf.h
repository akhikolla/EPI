#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgetrf_(integer *m, integer *n, real *a, integer *lda, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif
