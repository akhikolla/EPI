#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slarfg_(integer *n, real *alpha, real *x, integer *incx, real *tau);

#ifdef __cplusplus
}
#endif
