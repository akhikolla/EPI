#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slahqr_(logical *wantt, logical *wantz, integer *n, integer *ilo, integer *ihi, real *h__, integer *ldh, real *wr, real *wi, integer *iloz, integer *ihiz, real *z__, integer *ldz, integer *info);

#ifdef __cplusplus
}
#endif
