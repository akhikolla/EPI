#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slar2v_(integer *n, real *x, real *y, real *z__, integer *incx, real *c__, real *s, integer *incc);

#ifdef __cplusplus
}
#endif
