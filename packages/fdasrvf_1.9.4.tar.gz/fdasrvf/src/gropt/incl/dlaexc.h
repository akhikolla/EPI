#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaexc_(logical *wantq, integer *n, doublereal *t, integer *ldt, doublereal *q, integer *ldq, integer *j1, integer *n1, integer *n2, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
