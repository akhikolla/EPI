#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgebd2_(integer *m, integer *n, doublecomplex *a, integer *lda, doublereal *d__, doublereal *e, doublecomplex *tauq, doublecomplex *taup, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
