#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slaed5_(integer *i__, real *d__, real *z__, real *delta, real *rho, real *dlam);

#ifdef __cplusplus
}
#endif
