#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dopgtr_(char *uplo, integer *n, doublereal *ap, doublereal *tau, doublereal *q, integer *ldq, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
