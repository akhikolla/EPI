#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlar2v_(integer *n, doublereal *x, doublereal *y, doublereal *z__, integer *incx, doublereal *c__, doublereal *s, integer *incc);

#ifdef __cplusplus
}
#endif
