#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sppsv_(char *uplo, integer *n, integer *nrhs, real *ap, real *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
