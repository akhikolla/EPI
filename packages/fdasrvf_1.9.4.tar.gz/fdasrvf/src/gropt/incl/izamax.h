#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

integer izamax_(integer *n, doublecomplex *zx, integer *incx);

#ifdef __cplusplus
}
#endif
