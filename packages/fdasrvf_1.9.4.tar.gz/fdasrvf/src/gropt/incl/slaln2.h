#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slaln2_(logical *ltrans, integer *na, integer *nw, real *smin, real *ca, real *a, integer *lda, real *d1, real *d2, real *b, integer *ldb, real *wr, real *wi, real *x, integer *ldx, real *scale, real *xnorm, integer *info);

#ifdef __cplusplus
}
#endif
