#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal zlantb_(char *norm, char *uplo, char *diag, integer *n, integer *k, doublecomplex *ab, integer *ldab, doublereal *work);

#ifdef __cplusplus
}
#endif
