#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f slanhs_(char *norm, integer *n, real *a, integer *lda, real *work);

#ifdef __cplusplus
}
#endif
