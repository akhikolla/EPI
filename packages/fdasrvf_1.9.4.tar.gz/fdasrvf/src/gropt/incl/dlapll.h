#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlapll_(integer *n, doublereal *x, integer *incx, doublereal *y, integer *incy, doublereal *ssmin);

#ifdef __cplusplus
}
#endif
