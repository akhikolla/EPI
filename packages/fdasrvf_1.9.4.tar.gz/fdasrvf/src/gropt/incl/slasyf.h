#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slasyf_(char *uplo, integer *n, integer *nb, integer *kb, real *a, integer *lda, integer *ipiv, real *w, integer *ldw, integer *info);

#ifdef __cplusplus
}
#endif
