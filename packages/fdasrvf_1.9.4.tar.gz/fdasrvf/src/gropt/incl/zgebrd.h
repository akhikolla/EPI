#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgebrd_(integer *m, integer *n, doublecomplex *a, integer *lda, doublereal *d__, doublereal *e, doublecomplex *tauq, doublecomplex *taup, doublecomplex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
