#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sptsv_(integer *n, integer *nrhs, real *d__, real *e, real *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
