#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgtcon_(char *norm, integer *n, doublecomplex *dl, doublecomplex *d__, doublecomplex *du, doublecomplex *du2, integer *ipiv, doublereal *anorm, doublereal *rcond, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
