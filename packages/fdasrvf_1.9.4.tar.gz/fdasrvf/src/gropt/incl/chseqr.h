#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int chseqr_(char *job, char *compz, integer *n, integer *ilo, integer *ihi, complex *h__, integer *ldh, complex *w, complex *z__, integer *ldz, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
