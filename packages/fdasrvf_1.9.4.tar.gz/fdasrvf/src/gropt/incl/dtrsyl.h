#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dtrsyl_(char *trana, char *tranb, integer *isgn, integer *m, integer *n, doublereal *a, integer *lda, doublereal *b, integer *ldb, doublereal *c__, integer *ldc, doublereal *scale, integer *info);

#ifdef __cplusplus
}
#endif
