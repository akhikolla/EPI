#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlabad_(doublereal *small, doublereal *large);

#ifdef __cplusplus
}
#endif
