#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int stpsv_(char *uplo, char *trans, char *diag, integer *n, real *ap, real *x, integer *incx);

#ifdef __cplusplus
}
#endif
