#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgetri_(integer *n, doublecomplex *a, integer *lda, integer *ipiv, doublecomplex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
