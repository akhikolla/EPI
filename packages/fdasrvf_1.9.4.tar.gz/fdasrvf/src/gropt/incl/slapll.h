#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slapll_(integer *n, real *x, integer *incx, real *y, integer *incy, real *ssmin);

#ifdef __cplusplus
}
#endif
