#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgbsv_(integer *n, integer *kl, integer *ku, integer *nrhs, real *ab, integer *ldab, integer *ipiv, real *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
