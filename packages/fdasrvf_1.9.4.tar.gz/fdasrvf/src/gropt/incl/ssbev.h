#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssbev_(char *jobz, char *uplo, integer *n, integer *kd, real *ab, integer *ldab, real *w, real *z__, integer *ldz, real *work, integer *info);

#ifdef __cplusplus
}
#endif
