#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlatps_(char *uplo, char *trans, char *diag, char *normin, integer *n, doublecomplex *ap, doublecomplex *x, doublereal *scale, doublereal *cnorm, integer *info);

#ifdef __cplusplus
}
#endif
