#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int strexc_(char *compq, integer *n, real *t, integer *ldt, real *q, integer *ldq, integer *ifst, integer *ilst, real *work, integer *info);

#ifdef __cplusplus
}
#endif
