#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dpotrf_(char *uplo, integer *n, doublereal *a, integer *lda, integer *info);

#ifdef __cplusplus
}
#endif
