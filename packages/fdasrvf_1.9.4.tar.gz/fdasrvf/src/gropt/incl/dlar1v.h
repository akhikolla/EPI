#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlar1v_(integer *n, integer *b1, integer *bn, doublereal *sigma, doublereal *d__, doublereal *l, doublereal *ld, doublereal *lld, doublereal *gersch, doublereal *z__, doublereal *ztz, doublereal *mingma, integer *r__, integer *isuppz, doublereal *work);

#ifdef __cplusplus
}
#endif
