#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaruv_(integer *iseed, integer *n, doublereal *x);

#ifdef __cplusplus
}
#endif
