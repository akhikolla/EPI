#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slag2_(real *a, integer *lda, real *b, integer *ldb, real *safmin, real *scale1, real *scale2, real *wr1, real *wr2, real *wi);

#ifdef __cplusplus
}
#endif
