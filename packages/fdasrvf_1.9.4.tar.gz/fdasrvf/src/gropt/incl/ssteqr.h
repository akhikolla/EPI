#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssteqr_(char *compz, integer *n, real *d__, real *e, real *z__, integer *ldz, real *work, integer *info);

#ifdef __cplusplus
}
#endif
