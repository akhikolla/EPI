#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlasr_(char *side, char *pivot, char *direct, integer *m, integer *n, doublereal *c__, doublereal *s, doublereal *a, integer *lda);

#ifdef __cplusplus
}
#endif
