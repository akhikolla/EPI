#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ctgsna_(char *job, char *howmny, logical *select, integer *n, complex *a, integer *lda, complex *b, integer *ldb, complex *vl, integer *ldvl, complex *vr, integer *ldvr, real *s, real *dif, integer *mm, integer *m, complex *work, integer *lwork, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif
