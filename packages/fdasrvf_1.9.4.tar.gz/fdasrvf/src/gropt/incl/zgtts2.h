#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgtts2_(integer *itrans, integer *n, integer *nrhs, doublecomplex *dl, doublecomplex *d__, doublecomplex *du, doublecomplex *du2, integer *ipiv, doublecomplex *b, integer *ldb);

#ifdef __cplusplus
}
#endif
