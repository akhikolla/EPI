#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dsytd2_(char *uplo, integer *n, doublereal *a, integer *lda, doublereal *d__, doublereal *e, doublereal *tau, integer *info);

#ifdef __cplusplus
}
#endif
