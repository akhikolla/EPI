#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int saxpy_(integer *n, real *sa, real *sx, integer *incx, real *sy, integer *incy);

#ifdef __cplusplus
}
#endif
