#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int classq_(integer *n, complex *x, integer *incx, real *scale, real *sumsq);

#ifdef __cplusplus
}
#endif
