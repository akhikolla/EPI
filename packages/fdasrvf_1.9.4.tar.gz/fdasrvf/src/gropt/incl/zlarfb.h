#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlarfb_(char *side, char *trans, char *direct, char *storev, integer *m, integer *n, integer *k, doublecomplex *v, integer *ldv, doublecomplex *t, integer *ldt, doublecomplex *c__, integer *ldc, doublecomplex *work, integer *ldwork);

#ifdef __cplusplus
}
#endif
