#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dppequ_(char *uplo, integer *n, doublereal *ap, doublereal *s, doublereal *scond, doublereal *amax, integer *info);

#ifdef __cplusplus
}
#endif
