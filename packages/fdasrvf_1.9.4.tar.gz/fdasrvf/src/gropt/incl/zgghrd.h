#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgghrd_(char *compq, char *compz, integer *n, integer *ilo, integer *ihi, doublecomplex *a, integer *lda, doublecomplex *b, integer *ldb, doublecomplex *q, integer *ldq, doublecomplex *z__, integer *ldz, integer *info);

#ifdef __cplusplus
}
#endif
