#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sorg2r_(integer *m, integer *n, integer *k, real *a, integer *lda, real *tau, real *work, integer *info);

#ifdef __cplusplus
}
#endif
