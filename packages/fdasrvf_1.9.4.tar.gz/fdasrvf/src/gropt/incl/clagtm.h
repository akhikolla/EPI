#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clagtm_(char *trans, integer *n, integer *nrhs, real *alpha, complex *dl, complex *d__, complex *du, complex *x, integer *ldx, real *beta, complex *b, integer *ldb);

#ifdef __cplusplus
}
#endif
