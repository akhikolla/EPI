#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgbbrd_(char *vect, integer *m, integer *n, integer *ncc, integer *kl, integer *ku, real *ab, integer *ldab, real *d__, real *e, real *q, integer *ldq, real *pt, integer *ldpt, real *c__, integer *ldc, real *work, integer *info);

#ifdef __cplusplus
}
#endif
