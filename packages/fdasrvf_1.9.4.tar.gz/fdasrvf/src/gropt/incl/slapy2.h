#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f slapy2_(real *x, real *y);

#ifdef __cplusplus
}
#endif
