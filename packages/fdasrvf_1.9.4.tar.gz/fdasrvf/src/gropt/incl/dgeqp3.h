#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgeqp3_(integer *m, integer *n, doublereal *a, integer *lda, integer *jpvt, doublereal *tau, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
