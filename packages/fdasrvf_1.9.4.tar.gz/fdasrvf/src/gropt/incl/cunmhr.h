#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cunmhr_(char *side, char *trans, integer *m, integer *n, integer *ilo, integer *ihi, complex *a, integer *lda, complex *tau, complex *c__, integer *ldc, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
