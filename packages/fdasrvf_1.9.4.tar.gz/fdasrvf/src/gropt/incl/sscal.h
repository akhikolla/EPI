#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sscal_(integer *n, real *sa, real *sx, integer *incx);

#ifdef __cplusplus
}
#endif
