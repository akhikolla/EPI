#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zhptrs_(char *uplo, integer *n, integer *nrhs, doublecomplex *ap, integer *ipiv, doublecomplex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
