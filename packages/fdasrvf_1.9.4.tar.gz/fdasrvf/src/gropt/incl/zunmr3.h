#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zunmr3_(char *side, char *trans, integer *m, integer *n, integer *k, integer *l, doublecomplex *a, integer *lda, doublecomplex *tau, doublecomplex *c__, integer *ldc, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
