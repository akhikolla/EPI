#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dsbgv_(char *jobz, char *uplo, integer *n, integer *ka, integer *kb, doublereal *ab, integer *ldab, doublereal *bb, integer *ldbb, doublereal *w, doublereal *z__, integer *ldz, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
