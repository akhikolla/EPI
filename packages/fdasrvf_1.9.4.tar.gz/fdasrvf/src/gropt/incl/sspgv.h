#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sspgv_(integer *itype, char *jobz, char *uplo, integer *n, real *ap, real *bp, real *w, real *z__, integer *ldz, real *work, integer *info);

#ifdef __cplusplus
}
#endif
