#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dsytf2_(char *uplo, integer *n, doublereal *a, integer *lda, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif
