#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int chpgv_(integer *itype, char *jobz, char *uplo, integer *n, complex *ap, complex *bp, real *w, complex *z__, integer *ldz, complex *work, real *rwork, integer *info);

#ifdef __cplusplus
}
#endif
