#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dptts2_(integer *n, integer *nrhs, doublereal *d__, doublereal *e, doublereal *b, integer *ldb);

#ifdef __cplusplus
}
#endif
