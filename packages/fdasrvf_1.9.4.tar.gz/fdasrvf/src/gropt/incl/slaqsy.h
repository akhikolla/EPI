#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slaqsy_(char *uplo, integer *n, real *a, integer *lda, real *s, real *scond, real *amax, char *equed);

#ifdef __cplusplus
}
#endif
