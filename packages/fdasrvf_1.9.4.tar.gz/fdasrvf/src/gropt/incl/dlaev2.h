#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlaev2_(doublereal *a, doublereal *b, doublereal *c__, doublereal *rt1, doublereal *rt2, doublereal *cs1, doublereal *sn1);

#ifdef __cplusplus
}
#endif
