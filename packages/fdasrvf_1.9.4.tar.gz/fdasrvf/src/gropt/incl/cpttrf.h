#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cpttrf_(integer *n, real *d__, complex *e, integer *info);

#ifdef __cplusplus
}
#endif
