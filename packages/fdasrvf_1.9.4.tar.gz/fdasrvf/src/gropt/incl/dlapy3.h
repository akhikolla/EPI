#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dlapy3_(doublereal *x, doublereal *y, doublereal *z__);

#ifdef __cplusplus
}
#endif
