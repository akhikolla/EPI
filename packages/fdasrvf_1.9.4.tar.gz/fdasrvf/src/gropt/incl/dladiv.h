#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dladiv_(doublereal *a, doublereal *b, doublereal *c__, doublereal *d__, doublereal *p, doublereal *q);

#ifdef __cplusplus
}
#endif
