#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sstein_(integer *n, real *d__, real *e, integer *m, real *w, integer *iblock, integer *isplit, real *z__, integer *ldz, real *work, integer *iwork, integer *ifail, integer *info);

#ifdef __cplusplus
}
#endif
