#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zhpr2_(char *uplo, integer *n, doublecomplex *alpha, doublecomplex *x, integer *incx, doublecomplex *y, integer *incy, doublecomplex *ap);

#ifdef __cplusplus
}
#endif
