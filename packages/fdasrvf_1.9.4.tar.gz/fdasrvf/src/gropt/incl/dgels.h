#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgels_(char *trans, integer *m, integer *n, integer *nrhs, doublereal *a, integer *lda, doublereal *b, integer *ldb, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
