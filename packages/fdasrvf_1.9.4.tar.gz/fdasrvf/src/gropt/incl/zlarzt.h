#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlarzt_(char *direct, char *storev, integer *n, integer *k, doublecomplex *v, integer *ldv, doublecomplex *tau, doublecomplex *t, integer *ldt);

#ifdef __cplusplus
}
#endif
