#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int stzrqf_(integer *m, integer *n, real *a, integer *lda, real *tau, integer *info);

#ifdef __cplusplus
}
#endif
