#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int stptri_(char *uplo, char *diag, integer *n, real *ap, integer *info);

#ifdef __cplusplus
}
#endif
