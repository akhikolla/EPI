#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgglse_(integer *m, integer *n, integer *p, real *a, integer *lda, real *b, integer *ldb, real *c__, real *d__, real *x, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
