#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dpbtrf_(char *uplo, integer *n, integer *kd, doublereal *ab, integer *ldab, integer *info);

#ifdef __cplusplus
}
#endif
