#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dlangt_(char *norm, integer *n, doublereal *dl, doublereal *d__, doublereal *du);

#ifdef __cplusplus
}
#endif
