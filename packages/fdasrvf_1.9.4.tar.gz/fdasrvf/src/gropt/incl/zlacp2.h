#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlacp2_(char *uplo, integer *m, integer *n, doublereal *a, integer *lda, doublecomplex *b, integer *ldb);

#ifdef __cplusplus
}
#endif
