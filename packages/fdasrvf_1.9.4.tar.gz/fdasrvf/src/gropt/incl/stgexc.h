#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int stgexc_(logical *wantq, logical *wantz, integer *n, real *a, integer *lda, real *b, integer *ldb, real *q, integer *ldq, real *z__, integer *ldz, integer *ifst, integer *ilst, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
