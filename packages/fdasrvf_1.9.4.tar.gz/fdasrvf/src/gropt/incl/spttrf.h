#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int spttrf_(integer *n, real *d__, real *e, integer *info);

#ifdef __cplusplus
}
#endif
