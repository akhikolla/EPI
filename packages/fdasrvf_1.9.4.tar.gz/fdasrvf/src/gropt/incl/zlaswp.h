#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlaswp_(integer *n, doublecomplex *a, integer *lda, integer *k1, integer *k2, integer *ipiv, integer *incx);

#ifdef __cplusplus
}
#endif
