#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dormr3_(char *side, char *trans, integer *m, integer *n, integer *k, integer *l, doublereal *a, integer *lda, doublereal *tau, doublereal *c__, integer *ldc, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
