#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgghrd_(char *compq, char *compz, integer *n, integer *ilo, integer *ihi, real *a, integer *lda, real *b, integer *ldb, real *q, integer *ldq, real *z__, integer *ldz, integer *info);

#ifdef __cplusplus
}
#endif
