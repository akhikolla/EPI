#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int spbequ_(char *uplo, integer *n, integer *kd, real *ab, integer *ldab, real *s, real *scond, real *amax, integer *info);

#ifdef __cplusplus
}
#endif
