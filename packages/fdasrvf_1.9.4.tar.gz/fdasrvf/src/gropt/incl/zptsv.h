#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zptsv_(integer *n, integer *nrhs, doublereal *d__, doublecomplex *e, doublecomplex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
