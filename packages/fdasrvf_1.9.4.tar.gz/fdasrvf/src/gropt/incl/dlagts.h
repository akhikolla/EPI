#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlagts_(integer *job, integer *n, doublereal *a, doublereal *b, doublereal *c__, doublereal *d__, integer *in, doublereal *y, doublereal *tol, integer *info);

#ifdef __cplusplus
}
#endif
