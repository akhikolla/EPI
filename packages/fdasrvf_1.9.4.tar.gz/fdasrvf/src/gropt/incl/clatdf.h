#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clatdf_(integer *ijob, integer *n, complex *z__, integer *ldz, complex *rhs, real *rdsum, real *rdscal, integer *ipiv, integer *jpiv);

#ifdef __cplusplus
}
#endif
