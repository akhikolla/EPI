#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgelq2_(integer *m, integer *n, doublecomplex *a, integer *lda, doublecomplex *tau, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
