#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlae2_(doublereal *a, doublereal *b, doublereal *c__, doublereal *rt1, doublereal *rt2);

#ifdef __cplusplus
}
#endif
