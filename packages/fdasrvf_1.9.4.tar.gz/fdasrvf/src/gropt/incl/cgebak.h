#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cgebak_(char *job, char *side, integer *n, integer *ilo, integer *ihi, real *scale, integer *m, complex *v, integer *ldv, integer *info);

#ifdef __cplusplus
}
#endif
