#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlahqr_(logical *wantt, logical *wantz, integer *n, integer *ilo, integer *ihi, doublereal *h__, integer *ldh, doublereal *wr, doublereal *wi, integer *iloz, integer *ihiz, doublereal *z__, integer *ldz, integer *info);

#ifdef __cplusplus
}
#endif
