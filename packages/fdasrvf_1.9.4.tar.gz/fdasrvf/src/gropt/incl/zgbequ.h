#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgbequ_(integer *m, integer *n, integer *kl, integer *ku, doublecomplex *ab, integer *ldab, doublereal *r__, doublereal *c__, doublereal *rowcnd, doublereal *colcnd, doublereal *amax, integer *info);

#ifdef __cplusplus
}
#endif
