#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zhptri_(char *uplo, integer *n, doublecomplex *ap, integer *ipiv, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
