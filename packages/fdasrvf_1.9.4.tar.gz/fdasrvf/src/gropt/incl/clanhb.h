#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f clanhb_(char *norm, char *uplo, integer *n, integer *k, complex *ab, integer *ldab, real *work);

#ifdef __cplusplus
}
#endif
