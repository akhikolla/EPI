#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zggrqf_(integer *m, integer *p, integer *n, doublecomplex *a, integer *lda, doublecomplex *taua, doublecomplex *b, integer *ldb, doublecomplex *taub, doublecomplex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
