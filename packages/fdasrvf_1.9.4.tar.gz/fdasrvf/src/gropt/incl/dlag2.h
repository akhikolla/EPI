#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlag2_(doublereal *a, integer *lda, doublereal *b, integer *ldb, doublereal *safmin, doublereal *scale1, doublereal *scale2, doublereal *wr1, doublereal *wr2, doublereal *wi);

#ifdef __cplusplus
}
#endif
