#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dpbtrs_(char *uplo, integer *n, integer *kd, integer *nrhs, doublereal *ab, integer *ldab, doublereal *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
