#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int clacrm_(integer *m, integer *n, complex *a, integer *lda, real *b, integer *ldb, complex *c__, integer *ldc, real *rwork);

#ifdef __cplusplus
}
#endif
