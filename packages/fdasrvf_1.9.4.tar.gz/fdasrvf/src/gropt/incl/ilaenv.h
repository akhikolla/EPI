#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

integer ilaenv_(integer *ispec, char *name__, char *opts, integer *n1, integer *n2, integer *n3, integer *n4);

#ifdef __cplusplus
}
#endif
