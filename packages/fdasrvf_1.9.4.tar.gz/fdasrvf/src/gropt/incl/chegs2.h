#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int chegs2_(integer *itype, char *uplo, integer *n, complex *a, integer *lda, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
