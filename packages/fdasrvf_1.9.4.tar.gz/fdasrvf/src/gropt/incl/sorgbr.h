#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sorgbr_(char *vect, integer *m, integer *n, integer *k, real *a, integer *lda, real *tau, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
