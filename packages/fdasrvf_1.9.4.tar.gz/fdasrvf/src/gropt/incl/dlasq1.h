#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlasq1_(integer *n, doublereal *d__, doublereal *e, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
