#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlatdf_(integer *ijob, integer *n, doublecomplex *z__, integer *ldz, doublecomplex *rhs, doublereal *rdsum, doublereal *rdscal, integer *ipiv, integer *jpiv);

#ifdef __cplusplus
}
#endif
