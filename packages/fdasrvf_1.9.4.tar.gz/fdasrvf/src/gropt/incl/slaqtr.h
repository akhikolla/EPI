#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slaqtr_(logical *ltran, logical *lreal, integer *n, real *t, integer *ldt, real *b, real *w, real *scale, real *x, real *work, integer *info);

#ifdef __cplusplus
}
#endif
