#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int csytrf_(char *uplo, integer *n, complex *a, integer *lda, integer *ipiv, complex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
