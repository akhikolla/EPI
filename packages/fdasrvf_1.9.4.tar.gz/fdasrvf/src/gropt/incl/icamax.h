#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

integer icamax_(integer *n, complex *cx, integer *incx);

#ifdef __cplusplus
}
#endif
