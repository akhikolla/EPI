#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssptri_(char *uplo, integer *n, real *ap, integer *ipiv, real *work, integer *info);

#ifdef __cplusplus
}
#endif
