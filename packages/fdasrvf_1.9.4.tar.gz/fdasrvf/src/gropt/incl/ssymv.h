#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssymv_(char *uplo, integer *n, real *alpha, real *a, integer *lda, real *x, integer *incx, real *beta, real *y, integer *incy);

#ifdef __cplusplus
}
#endif
