#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int spptri_(char *uplo, integer *n, real *ap, integer *info);

#ifdef __cplusplus
}
#endif
