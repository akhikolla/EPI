#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f slapy3_(real *x, real *y, real *z__);

#ifdef __cplusplus
}
#endif
