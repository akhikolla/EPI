#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dlacpy_(char *uplo, integer *m, integer *n, doublereal *a, integer *lda, doublereal *b, integer *ldb);

#ifdef __cplusplus
}
#endif
