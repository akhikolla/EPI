#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dlanst_(char *norm, integer *n, doublereal *d__, doublereal *e);

#ifdef __cplusplus
}
#endif
