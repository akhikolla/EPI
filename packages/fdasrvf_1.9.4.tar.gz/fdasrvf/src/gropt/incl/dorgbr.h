#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dorgbr_(char *vect, integer *m, integer *n, integer *k, doublereal *a, integer *lda, doublereal *tau, doublereal *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
