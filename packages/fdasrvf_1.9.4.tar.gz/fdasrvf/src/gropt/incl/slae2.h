#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slae2_(real *a, real *b, real *c__, real *rt1, real *rt2);

#ifdef __cplusplus
}
#endif
