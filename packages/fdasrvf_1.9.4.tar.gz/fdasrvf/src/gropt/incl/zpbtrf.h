#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zpbtrf_(char *uplo, integer *n, integer *kd, doublecomplex *ab, integer *ldab, integer *info);

#ifdef __cplusplus
}
#endif
