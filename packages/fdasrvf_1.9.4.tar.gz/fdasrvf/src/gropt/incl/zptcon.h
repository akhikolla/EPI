#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zptcon_(integer *n, doublereal *d__, doublecomplex *e, doublereal *anorm, doublereal *rcond, doublereal *rwork, integer *info);

#ifdef __cplusplus
}
#endif
