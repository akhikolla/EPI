#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlaqps_(integer *m, integer *n, integer *offset, integer *nb, integer *kb, doublecomplex *a, integer *lda, integer *jpvt, doublecomplex *tau, doublereal *vn1, doublereal *vn2, doublecomplex *auxv, doublecomplex *f, integer *ldf);

#ifdef __cplusplus
}
#endif
