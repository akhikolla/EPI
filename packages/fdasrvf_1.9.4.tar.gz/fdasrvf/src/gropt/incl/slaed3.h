#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slaed3_(integer *k, integer *n, integer *n1, real *d__, real *q, integer *ldq, real *rho, real *dlamda, real *q2, integer *indx, integer *ctot, real *w, real *s, integer *info);

#ifdef __cplusplus
}
#endif
