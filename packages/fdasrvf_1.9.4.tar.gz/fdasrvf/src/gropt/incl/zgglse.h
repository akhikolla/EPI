#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgglse_(integer *m, integer *n, integer *p, doublecomplex *a, integer *lda, doublecomplex *b, integer *ldb, doublecomplex *c__, doublecomplex *d__, doublecomplex *x, doublecomplex *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
