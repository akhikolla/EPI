#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int chetrs_(char *uplo, integer *n, integer *nrhs, complex *a, integer *lda, integer *ipiv, complex *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
