#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zupmtr_(char *side, char *uplo, char *trans, integer *m, integer *n, doublecomplex *ap, doublecomplex *tau, doublecomplex *c__, integer *ldc, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
