#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f slansp_(char *norm, char *uplo, integer *n, real *ap, real *work);

#ifdef __cplusplus
}
#endif
