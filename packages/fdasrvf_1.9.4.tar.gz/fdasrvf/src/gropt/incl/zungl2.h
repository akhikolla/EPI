#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zungl2_(integer *m, integer *n, integer *k, doublecomplex *a, integer *lda, doublecomplex *tau, doublecomplex *work, integer *info);

#ifdef __cplusplus
}
#endif
