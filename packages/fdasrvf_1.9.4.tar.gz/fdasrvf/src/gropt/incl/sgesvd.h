#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sgesvd_(char *jobu, char *jobvt, integer *m, integer *n, real *a, integer *lda, real *s, real *u, integer *ldu, real *vt, integer *ldvt, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
