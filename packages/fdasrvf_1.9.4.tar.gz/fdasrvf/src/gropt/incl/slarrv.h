#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slarrv_(integer *n, real *d__, real *l, integer *isplit, integer *m, real *w, integer *iblock, real *gersch, real *tol, real *z__, integer *ldz, integer *isuppz, real *work, integer *iwork, integer *info);

#ifdef __cplusplus
}
#endif
