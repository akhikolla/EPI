#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slasd8_(integer *icompq, integer *k, real *d__, real *z__, real *vf, real *vl, real *difl, real *difr, integer *lddifr, real *dsigma, real *work, integer *info);

#ifdef __cplusplus
}
#endif
