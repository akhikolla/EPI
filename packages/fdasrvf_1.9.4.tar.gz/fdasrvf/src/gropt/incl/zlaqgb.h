#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlaqgb_(integer *m, integer *n, integer *kl, integer *ku, doublecomplex *ab, integer *ldab, doublereal *r__, doublereal *c__, doublereal *rowcnd, doublereal *colcnd, doublereal *amax, char *equed);

#ifdef __cplusplus
}
#endif
