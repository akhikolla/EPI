#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f slantp_(char *norm, char *uplo, char *diag, integer *n, real *ap, real *work);

#ifdef __cplusplus
}
#endif
