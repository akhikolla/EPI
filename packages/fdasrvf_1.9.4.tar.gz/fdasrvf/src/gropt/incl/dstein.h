#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dstein_(integer *n, doublereal *d__, doublereal *e, integer *m, doublereal *w, integer *iblock, integer *isplit, doublereal *z__, integer *ldz, doublereal *work, integer *iwork, integer *ifail, integer *info);

#ifdef __cplusplus
}
#endif
