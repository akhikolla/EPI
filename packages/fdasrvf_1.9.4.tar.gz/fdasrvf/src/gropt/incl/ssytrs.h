#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssytrs_(char *uplo, integer *n, integer *nrhs, real *a, integer *lda, integer *ipiv, real *b, integer *ldb, integer *info);

#ifdef __cplusplus
}
#endif
