#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

integer izmax1_(integer *n, doublecomplex *cx, integer *incx);

#ifdef __cplusplus
}
#endif
