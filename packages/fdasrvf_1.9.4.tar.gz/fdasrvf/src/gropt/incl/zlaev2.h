#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zlaev2_(doublecomplex *a, doublecomplex *b, doublecomplex *c__, doublereal *rt1, doublereal *rt2, doublereal *cs1, doublecomplex *sn1);

#ifdef __cplusplus
}
#endif
