#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slaqge_(integer *m, integer *n, real *a, integer *lda, real *r__, real *c__, real *rowcnd, real *colcnd, real *amax, char *equed);

#ifdef __cplusplus
}
#endif
