#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int sormtr_(char *side, char *uplo, char *trans, integer *m, integer *n, real *a, integer *lda, real *tau, real *c__, integer *ldc, real *work, integer *lwork, integer *info);

#ifdef __cplusplus
}
#endif
