#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dorg2r_(integer *m, integer *n, integer *k, doublereal *a, integer *lda, doublereal *tau, doublereal *work, integer *info);

#ifdef __cplusplus
}
#endif
