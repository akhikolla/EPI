#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dgttrf_(integer *n, doublereal *dl, doublereal *d__, doublereal *du, doublereal *du2, integer *ipiv, integer *info);

#ifdef __cplusplus
}
#endif
