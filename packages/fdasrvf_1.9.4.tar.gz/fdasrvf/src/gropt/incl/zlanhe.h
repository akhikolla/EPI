#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal zlanhe_(char *norm, char *uplo, integer *n, doublecomplex *a, integer *lda, doublereal *work);

#ifdef __cplusplus
}
#endif
