#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int slabad_(real *small, real *large);

#ifdef __cplusplus
}
#endif
