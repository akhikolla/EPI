#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f slantb_(char *norm, char *uplo, char *diag, integer *n, integer *k, real *ab, integer *ldab, real *work);

#ifdef __cplusplus
}
#endif
