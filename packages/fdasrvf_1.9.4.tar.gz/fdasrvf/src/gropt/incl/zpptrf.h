#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zpptrf_(char *uplo, integer *n, doublecomplex *ap, integer *info);

#ifdef __cplusplus
}
#endif
