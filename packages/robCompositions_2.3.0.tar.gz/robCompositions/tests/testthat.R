library(testthat)
library(robCompositions)

test_check("robCompositions")
