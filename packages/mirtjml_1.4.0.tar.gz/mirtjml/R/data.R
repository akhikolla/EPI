#' Simulated dataset for item factor analysis on the multidimensional two parameter logistic model.
#' 
#' The dataset contains the simulation setting and the response data.
"data_sim"