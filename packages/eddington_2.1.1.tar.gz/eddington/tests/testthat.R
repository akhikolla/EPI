library(testthat)
library(eddington)

test_check("eddington")
