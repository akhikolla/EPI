## Changes in spectralGraphTopology version 0.2.0 (2019-10-07)

* Added state of the art algorithms (CGL, GLE-MM, and GLE-ADMM) for learning connected graphs.

## Changes in spectralGraphTopology version 0.1.1 (2019-05-31)

* Minor changes in the DESCRIPTION file to conform with CRAN.


## Changes in spectralGraphTopology version 0.1.0 (2019-05-08)

* Initial release is on CRAN.
