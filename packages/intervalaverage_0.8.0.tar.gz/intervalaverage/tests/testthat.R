library(testthat)
library(intervalaverage)

test_check("intervalaverage")
