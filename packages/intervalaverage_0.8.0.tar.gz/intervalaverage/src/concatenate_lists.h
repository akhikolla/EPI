#include <Rcpp.h>
using namespace Rcpp;

extern "C++" List concatenate_lists(List, List) ;
