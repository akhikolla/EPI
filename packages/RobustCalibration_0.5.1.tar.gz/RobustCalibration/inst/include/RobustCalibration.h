/*
// RobustCalibration.h
//  Mengyang Gu, February 2018
//
*/

#ifndef _robustcalibration_ctools_H
#define _robustcalibration_ctools_H
#include <RcppEigen.h>

using namespace Rcpp;
using namespace Eigen;
using namespace std;

//using      Rcpp::List;

RcppExport SEXP check_openmp();

#endif
