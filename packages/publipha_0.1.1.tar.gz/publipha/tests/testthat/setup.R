wrap <- function(x) suppressWarnings(capture_output(x))
