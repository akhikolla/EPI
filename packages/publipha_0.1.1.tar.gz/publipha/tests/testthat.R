library(testthat)
library(publipha)

test_check("publipha")
