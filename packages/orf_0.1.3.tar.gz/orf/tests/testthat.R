library(testthat)
library(orf)

test_check("orf")
