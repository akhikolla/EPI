library(testthat)
library(neuroim)

test_check("neuroim")