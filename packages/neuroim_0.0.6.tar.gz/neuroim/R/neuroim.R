#'
#' @title neuroim
#' @description Data structures for analysis of neuroimaging data.
#' 
#' @useDynLib neuroim
#' @importFrom Rcpp evalCpp
#' 
#' @docType package
#' @name neuroim
#' @details none
NULL