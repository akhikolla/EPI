#' @importFrom(Rcpp, evalCpp)
#' @useDynLib(porridge)
#' @exportPattern("^[[:alpha:]]+")
#' @details
#' We all live in a yellow submarine.. 
"_PACKAGE" 
