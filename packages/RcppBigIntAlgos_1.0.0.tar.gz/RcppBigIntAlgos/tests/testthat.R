library(testthat)
library(RcppBigIntAlgos)

test_check("RcppBigIntAlgos")
