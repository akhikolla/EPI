.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome to mousetrap 3.1.5!")
  packageStartupMessage("Summary of recent changes: http://pascalkieslich.github.io/mousetrap/news/")
  packageStartupMessage("Forum for questions: https://forum.cogsci.nl/index.php?p=/categories/mousetrap")
}
