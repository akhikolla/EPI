#' @useDynLib mousetrap, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL