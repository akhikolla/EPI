utils::globalVariables(c("robust.binomial.prefit","robust.gamma.prefit","robust.gaussian.prefit","robust.poisson.prefit","robust.truncpoisson.prefit"))
utils::globalVariables(c("robust.nbinom.prefit","gaussian.outlierTest.robmixglm","truncpoisson.mle2","gaussian.fun","gaussian.rg"))
utils::globalVariables(c("nbinom","nbinom.mle","offset","negbin.mle","nbinom.mle2"))
