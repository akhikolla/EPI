library(testthat)
library(plac)

test_check("plac")
