library(testthat)
library(dexterMST)

test_check("dexterMST")
