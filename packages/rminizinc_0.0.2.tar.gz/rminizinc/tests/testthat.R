library(testthat)
library(rminizinc)

test_check("rminizinc")