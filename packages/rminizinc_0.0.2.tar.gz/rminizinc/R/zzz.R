#' @description
#' Load the required libraries used by 
#' most of the functions and classes
#' @importFrom R6 R6Class
#' @import checkmate
#' @importFrom  rlang env
"_PACKAGE"
