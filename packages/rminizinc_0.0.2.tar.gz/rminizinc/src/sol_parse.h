#include<Rcpp.h>

Rcpp::List sol_parse(std::string solutionString);


