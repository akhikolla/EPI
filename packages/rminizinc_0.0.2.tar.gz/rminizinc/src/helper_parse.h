#include <Rcpp.h>

using namespace std;

string filetoString(string filepath);
string pathStringcheck(string modelString, string mznpath);
int dirExists(const char* const path);
