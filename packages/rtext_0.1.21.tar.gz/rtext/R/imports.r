#' @importFrom R6 R6Class
#' @import hellno
#' @import stringb
#' @useDynLib rtext
#' @importFrom Rcpp sourceCpp
NULL

#' magrittr pipe
#' @importFrom magrittr %>%
#' @name %>%
#' @rdname pipe
#' @keywords internal
#' @export
#' @importFrom magrittr %>%
NULL
