#' prometheus early version
#' @source https://de.wikisource.org/w/index.php?title=Prometheus_(Gedicht,_fr%C3%BChe_Fassung)&oldid=2105646
"prometheus_early"

#' prometheus late version
#' @source https://de.wikisource.org/w/index.php?title=Prometheus_(Gedicht,_sp%C3%A4te_Fassung)&oldid=1479587
"prometheus_late"
