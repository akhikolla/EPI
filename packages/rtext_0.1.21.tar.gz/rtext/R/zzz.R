 # function executet on loading the package
 #.onLoad <- function(libname, pkgname) {
   #packageStartupMessage("Please cite in any publication as:")
   #library(stringb)
#}
