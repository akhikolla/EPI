prometheus_late <-
"
Johann Wolfgang von Goethe

\"Prometheus\"

Bedecke deinen Himmel, Zeus,
Mit Wolkendunst,
Und \u00FCbe, dem Knaben gleich,
Der Disteln k\u00F6pft,
An Eichen dich und Bergesh\u00F6hn;
M\u00FC\u00DFt mir meine Erde
Doch lassen stehn,
Und meine H\u00FCtte, die du nicht gebaut,
Und meinen Herd,
Um dessen Gluth
Du mich beneidest.

Ich kenne nichts Aermeres
Unter der Sonn', als euch, G\u00F6tter!
Ihr n\u00E4hret k\u00FCmmerlich
Von Opfersteuern
Und Gebetshauch
Eure Majest\u00E4t,
Und darbtet, w\u00E4ren
Nicht Kinder und Bettler
Hoffnungsvolle Thoren.

Da ich ein Kind war,
Nicht wu\u00DFte wo aus noch ein,
Kehrt' ich mein verirrtes Auge
Zur Sonne, als wenn dr\u00FCber w\u00E4r'
Ein Ohr, zu h\u00F6ren meine Klage,
Ein Herz, wie mein's,
Sich des Bedr\u00E4ngten zu erbarmen.

Wer half mir
Wider der Titanen Uebermuth?
Wer rettete vom Tode mich,
Von Sklaverey?
Hast du nicht alles selbst vollendet,
Heilig gl\u00FChend Herz?
Und gl\u00FChtest jung und gut,
Betrogen, Rettungsdank
Dem Schlafenden da droben?

Ich dich ehren? Wof\u00FCr?
Hast du die Schmerzen gelindert
Je des Beladenen?
Hast du die Thr\u00E4nen gestillet
Je des Ge\u00E4ngsteten?
Hat nicht mich zum Manne geschmiedet
Die allm\u00E4chtige Zeit
Und das ewige Schicksal,
Meine Herrn und deine?

W\u00E4hntest du etwa,
Ich sollte das Leben hassen,
In W\u00FCsten fliehen,
Weil nicht alle
Bl\u00FCthentr\u00E4ume reiften?

Hier sitz' ich, forme Menschen
Nach meinem Bilde,
Ein Geschlecht, das mir gleich sey,
Zu leiden, zu weinen,
Zu genie\u00DFen und zu freuen sich,
Und dein nicht zu achten,
Wie ich!

source: https://de.wikisource.org
"
