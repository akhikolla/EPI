library(testthat)
library(rTRNG)

test_check("rTRNG")
