# rTRNG 4.20-1

## Initial CRAN release

- Embed TRNG 4.20 C++ library.
- Expose parallel random number generators and distributions from the library to R. 
- Make TRNG accessible to other R projects' C++ code, via package dependency or `Rcpp::sourceCpp`.
- Vignettes and examples covering basic and advanced usage with both R and C++.
