library(testthat)
library(mwaved)

test_check("mwaved")