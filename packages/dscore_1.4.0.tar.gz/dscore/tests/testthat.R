library("testthat")
library("dplyr")
library("dscore")

test_check("dscore")
