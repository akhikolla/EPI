library(testthat)
library(peppm)

test_check("peppm")
