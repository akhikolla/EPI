# peppm
R package to fit the Piecewise Exponential distribution with random time grids using the clustering structure of the Product Partition Models.

Installation: devtools::install_github("fndemarqui/peppm")

<!-- badges: start -->
  [![Travis build status](https://travis-ci.com/fndemarqui/peppm.svg?branch=master)](https://travis-ci.com/fndemarqui/peppm)
  <!-- badges: end -->
