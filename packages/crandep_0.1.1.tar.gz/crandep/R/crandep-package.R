## usethis namespace: start
#' @useDynLib crandep, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
