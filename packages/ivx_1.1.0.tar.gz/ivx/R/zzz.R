# Set Global Variables to avoid NOTES in cmdchecks
globalVariables("i")
