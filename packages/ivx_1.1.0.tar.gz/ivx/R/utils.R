is_numeric0 <- function(x) {
  is.numeric(x) && length(x) == 0
}
