library(testthat)
library(ivx)

test_check("ivx")
