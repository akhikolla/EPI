library(testthat)
library(landsepi)

test_check("landsepi")
