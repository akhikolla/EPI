#ifndef TEST_STATS_H_
#define TEST_STATS_H_

namespace lolog{
namespace tests{

/*!
 * Tests model statistics.
 */
void testStats();

}
}


#endif /* TEST_STATS_H_ */
