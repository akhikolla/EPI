#ifndef TEST_BINARYNET_H_
#define TEST_BINARYNET_H_

namespace lolog{

namespace tests{


/*!
 * Tests BinaryNet (very thin right now).
 */
void testBinaryNet();


}
}


#endif /* TEST_BINARYNET_H_ */
