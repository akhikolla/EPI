#ifndef TESTLATENT_H_
#define TESTLATENT_H_


namespace lolog{
namespace tests{

/*!
 * Tests model statistics.
 */
void testLatent();

}
}



#endif /* TESTLATENT_H_ */
