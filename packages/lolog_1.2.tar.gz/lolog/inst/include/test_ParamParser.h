/*
 * test_ParamParser.h
 *
 *  Created on: Apr 4, 2018
 *      Author: ianfellows
 */

#ifndef TEST_PARAMPARSER_H_
#define TEST_PARAMPARSER_H_

namespace lolog{
namespace tests{

/*!
 * Tests model statistics.
 */
void testParamParser();

}
}



#endif /* TEST_PARAMPARSER_H_ */
