#ifndef OFFSETS_H_
#define OFFSETS_H_

#include "Offset.h"

namespace lolog{


}


#endif /* OFFSETS_H_ */
