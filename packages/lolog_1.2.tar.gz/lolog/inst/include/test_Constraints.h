#ifndef CONTRAINTTESTS_H_
#define CONTRAINTTESTS_H_

namespace lolog {

namespace tests{

void testConstraints();

}
} /* namespace lolog */
#endif /* CONTRAINTTESTS_H_ */
