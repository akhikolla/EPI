

library(testthat)
library(lolog)

test_check("lolog")