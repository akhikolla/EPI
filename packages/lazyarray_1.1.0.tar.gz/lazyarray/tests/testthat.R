library(testthat)
library(lazyarray)

test_check("lazyarray")
