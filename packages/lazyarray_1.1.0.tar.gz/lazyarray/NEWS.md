lazyarray 1.1.0
=======

* Renamed `LazyArray` to `ClassLazyArray`
* Added `lazyarray` function to create, load or import lazy arrays in one function
* Added `auto_clear_lazyarray` to automatically remove data on hard disks upon garbage collecting (require `dipsaus` package installed, optional)
* Supported customized multi-part file names

lazyarray 1.0.0
=======

* Initial CRAN release!

lazyarray 0.0.0
=======

* Initial private beta release!
* Imported `fstcore` as major back-end and implemented c++ interface
