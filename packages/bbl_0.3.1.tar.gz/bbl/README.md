## bbl (Boltzmann Bayes Learner)
- Boltzmann Bayes learning extends naive Bayes learner to include interactions between predictors
- bbl provides supervised learning implementations with training and prediction methods
