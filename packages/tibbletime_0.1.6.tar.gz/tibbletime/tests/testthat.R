library(testthat)
library(tibbletime)

test_check("tibbletime")
