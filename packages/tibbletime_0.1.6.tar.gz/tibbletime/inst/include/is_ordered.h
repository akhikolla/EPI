#include <Rcpp.h>

#ifndef IS_ORDERED_H
#define IS_ORDERED_H

bool is_ordered_numeric(Rcpp::NumericVector x);

#endif
