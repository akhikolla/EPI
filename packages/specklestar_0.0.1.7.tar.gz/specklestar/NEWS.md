# specklestar v0.0.1.7 (2017-02-08)

* First release of package
* You can obtain statistics of images, middle frame, ps and acf

# Roadmap of specklestar package

- Function to find position of secondary maximum on ACF.
- Function to calculate contrast.
- Calculation of precise rho, phi and dm.
