---
title: "NEWS"
author: "Dongshin Kim"
date: "September 3, 2018"
output: html_document
---


## Update news (11/16/2018)
1. Multinomial Logit and Cox proportional hazard models are added.
2. Significant performance improvements.
3. Minor bug fixes.
4. Paper is available at http://arxiv.org/abs/1811.05061.


## ncpen R package (2/19/2018)

We are releasing ncpen R pakcage: non-convex penalty estimation. Any comnents are welcome.

URL: https://github.com/zeemkr/ncpen
Bug Reports: https://github.com/zeemkr/ncpen/issues
