library(testthat)

test_check("rtdists")
