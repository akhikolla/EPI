library(testthat)
library(joineRML)

test_check("joineRML")
