.onLoad <- function(libname, pkgname) {
  #library(stringb)
  #library(rtext)
  ##packageStartupMessage()
}
