#' text_version_1 a first version of a text
#' @source Source of Text: Diff. (2014, August 26). In Wikipedia, The Free Encyclopedia. Retrieved 10:14, September 24, 2014, from http://en.wikipedia.org/w/index.php?title=Diff&oldid=622929855
"text_version_1"

#' text_version_2 a second version of a text
#' @source Source of Text: Diff. (2014, August 26). In Wikipedia, The Free Encyclopedia. Retrieved 10:14, September 24, 2014, from http://en.wikipedia.org/w/index.php?title=Diff&oldid=622929855
"text_version_2"
