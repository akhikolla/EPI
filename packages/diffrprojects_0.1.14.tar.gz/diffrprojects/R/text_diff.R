#' function for calculating distance matrix between two texts
