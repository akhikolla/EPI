#' method of comparison
#' @export

