NEWS diffrprojects
==========================================================================



version 0.1.12 // 2016-11-01 ...
--------------------------------------------------------------------------

* FEATURE
    - extended documentation
    - examples
    - usage section in README
    - CRAN submission

* BUGFIXES 
    - as.data.frame method for alignment_data would fail in case of no data




version 0.1.11 // 2016-10-25 ...
--------------------------------------------------------------------------

* BUGFIXES
    - using reserved name for alignment coding now gives more informative error message
    



version 0.1.10 // 2016-10-20 ...
--------------------------------------------------------------------------

* FEATURE 
    - sort_alignment()




version 0.1.9 // 2016-10-02 ... 
--------------------------------------------------------------------------

* BUGFIXES
    - fix - differing text timestamps on save-load-seqences

    
* FEATURE

    

* DEVELOPMENT



version 0.1.8 // 2016-09-24 ... 
--------------------------------------------------------------------------

* BUGFIXES
    

    
* FEATURE
    - dp :  dp_sqliteexport
    

* DEVELOPMENT




version 0.1.7 // 2016-09-17 ... 
--------------------------------------------------------------------------

* BUGFIXES
    

    
* FEATURE
    - dp :  dp_loadsave
    

* DEVELOPMENT




version 0.1.6 // 2016-09-11 ... 
--------------------------------------------------------------------------

* BUGFIXES
    - fixing bug in test_tools.r because of false usage of self within dp_text_base_data

    
* FEATURE
    - dp :  text_code_inherit() ... 
            allowing for pushing text_coding through zero distance alignments
    

* DEVELOPMENT




version 0.1.5 // 2016-09-10 ... 
--------------------------------------------------------------------------

* BUGFIXES


    
* FEATURE
    - dp : text_code()
    - dp : text_code_regex()
    - dp : text_code_alignment()
    - dp : text_code_alignment_regex()
    

* DEVELOPMENT
    - renaming self$text_alignment... self$to alignment



version 0.1.4 // 2016-08-28 ... 
--------------------------------------------------------------------------

* BUGFIXES


    
* FEATURE
    - introducing alignment and alignment_data 
    - dp : alignment_add()
    - dp : alignment_delete()
    - dp : alignment_code()
    - dp : alignment_update()
    

* DEVELOPMENT
    - tools : as.data.frame.named_df_list()
    - tools : as.data.frame.alignment_list()
    - registering NSE-variables as globals to make check complaints go away



version 0.1.3 // 2016-08-26 ... 
--------------------------------------------------------------------------

* BUGFIXES


    
* FEATURE
    - tests tests tests
    - passing all checks
    

* DEVELOPMENT



version 0.1.2 // 2016-06-09 ... 
--------------------------------------------------------------------------

* BUGFIXES


    
* FEATURE
    - diff_align()
    

* DEVELOPMENT



version 0.1.1 // 2016-06-07 ... 
--------------------------------------------------------------------------

* BUGFIXES

    
* FEATURE


* DEVELOPMENT
    - big big restructuring: putting rtext into separate package




version 0.1.0 // 2016-04-26 ... 
--------------------------------------------------------------------------

* START of development


    

