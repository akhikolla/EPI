# hierarchicalSets 1.0.2

* Bug Fix: Spelling errors in class name - ugh...
* Bug Fix: Typecast hidden size_t to int to make it build on windows x64
* Feature: More utility functions. Quickly get size and members of clusters as 
well as membership for each set.

# hierarchicalSets 1.0.1

* Release on CRAN

