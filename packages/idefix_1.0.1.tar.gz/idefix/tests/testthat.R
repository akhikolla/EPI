library(testthat)
library(idefix)

test_check("idefix")