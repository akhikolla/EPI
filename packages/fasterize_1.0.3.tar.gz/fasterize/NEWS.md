# fasterize 1.0.3

* Fixes link-time-optimization issues

# fasterize 1.0.2

* Modifies C code to comply with gcc-10 requirements

# fasterize 1.0.0

* First public release.
