library(testthat)
library(gif)

test_check("gif")
