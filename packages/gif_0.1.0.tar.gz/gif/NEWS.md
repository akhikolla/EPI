# gif 0.1.0
* Initial CRAN version
