dataf.tecator <- function() return (getdata("tecator"))
