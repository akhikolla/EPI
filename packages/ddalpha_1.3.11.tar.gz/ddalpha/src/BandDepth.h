void BandDepth(T3DMatrix x, T3DMatrix X, int m, int n, int t, int d, 
               bool modif, int J, double* depths);
