library(testthat)
library(sBIC)

test_check("sBIC")
