library(sBIC)
library(poLCA)

context("Testing LCAs")

# TODO: More tests!