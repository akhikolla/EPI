library(sBIC)

context("Testing ReducedRankRegressions")

# TODO: More tests!