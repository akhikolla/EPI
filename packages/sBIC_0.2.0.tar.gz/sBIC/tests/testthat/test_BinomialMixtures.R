library(sBIC)
library(flexmix)

context("Testing Binomial Mixtures")

# TODO: More tests!