library(sBIC)

context("Testing GaussianMixtures")

# TODO: More tests!