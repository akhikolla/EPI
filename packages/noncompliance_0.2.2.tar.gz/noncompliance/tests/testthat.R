library(testthat)
library(noncompliance)

test_check("noncompliance")
