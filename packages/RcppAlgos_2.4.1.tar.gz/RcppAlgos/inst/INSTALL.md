## Installation Information

* A modern compiler is required. Credit to Henrik Bengtsson for reporting this as well as testing and confirming. He found that compilation failed with gcc 4.8.5 whereas compilation was successful for gcc 5.3.1.

* For more information, see: https://github.com/jwood000/RcppAlgos/issues/13; https://stackoverflow.com/a/36970437/4408538; https://stat.ethz.ch/pipermail/r-package-devel/2020q1/005066.html
