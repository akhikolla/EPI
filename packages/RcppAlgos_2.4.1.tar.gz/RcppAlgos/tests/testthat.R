library(testthat)
library(RcppAlgos)

test_check("RcppAlgos")
