#' @import ParamHelpers
#' @import BBmisc
#' @import checkmate
#' @import ggplot2
#' @import RColorBrewer
#' @import plot3D
#' @import RJSONIO
#' @useDynLib smoof, .registration = TRUE
#' @importFrom mco nsga2
#' @importFrom Rcpp sourceCpp
#' @importFrom grDevices colorRampPalette
#' @importFrom graphics abline contour grid image plot points
#' @importFrom stats reformulate as.formula
#' @importFrom plotly plot_ly
NULL
