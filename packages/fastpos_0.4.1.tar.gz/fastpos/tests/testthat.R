library(testthat)
library(fastpos)

test_check("fastpos")
