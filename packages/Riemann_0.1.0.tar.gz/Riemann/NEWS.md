# Riemann 0.1.0

* Added a `NEWS.md` file to track changes to the package.
* Initial release with 19 common functions, 9 manifolds, and 6 manifold-specific functions.
