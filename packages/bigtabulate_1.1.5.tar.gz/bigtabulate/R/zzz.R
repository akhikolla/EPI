
.onLoad <- function(libname, pkgname) {
}

#.noGenerics <- TRUE

.onUnload <- function(libpath) {
}
