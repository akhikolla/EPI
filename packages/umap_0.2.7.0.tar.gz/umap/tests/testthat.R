library(testthat)
library(umap)

test_check("umap")


