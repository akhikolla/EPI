# eimpute 0.1.1

* Add a rank search function with information criterion rule and cross validation.
* Use Rcpp to rewrite biscale function.

# eimpute 0.1.0

* Initial CRAN version.
