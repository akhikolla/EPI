library(testthat)
library(geodiv)

test_check("geodiv")

