library(testthat)
library(glmmfields)

test_check("glmmfields")
