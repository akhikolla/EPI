library(testthat)
test_check("bggum")
