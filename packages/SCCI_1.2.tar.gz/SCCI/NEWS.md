# SCCI 1.1

* fixed bug that prehibited the package to build on r-patched-solaris-x86

# SCCI 1.2

* added new function *regret(n,k)* that allows the user to directly calculate the multinomial regret term for a discrete random variable with domain size *k* on a hypothetical sample size of *n*
* minor bug fix according to build process (does not involve any functionality of the package)
