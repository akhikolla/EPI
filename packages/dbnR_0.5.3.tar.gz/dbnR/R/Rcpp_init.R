#' @useDynLib dbnR
#' @importFrom Rcpp sourceCpp
NULL