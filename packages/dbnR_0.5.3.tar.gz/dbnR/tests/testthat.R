library(testthat)
library(dbnR)

test_check("dbnR")
