#pragma once

#include "platform_os.h"
#define OPENTIMS_BUILDING_R
