#include "scan2inv_ion_mobility_converter.h"

std::unique_ptr<Scan2InvIonMobilityConverterFactory> DefaultScan2InvIonMobilityConverterFactory::fac_instance;
