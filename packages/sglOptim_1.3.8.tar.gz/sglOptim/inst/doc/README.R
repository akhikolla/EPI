## ---- echo = FALSE-------------------------------------------------------
set.seed(150)
pkg_version <- packageVersion("sglOptim")

## ----eval = FALSE--------------------------------------------------------
#  install.packages("sglOptim")

## ----eval = FALSE--------------------------------------------------------
#  # install.packages("devtools")
#  devtools::install_github("nielsrhansen/sglOptim", build_vignettes = TRUE)

