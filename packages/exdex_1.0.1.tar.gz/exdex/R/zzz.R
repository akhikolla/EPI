.onUnload <- function (libpath) {
  library.dynam.unload("exdex", libpath)
}
