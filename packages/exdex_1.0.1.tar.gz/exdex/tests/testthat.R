library(testthat)
library(exdex)

test_check("exdex")
