# exdex 1.0.1

## Bug fixes and minor improvements

* An overloading ambiguity has been corrected to ensure installation on Solaris.

