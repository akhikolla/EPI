library(testthat)
library(landscapemetrics)
library(raster)

test_check("landscapemetrics")
