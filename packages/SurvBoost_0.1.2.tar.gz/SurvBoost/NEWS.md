# SurvBoost 0.1.2

No major changes to report yet. 

* Added a `NEWS.md` file to track changes to the package.

## Bug fixes

* Updated cross validation code to address a bug. 
* Updated predict.boosting to address a bug. 

