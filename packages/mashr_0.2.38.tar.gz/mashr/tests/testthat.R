library(testthat)
library(mashr)
test_check("mashr")
