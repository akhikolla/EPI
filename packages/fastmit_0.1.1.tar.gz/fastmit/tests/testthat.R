library(testthat)
library(fastmit)

test_check("fastmit")
