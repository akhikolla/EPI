#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib SDMtune
#' @aliases SDMtune-package
#' @keywords internal
"_PACKAGE"
