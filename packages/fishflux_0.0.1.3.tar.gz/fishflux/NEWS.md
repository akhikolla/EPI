# fishflux 0.0.1.2

## Minor update 
* Added a `NEWS.md` file to track changes to the package.
* Fixed minor issue related to internet resources used to comply with cran policy.
'Packages which use Internet resources should fail gracefully with an
informative message if the resource is not available or has changed (and
not give a check warning nor error).'
