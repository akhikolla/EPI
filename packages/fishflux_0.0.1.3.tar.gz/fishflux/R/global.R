utils::globalVariables(c(
  "AspectRatio", "Comment", "Data", "DietTroph", "FoodTroph", 
  "K", "Locality", "Loo", "SL",
  "Species", "TL", "input_sd", "key", "lt", "method",
  "nutrient", "output", "prop_lim", "tl", "to",
  "value", "variable", "w" ))