#' List of all parameters needed to run cnp_model for *Zebrasoma scopas*
#'
#' @docType data
#'
#' @usage data(param_zebsco)
#'
#' @keywords datasets
#'
#' @examples
#' data(param_zebsco)
"param_zebsco"
