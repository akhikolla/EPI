library(testthat)
library(fishflux)

test_check("fishflux")
