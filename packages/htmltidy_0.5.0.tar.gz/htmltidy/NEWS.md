htmltidy 0.3.1
====================
* Fix warnings coming from URL redirection in examples


htmltidy 0.3.0
====================
* Better error handling (fixed crashing bug in #1)
* New option to display document errors
* Support for directly tidying httr::response objects
* Added XML/HTML viewer & XPath query widgets


htmltidy 0.2.0
====================
* Bundled tidy-html5 library with the package
* Windows compatibility
* Options handling
* Enabled generics
* Modified tests


htmltidy 0.1.0
====================
* Added a `NEWS.md` file to track changes to the package.
* Added Debian & Ubuntu compatibility
* Added basic error checking
* Added basic test harness

