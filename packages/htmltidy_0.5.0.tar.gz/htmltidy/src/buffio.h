#ifdef __GNUC__
#warning "FIXME: Using compatibility tidy header (buffio.h) that will go away!"
#endif

#include "tidybuffio.h"

