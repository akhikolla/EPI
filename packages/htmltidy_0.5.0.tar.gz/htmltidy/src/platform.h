#ifdef __GNUC__
#warning "FIXME: Using compatibility tidy header (platform.h) that will go away!"
#endif

#include "tidyplatform.h"

