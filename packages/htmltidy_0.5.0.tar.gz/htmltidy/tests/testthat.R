library(testthat)
library(htmltidy)

test_check("htmltidy")
