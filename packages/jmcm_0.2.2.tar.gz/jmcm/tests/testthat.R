library(testthat)
library(jmcm)

test_check("jmcm")
