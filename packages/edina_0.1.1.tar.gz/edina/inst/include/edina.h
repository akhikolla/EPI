#ifndef EDINA_EDINA_H
#define EDINA_EDINA_H
#include <RcppArmadillo.h>
#include <rgen.h>

#include "edina_meat.h"

#endif
