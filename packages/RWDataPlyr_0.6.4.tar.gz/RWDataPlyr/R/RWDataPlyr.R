
#' @keywords internal
"_PACKAGE"

#' @importFrom dplyr %>%
NULL

#' @useDynLib RWDataPlyr, .registration = TRUE
#'
#' @importFrom Rcpp sourceCpp
NULL
