##Internal variables
fugeRglobal <- new.env(parent = baseenv())
