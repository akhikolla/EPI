#ifndef _fugeR_CFUZZIFYVAR_H
#define _fugeR_CFUZZIFYVAR_H

#include <Rcpp.h>

RcppExport SEXP cfuzzifyVar( SEXP mfId,
						  SEXP mfPoints,
						  SEXP values,
						  SEXP minValues ) ;

#endif
