library("testthat")
test_check("clifford")
