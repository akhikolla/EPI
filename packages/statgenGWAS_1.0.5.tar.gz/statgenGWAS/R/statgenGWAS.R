#' @keywords internal
"_PACKAGE"

#' @useDynLib statgenGWAS, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom utils hasName
NULL
