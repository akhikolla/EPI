#ifndef UTILS_ENTROPY_H
#define UTILS_ENTROPY_H

#include <math.h>

double Entropy(double x);

#endif
