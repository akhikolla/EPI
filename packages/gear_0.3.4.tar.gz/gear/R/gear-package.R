#' gear
#'
#' *Ge*ostatistical *A*nalysis in *R*.
#'
## usethis namespace: start
#' @useDynLib gear, .registration = TRUE
## usethis namespace: end
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
#' @name gear
#' @docType package
NULL
