# ibm
Individual Based Models in R
