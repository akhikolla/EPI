#ifndef _ibmLV_LOCAL_INT_CPP
#define _ibmLV_LOCAL_INT_CPP

#include <Rcpp.h>

RcppExport SEXP local_int_cpp( SEXP posx, SEXP posy, SEXP R1, SEXP R2) ;

#endif
