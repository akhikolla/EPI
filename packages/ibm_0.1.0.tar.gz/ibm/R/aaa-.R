#' @importFrom Rcpp evalCpp
NULL
#' @useDynLib ibm
NULL
#' @importFrom stats rnorm runif rbinom quantile median
NULL
#' @import graphics
NULL