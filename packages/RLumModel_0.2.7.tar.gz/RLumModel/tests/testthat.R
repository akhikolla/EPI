library(testthat)
library(RLumModel)

test_check("RLumModel")
