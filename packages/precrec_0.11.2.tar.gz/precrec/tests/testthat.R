library(testthat)
library(precrec)

test_check("precrec")
