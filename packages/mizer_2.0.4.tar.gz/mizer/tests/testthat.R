library(testthat)
library(mizer)

test_check("mizer")
