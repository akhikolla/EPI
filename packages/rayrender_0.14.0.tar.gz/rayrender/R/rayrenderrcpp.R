#' @useDynLib rayrender, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
