library(testthat)

if (T){
    library(gRbase)

    test_check("gRbase")
}
