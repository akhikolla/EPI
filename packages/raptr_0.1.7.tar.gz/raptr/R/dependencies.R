#' @import sp
#' @import raster
NULL

#' @useDynLib raptr, .registration = TRUE
NULL
