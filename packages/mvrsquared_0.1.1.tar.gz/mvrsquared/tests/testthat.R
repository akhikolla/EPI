library(testthat)
library(mvrsquared)

test_check("mvrsquared")
