# Data retrieved from https://en.wikipedia.org/wiki/HSL_and_HSV
dat <- readRDS("rgb_hsl.RData")