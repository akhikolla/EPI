library(testthat)
library(qualpalr)

test_check("qualpalr")
