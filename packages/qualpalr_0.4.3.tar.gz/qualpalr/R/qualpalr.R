#' @importFrom Rcpp evalCpp
#' @importFrom RcppParallel RcppParallelLibs
#' @useDynLib qualpalr, .registration = TRUE
#' @keywords internal
"_PACKAGE"