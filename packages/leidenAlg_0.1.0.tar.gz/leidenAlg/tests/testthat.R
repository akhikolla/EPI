library(leidenAlg)

testthat::test_check("leidenAlg")