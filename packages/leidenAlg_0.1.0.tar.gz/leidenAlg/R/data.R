#' Conos graph 
#'
"exampleGraph"
