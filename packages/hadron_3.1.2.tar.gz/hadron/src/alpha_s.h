#pragma once

double alphas_c(
    const double mu, const int nl, const double lam0, const int Nc, const int Nf);
