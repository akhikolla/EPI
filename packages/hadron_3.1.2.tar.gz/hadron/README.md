# Hadron

An R implementation of fitting routines used in lattice QCD. It provides useful
functions for extraction hadronic quantities and such like. 

The license is *GPL 3 or later*, even though the `DESCRIPTION` only shows
`GPL-3`.

[master branch](https://github.com/HISKP-LQCD/hadron): [![Build Status](https://travis-ci.org/HISKP-LQCD/hadron.svg?branch=master)](https://travis-ci.org/HISKP-LQCD/hadron)
