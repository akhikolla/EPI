library(testthat)
library(RNifti)

test_check("RNifti")
