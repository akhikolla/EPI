var searchData=
[
  ['_5fdatatype_259',['_datatype',['../a00018.html#a3a37b63398fdf338c91731007b19933a',1,'RNifti::NiftiImageData']]],
  ['_5flength_260',['_length',['../a00018.html#aa8496487bdd61d6022c3f5bbe72367f5',1,'RNifti::NiftiImageData']]]
];
