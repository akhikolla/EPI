var searchData=
[
  ['concretetypehandler_136',['ConcreteTypeHandler',['../a00026.html',1,'RNifti::NiftiImageData']]],
  ['concretetypehandler_3c_20rgba32_5ft_2c_20alpha_20_3e_137',['ConcreteTypeHandler&lt; rgba32_t, alpha &gt;',['../a00034.html',1,'RNifti::NiftiImageData']]],
  ['concretetypehandler_3c_20std_3a_3acomplex_3c_20elementtype_20_3e_2c_20false_20_3e_138',['ConcreteTypeHandler&lt; std::complex&lt; ElementType &gt;, false &gt;',['../a00030.html',1,'RNifti::NiftiImageData']]]
];
