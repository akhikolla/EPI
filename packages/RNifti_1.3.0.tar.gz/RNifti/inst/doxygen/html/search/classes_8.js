var searchData=
[
  ['valuetype_147',['ValueType',['../a00014.html',1,'RNifti::rgba32_t']]],
  ['vector_148',['Vector',['../a00046.html',1,'RNifti']]]
];
