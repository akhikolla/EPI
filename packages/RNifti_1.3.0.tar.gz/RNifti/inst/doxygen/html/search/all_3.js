var searchData=
[
  ['calibratefrom_8',['calibrateFrom',['../a00018.html#af0a02ca44de0e01f1dcf4c067d69cb1d',1,'RNifti::NiftiImageData']]],
  ['changedatatype_9',['changeDatatype',['../a00054.html#a359c9fc816ee752a27ee15b88b625a38',1,'RNifti::NiftiImage::changeDatatype(const int datatype, const bool useSlope=false)'],['../a00054.html#a2ae53292590a6618420bacc463b6f253',1,'RNifti::NiftiImage::changeDatatype(const std::string &amp;datatype, const bool useSlope=false)']]],
  ['code_10',['code',['../a00062.html#a7af16ec35942f5acf614a3e5b63bf597',1,'RNifti::NiftiImage::Extension']]],
  ['colnorm_11',['colnorm',['../a00050.html#a6f6bc1ba31373556da3b8e98f3bc63b0',1,'RNifti::SquareMatrix']]],
  ['concretetypehandler_12',['ConcreteTypeHandler',['../a00026.html',1,'RNifti::NiftiImageData']]],
  ['concretetypehandler_3c_20rgba32_5ft_2c_20alpha_20_3e_13',['ConcreteTypeHandler&lt; rgba32_t, alpha &gt;',['../a00034.html',1,'RNifti::NiftiImageData']]],
  ['concretetypehandler_3c_20std_3a_3acomplex_3c_20elementtype_20_3e_2c_20false_20_3e_14',['ConcreteTypeHandler&lt; std::complex&lt; ElementType &gt;, false &gt;',['../a00030.html',1,'RNifti::NiftiImageData']]],
  ['copy_15',['copy',['../a00062.html#a2330bbe8c133f913b5f3297ec35066d7',1,'RNifti::NiftiImage::Extension::copy(const nifti1_extension *source)'],['../a00062.html#a3a8a6161037850e565c3d157ea2e3d76',1,'RNifti::NiftiImage::Extension::copy(const SourceType *data, const size_t length, const int code)'],['../a00054.html#aeb1d5e30e3d28a07b69844cec2514144',1,'RNifti::NiftiImage::copy(const nifti_image *source)'],['../a00054.html#aab05a75827764608bbcb67251a5e8eba',1,'RNifti::NiftiImage::copy(const NiftiImage &amp;source)'],['../a00054.html#ad0fb9f9754e9c0e3692b9fbf5821705a',1,'RNifti::NiftiImage::copy(const Block &amp;source)']]],
  ['createhandler_16',['createHandler',['../a00018.html#ad9b5928c05894f07b5711734519546f0',1,'RNifti::NiftiImageData']]]
];
