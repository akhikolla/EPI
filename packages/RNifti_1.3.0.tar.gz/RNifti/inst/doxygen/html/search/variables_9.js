var searchData=
[
  ['slope_273',['slope',['../a00018.html#a5d74d8ab82313364907a532494efbb6c',1,'RNifti::NiftiImageData']]]
];
