var searchData=
[
  ['dataptr_261',['dataPtr',['../a00018.html#afe468724e2de9feee419f21a23d42c99',1,'RNifti::NiftiImageData']]],
  ['dimension_262',['dimension',['../a00058.html#ae1e9134978a127793003a06619e87440',1,'RNifti::NiftiImage::Block']]]
];
