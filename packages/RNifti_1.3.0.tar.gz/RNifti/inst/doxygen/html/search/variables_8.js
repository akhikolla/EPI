var searchData=
[
  ['refcount_272',['refCount',['../a00054.html#a8e1b092d6237daa18abb08ac966a3c80',1,'RNifti::NiftiImage']]]
];
