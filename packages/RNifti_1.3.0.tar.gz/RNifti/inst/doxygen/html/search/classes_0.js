var searchData=
[
  ['block_135',['Block',['../a00058.html',1,'RNifti::NiftiImage']]]
];
