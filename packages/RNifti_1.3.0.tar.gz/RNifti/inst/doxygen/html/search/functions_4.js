var searchData=
[
  ['element_170',['Element',['../a00038.html#a99dad9729bdf6bd34b0d5197506efcbe',1,'RNifti::NiftiImageData::Element']]],
  ['end_171',['end',['../a00018.html#a8d3ce6768dc2c333ac06c039f034a2d4',1,'RNifti::NiftiImageData::end() const'],['../a00018.html#a46d658a3d18a274ef5419628749bc37e',1,'RNifti::NiftiImageData::end()'],['../a00050.html#af213e6527e847574a687de55e412d88f',1,'RNifti::SquareMatrix::end() const'],['../a00050.html#a08218d971e27e89ed7ea1ec522e3c315',1,'RNifti::SquareMatrix::end()']]],
  ['extension_172',['Extension',['../a00062.html#a8ebcda3aba9cd412e7752d0ea4f4b2d8',1,'RNifti::NiftiImage::Extension::Extension()'],['../a00062.html#ab21b452989567f25f5672bb6cd21fea5',1,'RNifti::NiftiImage::Extension::Extension(nifti1_extension *const extension, const bool copy=false)'],['../a00062.html#a3155500db58b01d76e1228543c3b5b2c',1,'RNifti::NiftiImage::Extension::Extension(const Extension &amp;source)'],['../a00062.html#a2ed7e4fa36b776b4ec4e5273b79747d9',1,'RNifti::NiftiImage::Extension::Extension(const SourceType *data, const size_t length, const int code)'],['../a00062.html#a529eae1ef3a28afcf7144283fb5516bc',1,'RNifti::NiftiImage::Extension::Extension(SEXP source, int code=-1)']]],
  ['extensions_173',['extensions',['../a00054.html#ad3ddb7a18ac15d9b2266a9b90bf1c7e4',1,'RNifti::NiftiImage']]],
  ['eye_174',['eye',['../a00050.html#aba7d9e58ea3bd102b74b39614b56161f',1,'RNifti::SquareMatrix']]]
];
