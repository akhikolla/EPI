var searchData=
[
  ['fileversion_35',['fileVersion',['../a00054.html#a328c8d10d4ec7ba292f7490611db4bef',1,'RNifti::NiftiImage']]]
];
