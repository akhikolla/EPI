var searchData=
[
  ['pixdim_93',['pixdim',['../a00054.html#a2561e6a5865999f9997ec11b9c84b97c',1,'RNifti::NiftiImage']]],
  ['polar_94',['polar',['../a00050.html#a44b70f597dc165a4820bffe03e979537',1,'RNifti::SquareMatrix']]]
];
