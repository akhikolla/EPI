var searchData=
[
  ['handedness_177',['handedness',['../a00066.html#ab1b482e34d9203d7763dfd3032ac47b0',1,'RNifti::NiftiImage::Xform']]]
];
