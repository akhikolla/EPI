var searchData=
[
  ['nativetype_209',['NativeType',['../a00066.html#a63a374890eeef8a6ae35aa5045ac260b',1,'RNifti::NiftiImage::Xform::NativeType() const'],['../a00066.html#a31f7d91f7bf95ae19330ec1569c65e42',1,'RNifti::NiftiImage::Xform::NativeType()']]],
  ['offset_210',['offset',['../a00066.html#aeb1ed01cb68bcbf1057c7bd498c7c6e7',1,'RNifti::NiftiImage::Xform']]],
  ['operator_20const_20nifti_5fimage_20_2a_211',['operator const nifti_image *',['../a00054.html#af64d7fcf5e1a981931c8f539705ea364',1,'RNifti::NiftiImage']]],
  ['operator_20const_20niftitype_212',['operator const NiftiType',['../a00050.html#ab3e03ffce2ae1fb928555f40776b3c38',1,'RNifti::SquareMatrix']]],
  ['operator_20nifti_5fimage_20_2a_213',['operator nifti_image *',['../a00054.html#a2c8d20d6d020b8fa890aacc82e1dfc00',1,'RNifti::NiftiImage']]],
  ['operator_20niftitype_214',['operator NiftiType',['../a00050.html#af503ae5bd1c023fb560384f7d8ee7b95',1,'RNifti::SquareMatrix']]],
  ['operator_20rcomplex_215',['operator Rcomplex',['../a00038.html#a0f70b708948c21e73fa30b4246e94d5a',1,'RNifti::NiftiImageData::Element']]],
  ['operator_20sexp_216',['operator SEXP',['../a00050.html#a3585db109ae6ca121d209313c9f43d4d',1,'RNifti::SquareMatrix::operator SEXP()'],['../a00062.html#a8c611e5d1f499b4568e25d078c6beba3',1,'RNifti::NiftiImage::Extension::operator SEXP()']]],
  ['operator_20targettype_217',['operator TargetType',['../a00038.html#a3549c7efab91b93c95c9fb8eeda56e79',1,'RNifti::NiftiImageData::Element']]],
  ['operator_28_29_218',['operator()',['../a00050.html#ab524ad0344e5f8a65b204c5e4ee89489',1,'RNifti::SquareMatrix::operator()(const int i, const int j) const'],['../a00050.html#ac6709cdfe9f161dee523a7bacc50791b',1,'RNifti::SquareMatrix::operator()(const int i, const int j)']]],
  ['operator_2a_219',['operator*',['../a00050.html#ac4d9b0a0a507ebd9ba256c0a98eb1f5f',1,'RNifti::SquareMatrix::operator*(const MatrixType &amp;other) const'],['../a00050.html#af9ae8cc19a4df192abf3e5f115c062e7',1,'RNifti::SquareMatrix::operator*(const VectorType &amp;vec) const']]],
  ['operator_2d_220',['operator-',['../a00046.html#aa5f0c843177ebe8623c468f33471f8da',1,'RNifti::Vector']]],
  ['operator_2d_3e_221',['operator-&gt;',['../a00054.html#a68659ddd6865b3c2995f0144d2aa35c8',1,'RNifti::NiftiImage::operator-&gt;() const'],['../a00054.html#afb49b27d720e7ce6e83377dd3a80dd39',1,'RNifti::NiftiImage::operator-&gt;()']]],
  ['operator_3d_222',['operator=',['../a00038.html#aaf4204310e1fd3dd49c18c90ef05b4fc',1,'RNifti::NiftiImageData::Element::operator=(const SourceType &amp;value)'],['../a00038.html#a45c318ad9ac7d4a302872fec964cfeb8',1,'RNifti::NiftiImageData::Element::operator=(const Element &amp;other)'],['../a00018.html#a291ebbb7b347a8aac46273cd411944ea',1,'RNifti::NiftiImageData::operator=()'],['../a00058.html#a53fc2b90aecfbff3de279d89e3745383',1,'RNifti::NiftiImage::Block::operator=()'],['../a00066.html#ac2bec9810d1a0f1737b17ed1ff50115d',1,'RNifti::NiftiImage::Xform::operator=(const Xform &amp;source)'],['../a00066.html#abe1d2b2569f39925593c8738c6c69607',1,'RNifti::NiftiImage::Xform::operator=(const Matrix &amp;source)'],['../a00054.html#a62e1339b330697e2f684880aa9465ef7',1,'RNifti::NiftiImage::operator=(const NiftiImage &amp;source)'],['../a00054.html#a7ec9393480a1395e14afc4fc5393faa1',1,'RNifti::NiftiImage::operator=(const Block &amp;source)']]],
  ['operator_5b_5d_223',['operator[]',['../a00018.html#a9ee504228dc39abdb308671b90a7966e',1,'RNifti::NiftiImageData::operator[](const size_t i) const'],['../a00018.html#ac6b9bca4b0678c2536c9e3b6afac55f1',1,'RNifti::NiftiImageData::operator[](const size_t i)']]],
  ['orientation_224',['orientation',['../a00066.html#ac6cda322ebf309e62c06cbacfa7e38fd',1,'RNifti::NiftiImage::Xform']]]
];
