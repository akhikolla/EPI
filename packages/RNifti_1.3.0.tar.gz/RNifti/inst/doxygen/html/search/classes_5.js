var searchData=
[
  ['rgba32_5ft_144',['rgba32_t',['../a00010.html',1,'RNifti']]]
];
