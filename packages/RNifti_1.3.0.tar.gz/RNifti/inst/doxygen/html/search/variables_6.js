var searchData=
[
  ['owner_270',['owner',['../a00018.html#ac3b3b9f91252f9f0c11f5b249d728fdb',1,'RNifti::NiftiImageData']]]
];
