var searchData=
[
  ['toarray_246',['toArray',['../a00054.html#ab66bee4630c63a6d148107b0ea4453e5',1,'RNifti::NiftiImage']]],
  ['toarrayorpointer_247',['toArrayOrPointer',['../a00054.html#aaa2ad68e8ac3159c2ab66ff366816197',1,'RNifti::NiftiImage']]],
  ['tofile_248',['toFile',['../a00054.html#a2a59e2235e72af12c8c9b3ed4950ecc6',1,'RNifti::NiftiImage::toFile(const std::string fileName, const int datatype=DT_NONE, const int filetype=-1) const'],['../a00054.html#a59eae94706523a66df229156042a5c21',1,'RNifti::NiftiImage::toFile(const std::string fileName, const std::string &amp;datatype, const int filetype=-1) const']]],
  ['topointer_249',['toPointer',['../a00054.html#a9b323686f92c62395ba29733ae5667a1',1,'RNifti::NiftiImage']]],
  ['totalbytes_250',['totalBytes',['../a00018.html#a47d1a99723ce2b693e8162db8124e2d2',1,'RNifti::NiftiImageData']]]
];
