var searchData=
[
  ['rnifti_3a_20fast_20r_20and_20c_2b_2b_20access_20to_20nifti_20images_278',['RNifti: Fast R and C++ Access to NIfTI Images',['../index.html',1,'']]]
];
