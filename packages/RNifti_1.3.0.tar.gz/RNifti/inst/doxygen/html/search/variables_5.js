var searchData=
[
  ['mat_269',['mat',['../a00066.html#aa2dd4abb114bfdd406ebf7810a498724',1,'RNifti::NiftiImage::Xform']]]
];
