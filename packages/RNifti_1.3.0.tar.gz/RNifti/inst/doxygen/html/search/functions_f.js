var searchData=
[
  ['release_229',['release',['../a00054.html#a0204d82646631cc25ac22c5f430c59d4',1,'RNifti::NiftiImage']]],
  ['reorient_230',['reorient',['../a00054.html#a0f3120655b15e3fa849d166a4e5873fc',1,'RNifti::NiftiImage::reorient(const int i, const int j, const int k)'],['../a00054.html#ae6b7856d3e991ef2e45fad8d8cfd66d0',1,'RNifti::NiftiImage::reorient(const std::string &amp;orientation)']]],
  ['replace_231',['replace',['../a00066.html#a8b35e7420a354d6baef62f7c2602eab9',1,'RNifti::NiftiImage::Xform']]],
  ['replacedata_232',['replaceData',['../a00054.html#a4db6fa567beeaecd6e0abedac0b22fd1',1,'RNifti::NiftiImage::replaceData(const std::vector&lt; SourceType &gt; &amp;data, const int datatype=DT_NONE)'],['../a00054.html#aa250274616be26082c84144d13e1ca3f',1,'RNifti::NiftiImage::replaceData(const NiftiImageData &amp;data)']]],
  ['replaceextensions_233',['replaceExtensions',['../a00054.html#a361e9ab4ddc32fca91b0fe336985a8cf',1,'RNifti::NiftiImage']]],
  ['rescale_234',['rescale',['../a00054.html#a8d9e7e462f4aad57a46346f8d4b04e8e',1,'RNifti::NiftiImage']]],
  ['rotation_235',['rotation',['../a00066.html#a67ef1fa73a00abb04053f9405a4d7414',1,'RNifti::NiftiImage::Xform']]],
  ['rownorm_236',['rownorm',['../a00050.html#a6982e840fdcd98dc82e673dd8cd247e7',1,'RNifti::SquareMatrix']]]
];
