var searchData=
[
  ['mat_61',['mat',['../a00066.html#aa2dd4abb114bfdd406ebf7810a498724',1,'RNifti::NiftiImage::Xform']]],
  ['matrix_62',['matrix',['../a00066.html#ab5b8cff4b16d2a4e8d495d10a833342c',1,'RNifti::NiftiImage::Xform']]],
  ['matrixtype_63',['MatrixType',['../a00050.html#a9d4d556d843037c4482dcdd1b53629b7',1,'RNifti::SquareMatrix']]],
  ['minmax_64',['minmax',['../a00018.html#a54d136635f5598a75f4816c2d2a85a39',1,'RNifti::NiftiImageData']]],
  ['multiply_65',['multiply',['../a00050.html#a61fae0214e5fcd8a3de3ab95b12f071d',1,'RNifti::SquareMatrix::multiply(const MatrixType &amp;other) const'],['../a00050.html#ab3d42f8203abceeee8423b497f1ec3ab',1,'RNifti::SquareMatrix::multiply(const VectorType &amp;vec) const']]]
];
