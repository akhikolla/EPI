var searchData=
[
  ['qform_95',['qform',['../a00054.html#affd1edd48bae1337ba68e7b02693237e',1,'RNifti::NiftiImage::qform() const'],['../a00054.html#ad86379711025f3f514a8647be82b7578',1,'RNifti::NiftiImage::qform()']]],
  ['qparams_96',['qparams',['../a00066.html#ae8dcdba0a0d249e08c2344a711a73a16',1,'RNifti::NiftiImage::Xform']]],
  ['quaternion_97',['quaternion',['../a00066.html#ac67a04b26554614118cba509fc437dbe',1,'RNifti::NiftiImage::Xform']]]
];
