var searchData=
[
  ['handler_265',['handler',['../a00018.html#a4120de271d40a233d8d017919ca72b92',1,'RNifti::NiftiImageData']]]
];
