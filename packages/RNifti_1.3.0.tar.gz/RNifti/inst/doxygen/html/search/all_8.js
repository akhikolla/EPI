var searchData=
[
  ['handedness_37',['handedness',['../a00066.html#ab1b482e34d9203d7763dfd3032ac47b0',1,'RNifti::NiftiImage::Xform']]],
  ['handler_38',['handler',['../a00018.html#a4120de271d40a233d8d017919ca72b92',1,'RNifti::NiftiImageData']]]
];
