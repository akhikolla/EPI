var searchData=
[
  ['getdata_36',['getData',['../a00058.html#a6a97064f15e2c8f7bb8fb7dfc116a3fb',1,'RNifti::NiftiImage::Block::getData()'],['../a00054.html#a8a4c7ddbb589b70e0560b781e5b42d4d',1,'RNifti::NiftiImage::getData()']]]
];
