var searchData=
[
  ['xform_149',['Xform',['../a00066.html',1,'RNifti::NiftiImage']]]
];
