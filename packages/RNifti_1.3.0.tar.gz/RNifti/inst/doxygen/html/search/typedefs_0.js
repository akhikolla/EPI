var searchData=
[
  ['matrixtype_274',['MatrixType',['../a00050.html#a9d4d556d843037c4482dcdd1b53629b7',1,'RNifti::SquareMatrix']]]
];
