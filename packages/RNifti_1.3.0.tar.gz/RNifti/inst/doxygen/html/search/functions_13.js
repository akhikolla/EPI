var searchData=
[
  ['vector_254',['Vector',['../a00046.html#aa20b83aed1cbeee503ad3194e6762ffb',1,'RNifti::Vector::Vector(const ElementType value=0.0)'],['../a00046.html#a0b866ab02861725ff549b1fd9e7768e8',1,'RNifti::Vector::Vector(const ElementType *source)']]],
  ['volume_255',['volume',['../a00054.html#ac416f242d48fe60da4dc5d8f4ad04c20',1,'RNifti::NiftiImage::volume(const int i) const'],['../a00054.html#ab7dc18d35249622b5dc43171cceee9fe',1,'RNifti::NiftiImage::volume(const int i)']]]
];
