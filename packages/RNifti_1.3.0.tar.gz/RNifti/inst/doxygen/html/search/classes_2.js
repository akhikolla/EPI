var searchData=
[
  ['element_139',['Element',['../a00038.html',1,'RNifti::NiftiImageData']]],
  ['extension_140',['Extension',['../a00062.html',1,'RNifti::NiftiImage']]]
];
