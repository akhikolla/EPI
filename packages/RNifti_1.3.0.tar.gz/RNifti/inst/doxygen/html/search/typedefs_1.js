var searchData=
[
  ['nativetype_275',['NativeType',['../a00050.html#a61491d0a349e4590bb78bc963ff1216f',1,'RNifti::SquareMatrix']]]
];
