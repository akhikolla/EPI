var searchData=
[
  ['iterator_141',['Iterator',['../a00042.html',1,'RNifti::NiftiImageData']]]
];
