var searchData=
[
  ['image_39',['image',['../a00058.html#a44ac6e7ad9b070041bad4a63724d76b3',1,'RNifti::NiftiImage::Block::image()'],['../a00054.html#a82c4e0968f416972783a3cad00b4a1dc',1,'RNifti::NiftiImage::image()']]],
  ['index_40',['index',['../a00058.html#a5d929aeb499bedf7a55dc33fb45dbac3',1,'RNifti::NiftiImage::Block']]],
  ['init_41',['init',['../a00018.html#ad439731537b2e0e2ea838f12e11cacba',1,'RNifti::NiftiImageData']]],
  ['initfromarray_42',['initFromArray',['../a00054.html#acce36c8bd176c885a2f8d09fe5cfc912',1,'RNifti::NiftiImage']]],
  ['initfromdims_43',['initFromDims',['../a00054.html#af8d392ae02a26eb3b5df30e929fbd3cd',1,'RNifti::NiftiImage']]],
  ['initfromlist_44',['initFromList',['../a00054.html#aede605bed11fa10ccd027467b30d59ae',1,'RNifti::NiftiImage']]],
  ['initfrommriimage_45',['initFromMriImage',['../a00054.html#a0a5e86c97471419fa747c8e1c6c4ddb9',1,'RNifti::NiftiImage']]],
  ['initfromniftis4_46',['initFromNiftiS4',['../a00054.html#a700e21da500141bec53c11b33dce51ea',1,'RNifti::NiftiImage']]],
  ['intercept_47',['intercept',['../a00018.html#a7a5af7b5c106f31623783560e00aca68',1,'RNifti::NiftiImageData']]],
  ['inverse_48',['inverse',['../a00050.html#a1df5c002b23a29ba4ddb959bc33c7521',1,'RNifti::SquareMatrix']]],
  ['iscomplex_49',['isComplex',['../a00018.html#afb004caf42953e562f681c4d79001e2f',1,'RNifti::NiftiImageData']]],
  ['isdatascaled_50',['isDataScaled',['../a00054.html#a1e4a5e5391215ab54bfc0c823652ad78',1,'RNifti::NiftiImage']]],
  ['isempty_51',['isEmpty',['../a00018.html#ae205097bf159ffde5d8b28219ce042da',1,'RNifti::NiftiImageData']]],
  ['isfloatingpoint_52',['isFloatingPoint',['../a00018.html#a81ec89f42c5c2a7d5343fc36a0cb8a33',1,'RNifti::NiftiImageData']]],
  ['isinteger_53',['isInteger',['../a00018.html#ab4585895eb4875be7112ecc45e0ae7cd',1,'RNifti::NiftiImageData']]],
  ['isnull_54',['isNull',['../a00054.html#a59de4f1dc18aebce27f2abcbe2fe3a97',1,'RNifti::NiftiImage']]],
  ['ispersistent_55',['isPersistent',['../a00054.html#a94eda3b3041314354f9b314d95a116d1',1,'RNifti::NiftiImage']]],
  ['isrgb_56',['isRgb',['../a00018.html#a0f935b2f58c582bff944bfc1f8d50ddf',1,'RNifti::NiftiImageData']]],
  ['isscaled_57',['isScaled',['../a00018.html#a1fc8325e2db037d9374e254da0a0b8b4',1,'RNifti::NiftiImageData']]],
  ['isshared_58',['isShared',['../a00054.html#a75890fe868c735e7011f62c39a1e0eb2',1,'RNifti::NiftiImage']]],
  ['iterator_59',['Iterator',['../a00042.html',1,'RNifti::NiftiImageData::Iterator'],['../a00042.html#a5f127a5b057b7f68513cae3a9bca3378',1,'RNifti::NiftiImageData::Iterator::Iterator(const NiftiImageData &amp;parent, void *ptr=NULL, const size_t step=0)'],['../a00042.html#a8694ec0dd4b36b2705d36ece804e74ae',1,'RNifti::NiftiImageData::Iterator::Iterator(const Iterator &amp;other)']]]
];
