var searchData=
[
  ['qparams_271',['qparams',['../a00066.html#ae8dcdba0a0d249e08c2344a711a73a16',1,'RNifti::NiftiImage::Xform']]]
];
