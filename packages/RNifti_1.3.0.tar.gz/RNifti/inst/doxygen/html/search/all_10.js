var searchData=
[
  ['rnifti_3a_20fast_20r_20and_20c_2b_2b_20access_20to_20nifti_20images_98',['RNifti: Fast R and C++ Access to NIfTI Images',['../index.html',1,'']]],
  ['refcount_99',['refCount',['../a00054.html#a8e1b092d6237daa18abb08ac966a3c80',1,'RNifti::NiftiImage']]],
  ['release_100',['release',['../a00054.html#a0204d82646631cc25ac22c5f430c59d4',1,'RNifti::NiftiImage']]],
  ['reorient_101',['reorient',['../a00054.html#a0f3120655b15e3fa849d166a4e5873fc',1,'RNifti::NiftiImage::reorient(const int i, const int j, const int k)'],['../a00054.html#ae6b7856d3e991ef2e45fad8d8cfd66d0',1,'RNifti::NiftiImage::reorient(const std::string &amp;orientation)']]],
  ['replace_102',['replace',['../a00066.html#a8b35e7420a354d6baef62f7c2602eab9',1,'RNifti::NiftiImage::Xform']]],
  ['replacedata_103',['replaceData',['../a00054.html#a4db6fa567beeaecd6e0abedac0b22fd1',1,'RNifti::NiftiImage::replaceData(const std::vector&lt; SourceType &gt; &amp;data, const int datatype=DT_NONE)'],['../a00054.html#aa250274616be26082c84144d13e1ca3f',1,'RNifti::NiftiImage::replaceData(const NiftiImageData &amp;data)']]],
  ['replaceextensions_104',['replaceExtensions',['../a00054.html#a361e9ab4ddc32fca91b0fe336985a8cf',1,'RNifti::NiftiImage']]],
  ['rescale_105',['rescale',['../a00054.html#a8d9e7e462f4aad57a46346f8d4b04e8e',1,'RNifti::NiftiImage']]],
  ['rgba32_5ft_106',['rgba32_t',['../a00010.html',1,'RNifti']]],
  ['rotation_107',['rotation',['../a00066.html#a67ef1fa73a00abb04053f9405a4d7414',1,'RNifti::NiftiImage::Xform']]],
  ['rownorm_108',['rownorm',['../a00050.html#a6982e840fdcd98dc82e673dd8cd247e7',1,'RNifti::SquareMatrix']]]
];
