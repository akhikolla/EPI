var searchData=
[
  ['_7eniftiimage_133',['~NiftiImage',['../a00054.html#a5ec15c8ad46eedb6498d007202389e0c',1,'RNifti::NiftiImage']]],
  ['_7eniftiimagedata_134',['~NiftiImageData',['../a00018.html#ab5b71eeb251a8eb35dc4b9378164d9cf',1,'RNifti::NiftiImageData']]]
];
