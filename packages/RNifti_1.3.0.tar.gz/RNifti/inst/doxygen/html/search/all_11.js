var searchData=
[
  ['setpersistence_109',['setPersistence',['../a00054.html#ac2659bd59e1d35416f97b88f6618bedc',1,'RNifti::NiftiImage']]],
  ['setpixunits_110',['setPixunits',['../a00054.html#a21c9f48de4da893dacc0f37eed32828e',1,'RNifti::NiftiImage']]],
  ['sexptypetoniftitype_111',['sexpTypeToNiftiType',['../a00054.html#a8b8eeb22aa4e74f017e0c9f3d29c77a4',1,'RNifti::NiftiImage']]],
  ['sform_112',['sform',['../a00054.html#adbec8e0ad0fb64d31d01e47489c81b12',1,'RNifti::NiftiImage::sform() const'],['../a00054.html#a4e39a6a70a61c93ab868595d7da10bc4',1,'RNifti::NiftiImage::sform()']]],
  ['size_113',['size',['../a00018.html#abea0aea457bd6e8269098ccfab03c147',1,'RNifti::NiftiImageData::size()'],['../a00062.html#acac314c80dfd46755ab2db65f62fcccc',1,'RNifti::NiftiImage::Extension::size()']]],
  ['slice_114',['slice',['../a00054.html#ad8c9cb9aa058c5bd950822851ab03a37',1,'RNifti::NiftiImage::slice(const int i) const'],['../a00054.html#a9ca2e864f59b482e52c8553d029662ac',1,'RNifti::NiftiImage::slice(const int i)']]],
  ['slope_115',['slope',['../a00018.html#a5d74d8ab82313364907a532494efbb6c',1,'RNifti::NiftiImageData']]],
  ['spacing_116',['spacing',['../a00066.html#a4c8dab9a58f135f3490ad5aae348fab4',1,'RNifti::NiftiImage::Xform']]],
  ['squarematrix_117',['SquareMatrix',['../a00050.html',1,'RNifti::SquareMatrix&lt; NiftiType, ElementType, Order &gt;'],['../a00050.html#a017d7ca6b19661e64119ceafe916be13',1,'RNifti::SquareMatrix::SquareMatrix(const ElementType value=0.0)'],['../a00050.html#a1fb379388f50b5dc9c245a8c095c0a23',1,'RNifti::SquareMatrix::SquareMatrix(const ElementType *source)'],['../a00050.html#acccc89637c87d53ec93a655bc3ab956e',1,'RNifti::SquareMatrix::SquareMatrix(const NiftiType &amp;source)'],['../a00050.html#aa872cd0f7fe78bdaedd2dae347b1fe4a',1,'RNifti::SquareMatrix::SquareMatrix(SEXP source)']]],
  ['submatrix_118',['submatrix',['../a00066.html#aa784708bd351245fcf5c2c35cafbbae9',1,'RNifti::NiftiImage::Xform']]]
];
