var searchData=
[
  ['typehandler_146',['TypeHandler',['../a00022.html',1,'RNifti::NiftiImageData']]]
];
