var searchData=
[
  ['matrix_197',['matrix',['../a00066.html#ab5b8cff4b16d2a4e8d495d10a833342c',1,'RNifti::NiftiImage::Xform']]],
  ['minmax_198',['minmax',['../a00018.html#a54d136635f5598a75f4816c2d2a85a39',1,'RNifti::NiftiImageData']]],
  ['multiply_199',['multiply',['../a00050.html#a61fae0214e5fcd8a3de3ab95b12f071d',1,'RNifti::SquareMatrix::multiply(const MatrixType &amp;other) const'],['../a00050.html#ab3d42f8203abceeee8423b497f1ec3ab',1,'RNifti::SquareMatrix::multiply(const VectorType &amp;vec) const']]]
];
