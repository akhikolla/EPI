var searchData=
[
  ['data_162',['data',['../a00058.html#a09a1228a7a914f685b7bec62fb640f72',1,'RNifti::NiftiImage::Block::data()'],['../a00062.html#a4af9b30ee610bd28f729865c68622de1',1,'RNifti::NiftiImage::Extension::data()'],['../a00054.html#a72e6b937fe66d57733dcdd5b21a35329',1,'RNifti::NiftiImage::data() const'],['../a00054.html#ab0d6288e0cc591cd6bb374429efeef93',1,'RNifti::NiftiImage::data()']]],
  ['datatype_163',['datatype',['../a00018.html#a01e006a430bec6822bfd9bb696041596',1,'RNifti::NiftiImageData']]],
  ['determ_164',['determ',['../a00050.html#aa8eba984627826cad5f65d25b9277b88',1,'RNifti::SquareMatrix']]],
  ['dim_165',['dim',['../a00054.html#a0bd61daf1466767abfc153b013e8a30a',1,'RNifti::NiftiImage']]],
  ['disown_166',['disown',['../a00018.html#a5f145b2f0d45a22a27144a638cb2f2ec',1,'RNifti::NiftiImageData']]],
  ['drop_167',['drop',['../a00054.html#a73e10f56037f2f41bd5d306c29b3b4f1',1,'RNifti::NiftiImage']]],
  ['dropdata_168',['dropData',['../a00054.html#aad6f31a5bfc073ef4ea0648c29d75932',1,'RNifti::NiftiImage']]],
  ['dropextensions_169',['dropExtensions',['../a00054.html#aafe04778838023cbf6a75d00d21796c0',1,'RNifti::NiftiImage']]]
];
