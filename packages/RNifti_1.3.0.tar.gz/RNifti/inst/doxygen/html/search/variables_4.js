var searchData=
[
  ['image_266',['image',['../a00058.html#a44ac6e7ad9b070041bad4a63724d76b3',1,'RNifti::NiftiImage::Block::image()'],['../a00054.html#a82c4e0968f416972783a3cad00b4a1dc',1,'RNifti::NiftiImage::image()']]],
  ['index_267',['index',['../a00058.html#a5d929aeb499bedf7a55dc33fb45dbac3',1,'RNifti::NiftiImage::Block']]],
  ['intercept_268',['intercept',['../a00018.html#a7a5af7b5c106f31623783560e00aca68',1,'RNifti::NiftiImageData']]]
];
