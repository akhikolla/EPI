var searchData=
[
  ['squarematrix_145',['SquareMatrix',['../a00050.html',1,'RNifti']]]
];
