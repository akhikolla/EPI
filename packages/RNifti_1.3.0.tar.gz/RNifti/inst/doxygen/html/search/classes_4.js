var searchData=
[
  ['niftiimage_142',['NiftiImage',['../a00054.html',1,'RNifti']]],
  ['niftiimagedata_143',['NiftiImageData',['../a00018.html',1,'RNifti']]]
];
