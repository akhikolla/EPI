var searchData=
[
  ['vectortype_276',['VectorType',['../a00050.html#a5ff1f331a1d30bd850458186ecf029ba',1,'RNifti::SquareMatrix']]]
];
