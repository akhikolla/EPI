#' @import graphics
#' @import grDevices
#' @importFrom Rcpp evalCpp
#' @importFrom stats quantile
#' @importFrom utils object.size
#' @useDynLib RNifti
NULL
