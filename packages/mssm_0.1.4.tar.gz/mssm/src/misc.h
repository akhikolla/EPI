#ifdef USE_THREAD_LOCAL
#define M_THREAD_LOCAL thread_local
#else
#define M_THREAD_LOCAL
#endif
