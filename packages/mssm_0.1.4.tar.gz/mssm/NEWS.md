# mssm 0.1.4
* fix LTO issue due to testthat.

# mssm 0.1.3
* fix Fortran LTO issue.

# mssm 0.1.2
* two types of antithetic variables is now supported.
