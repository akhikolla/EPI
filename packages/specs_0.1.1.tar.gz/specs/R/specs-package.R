## usethis namespace: start
#' @useDynLib specs
#' @importFrom Rcpp evalCpp sourceCpp
#' @useDynLib specs, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
