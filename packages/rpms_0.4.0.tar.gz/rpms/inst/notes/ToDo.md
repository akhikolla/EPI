
# daniell's rpms ToDo list 

  
### Priority

* split on missing as category?
     * if category = easy
      - Done 4/20/2018
     * if numeric try as +\infty or -\infty
       - does this make sense?

* provide basic plot method

* do all of split entirely in C++
  - Done 1/20/2018


***

### Secondary


* provide domain estimate ??

* provide survey weights from (MAT research) ??

***

### Maybe

* make compatible with Lumley's "survey" package ???

* multi-variate y
  nonresponse adjustment ???

* provide user interface?



***


