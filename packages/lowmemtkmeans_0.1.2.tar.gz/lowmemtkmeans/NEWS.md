lowmemtkmeans 0.1.2
=============

Bug in initial cluster centre randomization fixed.
