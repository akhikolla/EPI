library(testthat)
library(lowmemtkmeans)

test_check("lowmemtkmeans")
