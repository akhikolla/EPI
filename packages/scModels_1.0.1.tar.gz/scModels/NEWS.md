# Todo

* Add configure script to set mpfr library prefix

# scModels 1.0.1

* Fixed mpfr warnings


# scModels 1.0.0

* Added a `NEWS.md` file to track changes to the package.
* Added examples to all functions.
* Fixed copyrights.
* Added doi of our paper.

