library(testthat)
library(scModels)

test_check("scModels")
