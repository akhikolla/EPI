.onUnload <- function(libpath) {
  library.dynam.unload("netrankr", libpath)
}
