library(testthat)
library(netrankr)

test_check("netrankr")
