# mrbayes 0.2.0

* IVW implemented using rstan.
* MR-Egger implemented using rstan.
* Radial MR-Egger implemented using rstan.

# mrbayes 0.1.0

* IVW, MR-Egger, and their radial versions implemented using JAGS.
