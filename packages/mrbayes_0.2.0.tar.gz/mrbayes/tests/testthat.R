library(testthat)
library(mrbayes)

test_check("mrbayes")
