#' @useDynLib SpaCCr
#' @importFrom Rcpp sourceCpp
NULL
stub <- function(){
  return(TRUE)
}
