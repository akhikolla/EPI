library(testthat)
library(SpaCCr)

test_check("SpaCCr")
