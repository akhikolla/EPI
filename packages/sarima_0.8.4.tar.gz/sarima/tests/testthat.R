## Sys.setenv(R_TESTS="")
library(testthat)
library(sarima)

test_check("sarima")
