library(testthat)
library(mapdeck)

test_check("mapdeck")
