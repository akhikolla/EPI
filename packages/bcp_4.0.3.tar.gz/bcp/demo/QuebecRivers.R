data(QuebecRivers)
bcpr.rivers <- bcp(QuebecRivers)
plot(bcpr.rivers, main="Quebec River Streamflow Change Point Analysis", xlab="Year", xaxlab = 1972:1994)
