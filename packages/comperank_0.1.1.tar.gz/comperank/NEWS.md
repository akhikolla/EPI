# comperank 0.1.1

* Reaction to `tibble` 3.0.0.

# comperank 0.1.0

* Initial release.
