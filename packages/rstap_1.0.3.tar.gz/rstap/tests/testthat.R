library(testthat)
library(rstap)

test_check("rstap")
