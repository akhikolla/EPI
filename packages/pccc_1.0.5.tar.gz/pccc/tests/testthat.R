library(testthat)
library(pccc)

test_check("pccc")
