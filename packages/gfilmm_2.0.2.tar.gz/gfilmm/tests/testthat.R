library(testthat)
library(gfilmm)

test_check("gfilmm")
