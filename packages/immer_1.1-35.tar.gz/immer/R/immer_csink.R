## File Name: immer_csink.R
## File Version: 0.04


immer_csink <- function(file)
{
    CDM::csink( file=file )
}
