## File Name: vcov.immer.R
## File Version: 0.12

vcov.immer_ccml <- function(object, ... )
{
    return( object$vcov )
}

vcov.immer_cml <- function(object, ... )
{
    return( object$vcov )
}

vcov.immer_latent_regression <- function(object, ... )
{
    return( object$vcov )
}
