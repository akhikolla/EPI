## File Name: immer_summary_print_package_rsession.R
## File Version: 0.01

immer_summary_print_package_rsession <- function(pack)
{
    sirt::sirt_summary_print_package_rsession(pack=pack)
}
