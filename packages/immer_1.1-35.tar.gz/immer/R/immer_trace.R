## File Name: immer_trace.R
## File Version: 0.01

immer_trace <- function(x)
{
    sum(diag(x))
}
