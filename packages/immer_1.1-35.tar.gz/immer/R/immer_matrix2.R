## File Name: immer_matrix2.R
## File Version: 0.01

immer_matrix2 <- function(x, nrow)
{
    y <- TAM::tam_matrix2(x=x, nrow=nrow)
    return(y)
}
