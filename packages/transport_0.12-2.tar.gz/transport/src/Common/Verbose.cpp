#include"Verbose.h"

#ifdef VERBOSE_DYN
bool verbose_mode=true;
#endif
