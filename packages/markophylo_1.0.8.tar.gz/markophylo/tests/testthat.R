library(testthat)
library(markophylo)

test_check("markophylo")
