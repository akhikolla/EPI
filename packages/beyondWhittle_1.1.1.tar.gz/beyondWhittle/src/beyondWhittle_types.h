#include "bernstein_gamma_psd.h"

typedef bernsteinGammaPsd bernsteinGammaPsd;
