library(testthat)
library(treenomial)

test_check("treenomial")
