# treenomial 1.1.3

* Add the new default metric "fraction"

# treenomial 1.1.2

* Fixed a bug with the treeDist function when using the y evaluated form 

# treenomial 1.1.1

* Fixed errors when checking input arguments to functions 

* added a variable names option for treeToPoly to print variable names on corresponding coefficient matrices rows and columns 

* added a option to convert to polynomials evaluated at a specified y rather than at fixed y = 1+1i 

# treenomial 1.0.1

* Fixed a bug in the treeToPoly function 

# treenomial 1.0.0

* Initial package release
