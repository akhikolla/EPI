library(testthat)
library(scorepeak)
test_check("scorepeak")