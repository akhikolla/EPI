void start_noop();
void end_noop();
