void parse_send_args(po::variables_map& vm, std::vector<std::string> pairs);
void setup_send();
void destroy_send();
