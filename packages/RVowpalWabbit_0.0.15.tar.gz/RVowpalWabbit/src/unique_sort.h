#ifndef UNIQUE_SORT
#define UNIQUE_SORT
#include "parser.h"
#include "example.h"

void unique_sort_features(example* ae);

#endif
