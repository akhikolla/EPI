#ifndef MESSAGE_RELAY_H
#define MESSAGE_RELAY_H

void setup_relay(void*);

void destroy_relay();

#endif
