#ifndef NETWORK_H
#define NETWORK_H

int open_socket(const char* host);

#endif
