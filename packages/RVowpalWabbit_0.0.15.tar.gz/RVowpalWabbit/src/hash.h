/*
Copyright (c) 2009 Yahoo! Inc.  All rights reserved.  The copyrights
embodied in the content of this file are licensed under the BSD
(revised) open source license
 */

const uint32_t hash_base = 97562527;
uint32_t uniform_hash( const void *key, size_t length, uint32_t initval);
