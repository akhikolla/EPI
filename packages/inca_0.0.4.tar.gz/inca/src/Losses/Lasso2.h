#ifndef LASSO2_HPP
#define LASSO2_HPP

#include <RcppArmadillo.h>

namespace Lasso2 {

}

#endif // LASSO2_HPP

