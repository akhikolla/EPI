#ifndef LASSO1_HPP
#define LASSO1_HPP

#include <RcppArmadillo.h>

namespace Lasso1 {

}

#endif // LASSO1_HPP

