library(testthat)
library(pcFactorStan)

test_check("pcFactorStan")
