library(testthat)
library(RPostgres)

test_check("RPostgres")
