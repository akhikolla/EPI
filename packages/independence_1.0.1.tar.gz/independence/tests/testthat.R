library(testthat)
library(independence)

test_check("independence")
