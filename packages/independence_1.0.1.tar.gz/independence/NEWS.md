# independence 1.0.1

* Added a `NEWS.md` file to track changes to the package.

* Added reference to https://arxiv.org/abs/2010.09712 "independence: Fast Rank Tests"
