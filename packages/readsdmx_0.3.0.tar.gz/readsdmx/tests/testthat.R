library(testthat)
library(readsdmx)

test_check("readsdmx")
