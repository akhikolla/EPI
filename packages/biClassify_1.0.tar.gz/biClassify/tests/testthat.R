library(testthat)
library(biClassify)

test_check("biClassify")
