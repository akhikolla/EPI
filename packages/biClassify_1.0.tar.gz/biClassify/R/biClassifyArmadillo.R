#' @useDynLib biClassify
#' @importFrom Rcpp evalCpp
#' @export KOS 
#' @export SelectParams
NULL