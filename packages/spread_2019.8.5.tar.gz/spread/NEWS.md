# spread 2019.8.5

Submitted to CRAN.

Exported functions:

- commuter
- convert_blank_seiiar_with_vax

Exported datasets:

- norway_commuters_2017
- norway_seiiar_noinfected_2017
- norway_seiiar_oslo_2017
- norway_seiiar_measles_noinfected_2017
- norway_seiiar_measles_oslo_2017
