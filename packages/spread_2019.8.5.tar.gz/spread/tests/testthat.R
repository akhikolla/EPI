library(testthat)
library(spread)

test_check("spread")
