#' @useDynLib spread, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL
