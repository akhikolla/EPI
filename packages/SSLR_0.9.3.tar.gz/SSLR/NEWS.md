
# SSLR 0.9.3

## Other Changes

* Clustering models
* GRFClassifier (Transductive model)

# SSLR 0.9.2

## Other Changes

* prob predict in SSLRRandomForest


# SSLR 0.9.1

## Other Changes

* snnrce with c++ functions
* Added URL in Description

# SSLR 0.9.0

First CRAN release

* First implementation

