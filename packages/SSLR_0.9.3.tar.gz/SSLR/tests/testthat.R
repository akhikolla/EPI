library(testthat)
require(SSLR)

test_check("SSLR")
