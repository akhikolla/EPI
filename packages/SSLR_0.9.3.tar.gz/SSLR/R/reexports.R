#' @importFrom generics fit
#' @export
generics::fit

#' @importFrom generics fit_xy
#' @export
generics::fit_xy
