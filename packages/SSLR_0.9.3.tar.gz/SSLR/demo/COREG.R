library(SSLR)

m <- COREG(max.iter = 1)

