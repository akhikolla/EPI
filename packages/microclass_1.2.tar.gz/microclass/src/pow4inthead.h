int pow4int(int K);
