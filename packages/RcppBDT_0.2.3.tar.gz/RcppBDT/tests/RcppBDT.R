
demo(RcppBDT, package="RcppBDT")
