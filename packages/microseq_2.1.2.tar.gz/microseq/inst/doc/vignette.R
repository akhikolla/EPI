### R code from vignette source 'vignette.Rnw'

###################################################
### code chunk number 1: vignette.Rnw:33-34 (eval = FALSE)
###################################################
## system("muscle -h")


###################################################
### code chunk number 2: vignette.Rnw:41-42 (eval = FALSE)
###################################################
## system("barrnap -h")


###################################################
### code chunk number 3: vignette.Rnw:49-50 (eval = FALSE)
###################################################
## system("prodigal -h")


