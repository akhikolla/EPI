library(testthat)
library(sourceR)

test_check("sourceR")
