Rcpp::loadModule("HashTable_module")

