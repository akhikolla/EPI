library(testthat)
library(glca)

test_check("glca")
