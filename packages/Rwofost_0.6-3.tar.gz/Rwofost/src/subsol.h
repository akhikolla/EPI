
double SUBSOL (double PF, double D, std::vector<double> CONTAB);// flow is output
