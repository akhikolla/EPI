# ebmstate

### Source code for the R package 'ebmstate', a package for multi-state survival analysis under empirical Bayes Cox models.
 
