library(testthat)
library(RcppHNSW)

test_check("RcppHNSW")
