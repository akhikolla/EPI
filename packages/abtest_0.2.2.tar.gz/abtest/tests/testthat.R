library(testthat)
library(abtest)

test_check("abtest")
