// [[Rcpp::depends(Rcpp)]]
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp11)]]

#ifndef CONSSTITUER_MATRICE_EFFECTIFS_H
#define CONSSTITUER_MATRICE_EFFECTIFS_H

arma::Mat<int> constituerMatriceEffectifs(IntegerVector vLigneObservation, IntegerVector vColonneObservation)
  
#endif
