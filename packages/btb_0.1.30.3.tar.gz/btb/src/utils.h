#ifndef UTILS_H
#define UTILS_H

void quickSort(std::vector<double>& vModalites, std::vector<double>& vPonderations, int iLeft, int iRight);

#endif
