#' @name anolis
#' @title Anole data
#' @description Anole data for aRbor functions
#' @docType data
#' @usage data(anolis)
"anolis"