# blatent
Bayesian Latent Variable Models in R
