initUnitsVariable = function(variable, data){

  newData = variable$routines$sampleUnits$runInit(data = data)
  return(newData)
}
