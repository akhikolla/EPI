bias = function(est, true){

  return(mean(est-true))

}
