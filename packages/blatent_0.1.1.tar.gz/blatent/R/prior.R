prior = function(distribution = "normal", mean = 0, variance = 1){
  return(list(mean = mean, variance = variance))
}
