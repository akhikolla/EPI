MAD = function(x, y){
  return(mean(abs(x-y)))
}
