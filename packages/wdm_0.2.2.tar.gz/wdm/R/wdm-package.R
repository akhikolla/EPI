#' @title \packageTitle{wdm}
#'
#' @description
#' \packageDescription{wdm}
#'
#' @details
#' The DESCRIPTION file:
#' \packageDESCRIPTION{VineCopula}
#'
#' @name wdm-package
#' @aliases wdm-package
#' @docType package
#' @useDynLib wdm, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL

