library(testthat)
library(Rrelperm)

test_check("Rrelperm")
