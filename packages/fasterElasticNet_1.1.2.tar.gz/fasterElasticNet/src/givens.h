#ifndef givens_H
#define givens_H
#include <RcppArmadillo.h>

void givens(arma::mat & L, arma::uword & k);

#endif
