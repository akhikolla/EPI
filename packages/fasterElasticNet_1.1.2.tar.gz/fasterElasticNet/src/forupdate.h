#ifndef forupdate_H
#define forupdate_H
#include <RcppArmadillo.h>

void forupdate(arma::mat & L, arma::vec & xxk, double & xkxk);

#endif
