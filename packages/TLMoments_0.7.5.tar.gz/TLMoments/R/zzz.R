#' @import stats Rcpp
#' @useDynLib TLMoments, .registration = TRUE
.onAttach <- function(libname, pkgname) {
  #packageStartupMessage(">> TLMoments master version 0.7.4.1")
}
