library(testthat)
library(epinetr)

test_check("epinetr")
