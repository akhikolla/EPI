library(testthat)
library(quantregRanger)

test_check("quantregRanger")
