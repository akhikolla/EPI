
.onUnload <- function (libpath) {
  library.dynam.unload("imbalance", libpath)
}
