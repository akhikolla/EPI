# imbalance 1.0.2
  * Minor fixes regarding compilation flags
  * Adapts code to work with `class(matrix)` returning `c(array, matrix)`

# imbalance 1.0.1
  * Adds citation info

# imbalance 1.0.0
  * Wrapper oversample for algorithms in other packages
  * Adds default wrappers for wracog, changed parameters for this method

# imbalance 0.1.1
  * Small patch for C++ portability under different OSs

# imbalance 0.1.0
  * First release
  * Methods of oversampling included: mwmote, pdfos, rwo, racog, wracog
  * Methods of filtering: neater
