library(testthat)
library(rags2ridges)

test_check("rags2ridges")
