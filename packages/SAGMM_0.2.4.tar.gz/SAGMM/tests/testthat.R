library(testthat)
library(SAGMM)

test_check("SAGMM")
