# SAGMM 0.2.4

Removed superfluous dependency to fix namespace clash.

# SAGMM 0.2.3

First published version


