## CHANGES IN nametagger VERSION 0.1.1

- Move udpipe to Suggests instead of Imports, remove crfsuite from Suggests
- Make example conditionally on availability of udpipe

## CHANGES IN nametagger VERSION 0.1.0

- Initial package based on https://github.com/ufal/nametag commit 598666b5aa2f3ebbb9658976fe06749f551aed02
