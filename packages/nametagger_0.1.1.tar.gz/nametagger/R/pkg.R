#' @importFrom Rcpp evalCpp
#' @importFrom utils capture.output unzip download.file
#' @useDynLib nametagger
NULL
