library(testthat)
library(SSOSVM)

test_check("SSOSVM")
