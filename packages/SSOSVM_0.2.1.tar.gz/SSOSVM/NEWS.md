#SSOSVM 0.2.1
First published version