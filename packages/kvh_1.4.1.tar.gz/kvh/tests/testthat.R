Sys.setenv("R_TESTS" = "")
library(testthat)
library(Rcpp)
library(kvh)
