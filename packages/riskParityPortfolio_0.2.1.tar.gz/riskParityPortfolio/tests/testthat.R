library(testthat)
library(riskParityPortfolio)

test_check("riskParityPortfolio")
