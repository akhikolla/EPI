library(testthat)
library(higlasso)
test_check("higlasso")
