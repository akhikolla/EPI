# higlasso v0.9.0
* Initial CRAN release

# higlasso v0.2.0
* Beta version of higlasso used in paper
