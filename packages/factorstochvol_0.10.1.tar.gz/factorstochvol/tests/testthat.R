library(testthat)
library(factorstochvol)

test_check("factorstochvol")
