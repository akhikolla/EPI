library('testthat')
library('TBRDist')

test_check("TBRDist")
