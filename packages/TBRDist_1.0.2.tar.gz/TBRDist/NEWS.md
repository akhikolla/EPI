# TBRDist 1.0.2

- Import RdMacros package 'Rdpack'.

# TBRDist 1.0.1

- Address memory mismanagement in `USPRDist()`.

# TBRDist 1.0.0

- Initial implementation of distances on unrooted trees.
