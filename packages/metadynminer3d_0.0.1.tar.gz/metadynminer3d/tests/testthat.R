library(testthat)
library(metadynminer3d)

test_check("metadynminer3d")
