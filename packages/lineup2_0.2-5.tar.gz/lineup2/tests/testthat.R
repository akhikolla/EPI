library(testthat)
test_check("lineup2")
