#' @keywords internal
#' @importFrom Rcpp sourceCpp
#' @useDynLib lineup2, .registration=TRUE
#'
#'
"_PACKAGE"
