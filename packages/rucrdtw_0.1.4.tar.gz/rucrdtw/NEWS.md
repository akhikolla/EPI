# rucrdtw 0.1.4

* updated code in anticipation of stringsAsFactors = FALSE in forthcoming R versions
* adjusted examples and vignettes to accommodate run-times of examples that are numerically zero
* updated citation information in README


# rucrdtw 0.1.3

* Fixed memory leaks in C++ routines

# rucrdtw 0.1.2

* Added a `NEWS.md` file to track changes to the package
* Updated CITATION to reflect publication in JOSS
* C++ routines are registered now
* vignette now uses the rbenchmark package instead of microbenchmark


