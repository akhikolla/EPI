library(testthat)
library(rucrdtw)

test_check("rucrdtw")
