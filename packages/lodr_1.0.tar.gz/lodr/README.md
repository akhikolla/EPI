# lodr
R package for analyzing covariates subject to a limit of detection
