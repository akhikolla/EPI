![Build Status](https://travis-ci.org/sdcTools/sdcMicro.svg?branch=master)
[![Coverage Status](https://coveralls.io/repos/github/sdcTools/sdcMicro/badge.svg?branch=master)](https://coveralls.io/github/sdcTools/sdcMicro?branch=master)
[![CRAN](http://www.r-pkg.org/badges/version/sdcMicro)](https://CRAN.R-project.org/package=sdcMicro)
[![Downloads](http://cranlogs.r-pkg.org/badges/sdcMicro)](https://CRAN.R-project.org/package=sdcMicro)
[![Mentioned in Awesome Official Statistics ](https://awesome.re/mentioned-badge.svg)](http://www.awesomeofficialstatistics.org)

sdcMicro
========

**sdcMicro** is an R-package to anonymize microdata. Most functionalities of the package are also available via an interactive shiny-based graphical user interface.

 [Online documentation](http://sdctools.github.io/sdcMicro/index.html)