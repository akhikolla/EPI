
// Function within a different Namespace, depending of the Matching Type
int weighted(vertex_type *v, int n, vertex_type *u);
int match_check(vertex_type *v, int n);
BOOL dual_check(vertex_type *v, int n, vertex_type *u);
