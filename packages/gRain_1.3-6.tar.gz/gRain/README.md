# gRain

 [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/hojsgaard/gRain?branch=master&svg=true)](https://ci.appveyor.com/project/hojsgaard/gRain)
