library(testthat)

if (T){
    library(gRain)

    test_check("gRain")
}
