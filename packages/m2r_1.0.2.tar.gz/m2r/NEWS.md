# m2r 1.0.1

## New features

* The LLL algorithm is now implemented as LLL().  (Thanks to Rudy Yoshida
  for the request.)

## Changes

* Citation is now requested upon loading. Package startup messages are
  indented for prettier printing in algstat (consistent with latter).

* The package now suggests microbenchmark.

* Added a `NEWS.md` file to track changes to the package.

* Pathing is now governed by environmental variables instead of path searching.
