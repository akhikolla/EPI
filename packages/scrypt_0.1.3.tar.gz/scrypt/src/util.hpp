#ifndef UTIL_HPP
#define UTIL_HPP

int getcpuperf(double*);

int getmemlimit(size_t*);

int getsalt(uint8_t salt[32]);

#endif // UTIL_HPP
