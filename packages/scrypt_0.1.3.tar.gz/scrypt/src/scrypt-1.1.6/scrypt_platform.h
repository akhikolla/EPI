#ifndef _SCRYPT_PLATFORM_H_
#define _SCRYPT_PLATFORM_H_

#if defined(HAVE_CONFIG_H)
#include "config.h"
#endif

#endif /* !_SCRYPT_PLATFORM_H_ */
