print.genfrail <- function(x, ...) {
  print(as.data.frame(x), ...)
}