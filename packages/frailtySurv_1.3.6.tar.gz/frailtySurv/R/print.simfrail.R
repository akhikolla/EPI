print.simfrail <- function(x, ...) {
  print(as.data.frame(x))
}