#' A small random tridiagonal matrix
#'
#' A small random tridiagonal matrix used only to demonstrate the package's algorithms in the \code{examples} sections of the package documentation.
"triA"
