#' A small random matrix
#'
#' A small random matrix used only to demonstrate the package's algorithms in the \code{examples} sections of the package documentation.
"A"
