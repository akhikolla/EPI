library(testthat)
library(expperm)

test_check("expperm")
