#' netcontrol
#' 
#' Description of your package
#' 
#' @docType package
#' @author Teague Henry
#' @import Rcpp Matrix
#' @importFrom Rcpp evalCpp
#' @importFrom Rdpack reprompt
#' @importFrom MASS mvrnorm
#' @importFrom pracma pinv
#' @importFrom expm %^%
#' @useDynLib netcontrol
#' @name netcontrol
NULL  