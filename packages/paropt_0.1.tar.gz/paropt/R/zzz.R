.onAttach <- function(...){
  packageStartupMessage("SUNDIALS - Copyright (c) 2002-2015, Lawrence Livermore National Laboratory.
Produced at the Lawrence Livermore National Laboratory.
See - https://computation.llnl.gov/projects/sundials
PSO: See - https://github.com/kthohr/optim")}
