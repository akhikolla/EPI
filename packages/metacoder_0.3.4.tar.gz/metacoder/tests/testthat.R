library(testthat)

suppressPackageStartupMessages(library(metacoder))

test_check("metacoder")
