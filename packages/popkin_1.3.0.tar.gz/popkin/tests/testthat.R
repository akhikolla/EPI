library(testthat)
library(popkin)

test_check('popkin')
