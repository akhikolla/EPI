# Rlinsolve 0.3.1

* Added a `NEWS.md` file to track changes to the package.
* Partial support for bigmemory is dropped due to its instability. We expect it to be running smooth in the future.
