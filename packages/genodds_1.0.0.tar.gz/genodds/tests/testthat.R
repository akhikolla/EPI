library(testthat)
library(genodds)

test_check("genodds")
