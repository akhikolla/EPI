# genodds 1.0

Package released
