library(testthat)
library(bsem)

test_check("bsem")
