library(testthat)
library(bpcs)

test_check("bpcs")
