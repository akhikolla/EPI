# robustBLME
 This is an R implementation of the method proposed by Ruli et al. (2017). It gives routines for Bayesian robust fitting of linear mixed effects models though weighted likelihood equations and approximate Bayesian computation.
