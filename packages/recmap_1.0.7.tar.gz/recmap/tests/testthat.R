#R


library(testthat)

suppressPackageStartupMessages(library(recmap))

test_check("recmap")

