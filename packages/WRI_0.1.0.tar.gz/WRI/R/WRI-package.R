## usethis namespace: start
#' @useDynLib WRI, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
