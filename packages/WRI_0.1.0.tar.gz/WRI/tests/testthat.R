library(testthat)
library(WRI)

test_check("WRI")
