library(testthat)
library(jackalope)

test_check("jackalope")
