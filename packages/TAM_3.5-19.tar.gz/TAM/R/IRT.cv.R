## File Name: IRT.cv.R
## File Version: 0.03



# S3 method
IRT.cv <- function(object, ...)
{
    UseMethod("IRT.cv")
}

