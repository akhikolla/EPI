## File Name: tam.jml2.R
## File Version: 9.71

tam.jml2 <- function(...){
    .Defunct(new="tam.jml", package="TAM")
}
