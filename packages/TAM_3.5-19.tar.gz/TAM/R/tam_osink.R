## File Name: tam_osink.R
## File Version: 0.04

tam_osink <- function(file, suffix="__SUMMARY.Rout")
{
    CDM::osink( file=file, suffix=suffix )
}
