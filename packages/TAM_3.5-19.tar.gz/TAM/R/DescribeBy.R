## File Name: DescribeBy.R
## File Version: 9.03


#####################################################
# S3 method DescribeBy
DescribeBy <- function (object, ...) {
    UseMethod("DescribeBy")
}
#####################################################
