## File Name: tam_csink.R
## File Version: 0.01

tam_csink <- function(file)
{
    CDM::csink(file=file)
}
