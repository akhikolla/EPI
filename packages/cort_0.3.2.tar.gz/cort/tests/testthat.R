library(testthat)
library(cort)

test_check("cort")
