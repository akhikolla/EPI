# liger v1.1
* Add main option to gsea plotting for title

# liger v1.0
* CRAN resubmission to address "duplicated titles" issue 
 noted by Prof Brian Ripley. Add new vignette and bump up version.

# liger v0.1
* Initial release to CRAN
