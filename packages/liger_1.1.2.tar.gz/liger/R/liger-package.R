#' liger
#' 
#' This package contains permutation-based gene set enrichment functionalities in R
#' 
#' @name liger
#' @docType package
#' 
#' @useDynLib liger
#' @importFrom Rcpp evalCpp
NULL