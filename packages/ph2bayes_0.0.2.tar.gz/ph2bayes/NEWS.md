
# The 'ph2bayes' package


## Changes in version 0.0.2 (2018-02-23)

* Updated according to the CRAN policies


## Changes in version 0.0.1 (2016-01-18)

* First release

