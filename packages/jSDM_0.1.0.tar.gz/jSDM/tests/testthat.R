library(testthat)
library(jSDM)

test_check("jSDM")
