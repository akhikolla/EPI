#' The binarized drug-target data for the Miller drugs
#'
#' The binarized drug-target data for the Miller drugs

#' @format A data frame contains drug names, target names, and binding affities
#' @name miller_interaction_binary
NULL