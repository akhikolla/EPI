#' A drug list from Miller study
#'
#' The drug list from the Miller study

#' @format A data frame with drug information from the Miller study
#' @name miller_drugs
NULL