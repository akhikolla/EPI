#' The single drug does-response data from the Miller study
#'
#' The single drug does-response data from the Miller study.
#' @format A data frame contains the drug response from Miller study
#' @name miller_drug_response
NULL