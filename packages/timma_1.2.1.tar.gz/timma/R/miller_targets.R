#' The curated drug-target data for the Miller drugs
#'
#' The curated drug-target data for the Miller drugs

#' @format A data frame contains 234 targets information for 14 drugs
#' @name miller_targets
NULL