#' The scaled drug sensitivity data for the Miller drugs
#'
#' The scaled drug sensitivity data for the Miller drugs 

#' @format A matrix with drugs as row indexes and entries are drug sensitivities
#' @name miller_sensitivity
NULL