#' The combination index extracted from Figure 1B of the Miller study
#'
#' The combination index extracted from Figure 1B of the Miller study
#' @name ci
NULL