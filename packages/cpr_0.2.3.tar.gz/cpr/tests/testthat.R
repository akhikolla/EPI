library(testthat)
library(cpr)

test_check("cpr")
