library(testthat)
library(segclust2d)

test_check("segclust2d")
