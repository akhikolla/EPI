library(testthat)
library(lpirfs)

test_check("lpirfs")
