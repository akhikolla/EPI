
print.grid.roll.reg <- function(x, ...)
  {
   print(round(x$fq,digits=4),quote=FALSE)
   cat("\n")
  }
