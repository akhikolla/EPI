
print.grid.tvp <- function(x, ...)
  {
   print(round(x$fq,digits=4),quote=FALSE)
   cat("\n")
  }
