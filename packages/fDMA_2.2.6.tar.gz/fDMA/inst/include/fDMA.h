#ifndef fDMA
#define fDMA

#define ARMA_NO_DEBUG

#include <RcppArmadillo.h>
using namespace std;
using namespace arma;
using namespace Rcpp;

#endif
