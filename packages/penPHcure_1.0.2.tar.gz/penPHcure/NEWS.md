# penPHcure 1.0.2

* Fixed array overrun in the compute_survival_cpp(...) function in src/cure.std.fit.cpp

* Fixed minor issue in R/penPHcure.initialize.R regarding the formula objects cureform and survform.

* Documentation built using roxygen2 (v7.0.0).

# penPHcure 1.0.1

* Fixed minor issues for publication on CRAN

# penPHcure 1.0

* Initial CRAN release