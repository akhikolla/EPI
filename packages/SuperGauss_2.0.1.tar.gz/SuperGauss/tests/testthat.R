library(SuperGauss)
library(testthat)

test_check("SuperGauss")
