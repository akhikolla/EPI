library(testthat)
test_check("securitytxt")
