library(testthat)
library(mappoly)

test_check("mappoly")
