
# flying 0.1.3

* Rcpp warning in solaris fixed

* Two methods added in migrate; "csw" and "csp"

* migrate function allows for minimum energy percentage from protein.

