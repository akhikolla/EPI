library(testthat)
library(flying)
test_check("flying")
