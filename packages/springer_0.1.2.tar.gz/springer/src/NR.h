#ifndef NR_h
#define NR_h

#include<RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

arma::vec NR(arma::mat& matr1, arma::vec& matr2);

#endif
