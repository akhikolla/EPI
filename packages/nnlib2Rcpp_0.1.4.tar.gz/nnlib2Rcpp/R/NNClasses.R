BP   		<- Rcpp::setRcppClass("BP")
LVQs 		<- Rcpp::setRcppClass("LVQs")
MAM  		<- Rcpp::setRcppClass("MAM")
NN 			<- Rcpp::setRcppClass("NN")
