library(testthat)
library(quantities)

test_check("quantities")

detach("package:quantities", unload = TRUE)
