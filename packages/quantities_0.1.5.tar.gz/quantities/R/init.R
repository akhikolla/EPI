
.onLoad = function(libname, pkgname) {
  register_all_s3_methods()
}
