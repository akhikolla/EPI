Sys.setenv("R_TESTS" = "")

library(testthat)
library(rmdcev)
test_check("rmdcev")
