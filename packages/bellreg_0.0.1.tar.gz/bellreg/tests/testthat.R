library(testthat)
library(bellreg)

test_check("bellreg")
