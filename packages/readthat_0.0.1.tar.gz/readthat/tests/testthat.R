library(testthat)
library(readthat)

test_check("readthat")
