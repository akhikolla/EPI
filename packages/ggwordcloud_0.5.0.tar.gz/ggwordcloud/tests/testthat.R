library(testthat)
library(ggwordcloud)

test_check("ggwordcloud")
