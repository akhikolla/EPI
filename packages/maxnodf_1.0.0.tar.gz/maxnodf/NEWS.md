1.0.0
=====
- maxnodf() calculates the maximum NODF that can be achieved in a bipartite network.
- NODFc() calculates the NODF_c metric suggested by Song et al (2017).
- nodf_cpp calculates raw NODF rapidly using C++.