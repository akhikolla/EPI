library(testthat)
library(maxnodf)

test_check("maxnodf")
