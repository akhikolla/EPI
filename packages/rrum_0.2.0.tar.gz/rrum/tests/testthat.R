library(testthat)
library(rrum)

test_check("rrum")
