context("zeroin.h unit tests")

expect_equal(hesim:::test_zeroin(), 1/3)

