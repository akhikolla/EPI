library(testthat)
library(hesim)

test_check("hesim")
