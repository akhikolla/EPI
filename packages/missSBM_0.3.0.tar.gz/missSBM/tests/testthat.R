library(testthat)
library(missSBM)

test_check("missSBM")
