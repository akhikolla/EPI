library(testthat)
library(themetagenomics)

test_check("themetagenomics")
