# 'gbeta' package for R

Generalized Beta and Beta prime distributions.

![](https://raw.githubusercontent.com/stla/gbeta/master/inst/plots/dgbeta.png)

![](https://raw.githubusercontent.com/stla/gbeta/master/inst/plots/dgbetap.png)
