library(testthat)
library(SimBIID)

test_check("SimBIID")
