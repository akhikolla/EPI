# Copyright (c) 2020, ETH Zurich

library(testthat)
library(gen3sis)

test_check("gen3sis")
