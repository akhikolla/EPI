\dontrun{
  ## save phylogeny as a nexus tree from within observer for each species
  # this functions should be called inside the end_of_timestep_observer function at the config file:
  save_phylogeny()
}