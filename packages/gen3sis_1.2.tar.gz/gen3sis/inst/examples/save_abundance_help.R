\dontrun{
  ## save abundances from within observer
  # this functions should be called inside the end_of_timestep_observer function at the config file:
  save_abundance()
}