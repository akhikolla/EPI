library(testthat)
library(dodgr)

test_check("dodgr")
