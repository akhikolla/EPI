library(testthat)
test_check("qtl2convert")
