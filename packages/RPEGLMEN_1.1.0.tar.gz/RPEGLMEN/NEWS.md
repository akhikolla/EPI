# RPEGLMEN 1.0.0
* Initial stable release of package.

# RPEGLMEN 1.0.1
* Update title of the vignette.

# RPEGLMEN 1.1.0
* Adapt package to RPEIF 1.1.0.