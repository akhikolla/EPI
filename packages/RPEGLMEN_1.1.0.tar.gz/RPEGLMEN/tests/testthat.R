library(testthat)
library(RPEGLMEN)

test_check("RPEGLMEN")
