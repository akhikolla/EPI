library(testthat)
test_check("clustermq")
