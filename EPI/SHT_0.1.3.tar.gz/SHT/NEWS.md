# News for Package SHT
### Changes in version 0.1.3
  * Defensive protection for OpenMP. 

### Changes in version 0.1.2
  * Corrected example's multiline display of simulation results.
  * Change of maintainer's contact.
  
### Changes in version 0.1.1
  * Functions are added, a lot.
  * README invisible on CRAN. Later we'll add vignette.
  
### Changes in version 0.1.0
  * Package is first deployed.
  * Initialize the following documentation:
    - NEWS for keeping record of updates.
    - README to briefly introduce the method.