olc_full <- function(olc){

}

olc_short <- function(olc){

}

olc_valid <- function(olc){

}
