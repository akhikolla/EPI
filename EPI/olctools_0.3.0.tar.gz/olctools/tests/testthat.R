library(testthat)
library(olctools)

test_check("olctools")
