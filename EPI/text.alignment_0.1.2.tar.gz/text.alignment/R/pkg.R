#' @importFrom Rcpp evalCpp
#' @useDynLib text.alignment
NULL


