library(testthat)
library(kdecopula)

test_check("kdecopula")
