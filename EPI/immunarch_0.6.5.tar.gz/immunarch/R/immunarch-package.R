## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib immunarch, .registration = TRUE
## usethis namespace: end
NULL
