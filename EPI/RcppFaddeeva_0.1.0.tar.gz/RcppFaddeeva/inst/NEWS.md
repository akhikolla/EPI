# RcppFaddeeva 0.1

* Initial version
