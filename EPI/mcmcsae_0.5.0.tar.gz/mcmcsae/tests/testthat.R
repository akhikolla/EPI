library(testthat)
test_check("mcmcsae")
