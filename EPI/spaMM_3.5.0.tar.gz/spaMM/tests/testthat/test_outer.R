if (file.exists((privtest <- "C:/home/francois/travail/stats/spaMMplus/spaMM/package/tests_private/test_outer.R"))) {
  source(privtest)
}