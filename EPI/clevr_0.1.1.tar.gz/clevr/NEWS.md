# clevr 0.1.1
* Fix behavior when pairs are represented using different types
* Improve documentation by adding examples
* First release to CRAN

# clevr 0.1.0
* Initial release
