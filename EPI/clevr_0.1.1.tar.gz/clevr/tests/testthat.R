library(testthat)
library(clevr)

test_check("clevr")
