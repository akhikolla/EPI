shrinkcovmathat <- function(x, ...) UseMethod("shrinkcovmathat")
