library("testthat")
library("ShrinkCovMat")

test_check("ShrinkCovMat")
