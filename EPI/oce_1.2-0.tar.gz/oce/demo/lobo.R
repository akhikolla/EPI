library(oce);
data(lobo)
summary(lobo)
plot(lobo)
