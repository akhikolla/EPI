library(testthat)
library(TDAstats)

test_check("TDAstats")
