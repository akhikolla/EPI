library(shiny)

source("tables.R", local = TRUE)
source("plots.R", local = TRUE)
source("main.R", local = TRUE)
source("ui.R", local = TRUE)
source("server.R", local = TRUE)
