RNGkind("default")
default_rngkind <- RNGkind()[1L]
