library(testthat)
library(belg)

test_check("belg")
