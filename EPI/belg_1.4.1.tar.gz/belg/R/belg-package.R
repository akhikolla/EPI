#' @useDynLib belg
#' @importFrom Rcpp sourceCpp
#' @keywords internal
"_PACKAGE"
