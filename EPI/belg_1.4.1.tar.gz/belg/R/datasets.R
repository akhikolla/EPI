#' Complex landscape (small)
#'
#' A dataset containing small artificial complex landscape
#'
"complex_land"

#' Simple landscape (small)
#'
#' A dataset containing small artificial simple landscape
#'
"simple_land"

#' Complex landscape
#'
#' A dataset containing artificial complex landscape
#'
"land_gradient1"

#' Simple landscape
#'
#' A dataset containing artificial simple landscape
#'
"land_gradient2"
