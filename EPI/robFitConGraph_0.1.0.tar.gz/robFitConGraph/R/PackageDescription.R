#' A package for robust estimation of scatter matrices subject to zero- constraints in its inverse.
#'
#' robFitConGraph contains one function named after itself: \code{\link[robFitConGraph]{robFitConGraph}}.
#' @aliases robFitConGraph-package
"_PACKAGE"
