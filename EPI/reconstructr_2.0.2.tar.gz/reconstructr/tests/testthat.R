library(testthat)
library(reconstructr)

test_check("reconstructr")
