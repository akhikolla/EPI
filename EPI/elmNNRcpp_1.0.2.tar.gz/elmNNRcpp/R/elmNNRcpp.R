#' @useDynLib elmNNRcpp, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @import KernelKnn
NULL
