
## elmNNRcpp 1.0.2

* I fixed the documentation of the *'normal_gaussian'* weights (see issue: *https://github.com/mlampros/elmNNRcpp/issues/1*)
* I fixed the *'uniform_negative'* distribution (see issue: *https://github.com/mlampros/elmNNRcpp/issues/2*)


## elmNNRcpp 1.0.1

I added the *Github repository Url* and the *BugReports Url* in the DESCRIPTION file.


## elmNNRcpp 1.0.0

