library(testthat)
library(elmNNRcpp)

test_check("elmNNRcpp")
