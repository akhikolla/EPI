hardlim <-
function(x) {
  y <- ifelse(x >= 0, 1, 0)
  y
}
