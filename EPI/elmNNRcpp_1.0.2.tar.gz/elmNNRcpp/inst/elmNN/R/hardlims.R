hardlims <-
function(x) {
  y <- ifelse(x >= 0, 1, -1)
  y
}
