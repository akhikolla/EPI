library(testthat)
test_check("multdyn")
