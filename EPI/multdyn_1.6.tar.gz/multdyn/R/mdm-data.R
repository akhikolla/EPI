#' @name myts
#' @title Network simulation data.
#' @description Simulation 22 5 node net from Smith et al. 2011 (only first subject).
#' @docType data
NULL

#' @name utestdata
#' @title Results from v.1.0 for unit tests.
#' @description Some LPL values (n2 parent of n1 Simulation 22) to test against.
#' @docType data
NULL