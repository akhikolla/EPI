library(testthat)
library(nabor)
library(RANN)

test_check("nabor")
