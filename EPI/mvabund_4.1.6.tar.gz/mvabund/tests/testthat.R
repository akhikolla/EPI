library(testthat)
library(mvabund)

test_check("mvabund")
