gm <-
function (tm, te, method, ...) 
UseMethod("gm")
