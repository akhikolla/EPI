gmci <-
function (gm, alpha, ...) 
UseMethod("gmci")
