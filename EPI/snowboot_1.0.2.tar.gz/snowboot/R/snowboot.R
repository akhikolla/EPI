#' @useDynLib snowboot, .registration = TRUE
#' @importFrom graphics abline arrows axTicks axis boxplot legend lines plot points
#' @importFrom Rcpp sourceCpp
#' @importFrom Rdpack reprompt
#' @importFrom stats na.omit quantile
NULL
