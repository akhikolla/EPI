library(testthat)
library(kde1d)

test_check("kde1d")
