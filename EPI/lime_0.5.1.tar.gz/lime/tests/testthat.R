library(testthat)
library(lime)

test_check("lime")
