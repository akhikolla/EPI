library(testthat)
library(Rdca)

test_check("Rdca")
