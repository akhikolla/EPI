#' @useDynLib mfGARCH
#' @importFrom Rcpp sourceCpp
NULL
