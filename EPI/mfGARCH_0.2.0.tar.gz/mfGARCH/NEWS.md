v0.2.0
- Better error management for OPG standard errors

v0.1.9
- Compatibility with R 4.0.0

v0.1.8
- More precise error messages
- More robust estimation methods
- OPG standard errors are calculated as well
- Additional simulation option for RVol(22) and RV(22) as dependent variables 

v0.1.7
- Improved documentation for simulation functions
- Bugfix for simulating when using student-t
- Added K = K.two = 1, i.e. two covariates each with one lag
- Added K > 0 and K.two = 1 for unrestricted beta-weighting scheme

v0.1.6
- Hessian matrix more accurate

v0.1.5
- Support for two covariates

v0.1.4
- Predict function bugfix
- Better error messages
- Bugfix for calculating the variance ratio

v0.1.3
- New generic plot function

v0.1.2
- First release on CRAN
