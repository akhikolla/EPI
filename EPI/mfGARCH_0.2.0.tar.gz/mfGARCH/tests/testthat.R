library(testthat)
library(mfGARCH)

test_check("mfGARCH")
