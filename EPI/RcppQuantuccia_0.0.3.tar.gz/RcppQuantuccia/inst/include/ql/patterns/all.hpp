#include <ql/patterns/curiouslyrecurring.hpp>
#include <ql/patterns/lazyobject.hpp>
#include <ql/patterns/observable.hpp>
#include <ql/patterns/singleton.hpp>

