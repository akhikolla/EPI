#include <ql/math/statistics/incrementalstatistics.hpp>

