#include <ql/math/integrals/gausslobattointegral.hpp>
#include <ql/math/integrals/gaussianorthogonalpolynomial.hpp>
#include <ql/math/integrals/gaussianquadratures.hpp>
#include <ql/math/integrals/integral.hpp>
#include <ql/math/integrals/segmentintegral.hpp>
#include <ql/math/integrals/simpsonintegral.hpp>
#include <ql/math/integrals/trapezoidintegral.hpp>

