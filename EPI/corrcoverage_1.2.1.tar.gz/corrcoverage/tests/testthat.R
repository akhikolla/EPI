library(testthat)
library(corrcoverage)

test_check("corrcoverage")
