# corrcoverage 1.2.0

* Replace class with inherits to pass r-devel Debian checks

# corrcoverage 1.1.0

* Minor bug fixes for solaris operating system and removal of simGWAS dependency

# corrcoverage 1.0.0

* Initial submission
