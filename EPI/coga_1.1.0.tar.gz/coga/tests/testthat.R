library(testthat)
library(coga)

test_check("coga")
