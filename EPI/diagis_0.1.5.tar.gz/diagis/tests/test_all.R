library("testthat")
test_check("diagis")
