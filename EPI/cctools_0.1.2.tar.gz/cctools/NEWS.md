# cctools 0.1.1

BUG FIXES

* Expanded factor dummies now contain the name of the factor level.


# cctools 0.1.0

First release.
