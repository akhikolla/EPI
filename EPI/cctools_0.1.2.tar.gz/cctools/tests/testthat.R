library(testthat)
library(cctools)

test_check("cctools")
