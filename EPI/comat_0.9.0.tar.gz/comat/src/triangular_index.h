#ifndef triangular_index_H
#define triangular_index_H
// [[Rcpp::plugins(cpp11)]]

int triangular_index(int r, int c);

#endif // triangular_index_H
