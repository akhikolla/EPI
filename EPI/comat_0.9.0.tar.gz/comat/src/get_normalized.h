#ifndef get_normalized_H
#define get_normalized_H
// [[Rcpp::plugins(cpp11)]]

Rcpp::NumericVector get_normalized(Rcpp::NumericVector &x, std::string normalization);

#endif // get_normalized_H
