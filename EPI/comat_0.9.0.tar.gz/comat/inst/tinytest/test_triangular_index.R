expect_equal(comat:::triangular_index(0, 0), 0)
expect_equal(comat:::triangular_index(1, 0), 1)
expect_equal(comat:::triangular_index(0, 1), 1)
