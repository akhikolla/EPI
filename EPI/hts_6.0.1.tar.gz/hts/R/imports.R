#' @importFrom graphics lines par plot strwidth text
#' @import grDevices
#' @importFrom utils combn
#' @import methods
#' @importFrom stats window as.ts fitted frequency is.ts na.omit residuals time ts tsp tsp<-
#' @import Matrix 
#' @import SparseM
#' @import forecast
#' @import matrixcalc
#' @import parallel
#' @useDynLib hts
NULL
