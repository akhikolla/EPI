## #
## # --- Test tbind.R ---
## #
 
## test.tbind <- function() {
##     # function(...,checkData=TRUE)
## }

