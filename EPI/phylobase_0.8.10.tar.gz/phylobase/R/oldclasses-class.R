## This file contains the old class definitions needed
## better interoperation with other packages


## ape classes
setOldClass("phylo")

setOldClass("multiPhylo")

## setOldClass("multi.tree") ## obsolete

## ade4 classes
setOldClass("phylog")
