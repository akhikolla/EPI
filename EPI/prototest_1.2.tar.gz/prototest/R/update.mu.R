update.mu <-
function(theta, y1, yP1, n){
  (y1 - theta*yP1)/n
}
