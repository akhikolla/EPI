library(testthat)
library(blockForest)

test_check("blockForest")