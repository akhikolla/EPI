// global veriables
#ifndef __global_h__
#define __global_h__

static int *min_lamba, *cse;
  

#endif
