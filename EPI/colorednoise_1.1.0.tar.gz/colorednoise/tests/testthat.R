library(testthat)
library(colorednoise)

test_check("colorednoise")
