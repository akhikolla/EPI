library(testthat)
library(libstableR)

test_check("libstableR")
