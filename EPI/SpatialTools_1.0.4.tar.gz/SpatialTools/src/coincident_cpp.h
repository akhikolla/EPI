#ifndef _SpatialTools_COINCIDENT_CPP_H
#define _SpatialTools_COINCIDENT_CPP_H

#include <Rcpp.h>

RcppExport SEXP coincident_cpp(SEXP coords1, SEXP coords2, SEXP eps);

#endif
