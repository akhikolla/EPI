library(testthat)
library(SplitReg)

test_check("SplitReg")
