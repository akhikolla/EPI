#' Coordinates of houses in Groningen
#'
#' A dataset of postal codes and the corresponding spatial locations in terms of a latitude and a longitude.
#'
#' @format A data frame with 25000 rows and 8 variables:
#' \describe{
#'   \item{street}{Name of street}
#'   \item{number}{Number of house}
#'   \item{letter}{Letter of house}
#'   \item{suffix}{Suffix to number of house}
#'   \item{postal_code}{Postal code of house}
#'   \item{city}{The name of the city}
#'   \item{lon}{Longitude (in degrees)}
#'   \item{lat}{Latitude (in degrees)}
#'   \item{amount}{Random value}
#' }
#' @source The BAG is the Dutch registry for Buildings and adresses (Basisregistratie adressen en gebouwen).
"Groningen"
