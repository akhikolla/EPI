globalVariables(c("lon", "lat", "value", "clustering", "output", "DD", "DR", "FF", "FH", "FX", "HH", "RH", "T10", "TD", "YYYYMMDD", "knmi_stations"))

