library(testthat)
library(spatialrisk)

test_check("spatialrisk")

