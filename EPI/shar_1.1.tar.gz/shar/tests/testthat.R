library(dplyr)
library(shar)
library(spatstat)
library(testthat)

test_check("shar")
