#ifndef Ktype
#define Ktype float
#endif
