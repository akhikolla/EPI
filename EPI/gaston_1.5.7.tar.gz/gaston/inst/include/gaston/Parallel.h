// gaston 1.5.4 : we suppress the PoorMansParallel...
#include <RcppParallel.h>

#define Parallel RcppParallel
