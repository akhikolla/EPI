#include <Rcpp.h>
#ifndef GASTONmin_max_h2
#define GASTONmin_max_h2
using namespace Rcpp;
void min_max_h2(NumericVector Sigma, double & min_h2, double & max_h2);
#endif
