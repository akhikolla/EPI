#include "../inst/include/gaston/gzstream.h"
#include "../inst/include/gaston/gzstream0.h"
