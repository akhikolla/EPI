#' The Package
#' 
#' @docType package
#' 
#' @import Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib calculus, .registration=TRUE
NULL  
