#[export]
Match <- function(x,key=NULL) {
  as_integer(x,result.sort=FALSE)
}