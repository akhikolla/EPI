library(testthat)
test_check("geoops")
