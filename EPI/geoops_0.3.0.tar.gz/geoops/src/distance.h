double distance(std::string start, std::string end, std::string units);
