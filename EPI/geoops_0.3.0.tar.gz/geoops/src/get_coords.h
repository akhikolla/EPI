std::string get_coords(std::string x);
