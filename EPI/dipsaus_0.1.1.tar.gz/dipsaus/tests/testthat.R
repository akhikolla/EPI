library(testthat)
library(dipsaus)

test_check("dipsaus")
