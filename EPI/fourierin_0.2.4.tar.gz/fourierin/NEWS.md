
# Version 0.2.4

- Fix bugs.

- Explicitly call std::abs for doubles in C++ code.

# Version 0.2.3

- Explicitly call std::abs for doubles in C++ code.


# Version 0.2.2

- Suggested package 'microbenchmark' has been replaced by 'rbenchmark'.

# Version 0.2.1

- Parameters are more intuitive
- Vignette hes been improved

# Version 0.1.2

Patch: microbenchmark is now used only conditionally.

# Version 0.1.1

This first version of the package includes univariate and bivariate
Fourier-type integrals.

