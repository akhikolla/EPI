#' @useDynLib fmf, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL