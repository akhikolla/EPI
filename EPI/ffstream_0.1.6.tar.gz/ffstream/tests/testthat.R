library(testthat)
library(ffstream)

test_check("ffstream")
