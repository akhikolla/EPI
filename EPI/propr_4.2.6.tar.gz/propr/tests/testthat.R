library(testthat)
library(propr)

test_check("propr")
