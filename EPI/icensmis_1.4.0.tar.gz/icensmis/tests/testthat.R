library(testthat)
library(icensmis)

test_check("icensmis")
