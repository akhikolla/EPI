## icensmis

This is an R package for Study Design and Data Analysis in the Presence of Error-Prone Diagnostic Tests and Self-Reported Outcomes. Please refer to our [Annals of Applied Statistics paper](https://arxiv.org/abs/1509.04080), [Statistics in Medicine paper](https://onlinelibrary.wiley.com/doi/full/10.1002/sim.6962), and [BMC Medical Informatics and Decision Making paper](https://link.springer.com/article/10.1186/s12911-020-01223-w) for more details of proposed methods.
