library(testthat)
library(bigsparser)

test_check("bigsparser")
