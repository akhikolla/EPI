library(testthat)
library(readobj)

test_check("readobj")
