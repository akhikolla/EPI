library(testthat)
library(pdSpecEst)

test_check("pdSpecEst")
