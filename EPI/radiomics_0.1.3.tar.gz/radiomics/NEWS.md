# radiomics 0.1.3

* Fixes for `R CMD check --as-cran`
* Fixed the vignette for this version to pass.


# radiomics 0.1.2

* Numerous bugfixes/edge cases
* Better handling of NAs in matrices
* Minor optimizations

# radiomics 0.1.1

* Added generator functions for classes
* Added option to glrlm, glszm and mglszm truncate output matrix
* Changed algorithm used to calculate glcm, resulting in speed increases for larger images

# radiomics 0.1.0

* First release!