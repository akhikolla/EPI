## Release summary

First release!

## Test environments

* local Ubuntu 14.04 LTS install, R 3.2.2
* win-builder 

## R CMD check results

There were no NOTES, ERRORs or WARNINGs.

## Downstream dependencies

None to report