library(testthat)
library(radiomics)

test_check("radiomics")
