library(testthat)
library(earthtide)

test_check("earthtide")
