# earthtide 0.0.9

* remove get_iers test as it can cause failure if no internet accesss, or the server is down.

# earthtide 0.0.8

* Added horizontal displacement calculation
* Added horizontal strain calculation
* Add scaling option for analyze function

# earthtide 0.0.7*

* Added a `NEWS.md` file to track changes to the package.
* Matrix output method