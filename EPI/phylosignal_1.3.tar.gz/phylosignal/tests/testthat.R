library(testthat)
library(phylosignal)

test_check("phylosignal")
