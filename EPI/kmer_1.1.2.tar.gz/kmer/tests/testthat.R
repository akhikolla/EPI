library(testthat)
library(kmer)
test_check("kmer")
