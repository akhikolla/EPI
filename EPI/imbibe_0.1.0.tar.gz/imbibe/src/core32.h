#ifndef CR_CORE32_H
#define CR_CORE32_H

#ifdef  __cplusplus
extern "C" {
#endif

	int main32(int argc, char * argv[]);

#ifdef  __cplusplus
}
#endif

#endif //CR_CORE32_H




