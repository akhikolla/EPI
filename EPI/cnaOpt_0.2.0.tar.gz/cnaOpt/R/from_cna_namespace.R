
ctInfo <- getFromNamespace("ctInfo", "cna")

rreduce <- getFromNamespace("rreduce", "cna")

C_recCharList2char <- getFromNamespace("C_recCharList2char", "cna")
C_relist_Int  <- getFromNamespace("C_relist_Int", "cna")
relist1 <- getFromNamespace("relist1", "cna")
getCond <- getFromNamespace("getCond", "cna")
C_mconcat <- getFromNamespace("C_mconcat", "cna")
hstrsplit <- getFromNamespace("hstrsplit", "cna")
noblanks <- getFromNamespace("noblanks", "cna")
qcond_bool <- getFromNamespace("qcond_bool", "cna")
C_redund <- getFromNamespace("C_redund", "cna")

