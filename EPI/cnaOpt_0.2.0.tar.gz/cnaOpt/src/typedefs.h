
#include <Rcpp.h>
using namespace Rcpp;

typedef ListOf<NumericVector> dblList; 
typedef std::vector<NumericVector::iterator> dblIteratorList;
