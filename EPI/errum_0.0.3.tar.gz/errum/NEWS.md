# errum 0.0.3

## Bug fix

- Fix ambiguous overloaded of `pow` on Solaris.

# errum 0.0.2

## Features

- Provides a high-performing modeling routine for the Exploratory
  Reduced Reparameterized Unified Model (errum).
