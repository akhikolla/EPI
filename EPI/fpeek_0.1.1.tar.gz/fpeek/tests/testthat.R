library(testthat)
library(fpeek)

test_check("fpeek")
