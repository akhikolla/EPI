# fpeek 0.1.1

* update peek_iconv test to skip it when platform charset is not UTF-8
