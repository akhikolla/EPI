.onUnload <- function (libpath) {
  library.dynam.unload("smam", libpath)
}
