#' @importFrom Rcpp evalCpp
#' @importFrom stats predict
#' @useDynLib doc2vec
NULL

