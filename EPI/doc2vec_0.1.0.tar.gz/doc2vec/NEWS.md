## CHANGES IN doc2vec VERSION 0.1.0

- Initial package based on https://github.com/hiyijian/doc2vec commit dec123e891f17ea664053ee7575b0e5e7dae4fca
