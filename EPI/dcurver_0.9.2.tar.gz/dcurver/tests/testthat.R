library(testthat)
library(dcurver)

test_check("dcurver")
