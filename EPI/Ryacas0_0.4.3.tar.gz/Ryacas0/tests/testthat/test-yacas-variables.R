context("yacas variables")

test_that("Variables", {
  expect_equal(TRUE, TRUE)
})
