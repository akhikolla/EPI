/** \file lisptype.h
  * Declarations of types that could become platform-dependent
  */


#ifndef YACAS_LISPTYPE_H
#define YACAS_LISPTYPE_H

#include <stdlib.h>


#endif
