print.fwsim_fixed_sim_genealogy <-
function(x, ...) {
  if (!is(x, "fwsim_fixed_sim_genealogy")) stop("x must be a fwsim_fixed_sim_genealogy object")
  print_simulation_info(x)
    
  return(invisible(NULL))
}

plot.fwsim_fixed_sim_genealogy <-
function(x, which = 1L, ...) {
  if (!is(x, "fwsim_fixed_sim_genealogy")) stop("x must be a fwsim_fixed_sim_genealogy object")
  
  
      
  return(invisible(NULL))
}


