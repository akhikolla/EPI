library(testthat)
library(kdevine)

test_check("kdevine")
