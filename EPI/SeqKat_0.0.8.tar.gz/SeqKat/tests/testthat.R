library(testthat);
test_check("SeqKat");
