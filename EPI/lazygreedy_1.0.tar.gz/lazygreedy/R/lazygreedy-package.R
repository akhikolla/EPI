## usethis namespace: start
#' @useDynLib lazygreedy, .registration = TRUE
## usethis namespace: end
NULL

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL

## usethis namespace: start
#' @importFrom utils packageDescription
## usethis namespace: end
NULL
