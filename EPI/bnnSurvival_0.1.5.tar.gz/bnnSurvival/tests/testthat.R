library(testthat)
library(bnnSurvival)

test_check("bnnSurvival")