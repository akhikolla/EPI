## usethis namespace: start
#' @useDynLib geoFKF, .registration = TRUE
## usethis namespace: end
NULL

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL

## usethis namespace: start
#' @importFrom stats dist nlminb rnorm
## usethis namespace: end
NULL
