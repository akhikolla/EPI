library(testthat)
library(cusum)

test_check("cusum")
