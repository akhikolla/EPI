library(testthat)
test_check("segmag")
