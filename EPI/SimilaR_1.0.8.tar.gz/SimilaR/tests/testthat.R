library("testthat")
library("SimilaR")
test_check("SimilaR")
