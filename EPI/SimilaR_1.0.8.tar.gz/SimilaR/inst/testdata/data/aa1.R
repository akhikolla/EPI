asd <- function(x)
{
    for(i in x)
    {
        cat(i)
        x[i] <- 3
    }
}
