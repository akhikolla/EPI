int fifmod(int, int);
int fifmax0(int, int);
int fifmin0(int, int);
int fifipow(int, int);
