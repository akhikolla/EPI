library(testthat)
library(gastempt)

test_check("gastempt")

