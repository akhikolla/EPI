library(testthat)
library(SimSurvNMarker)

test_check("SimSurvNMarker")
