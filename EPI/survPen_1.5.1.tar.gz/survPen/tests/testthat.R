library(testthat)
library(survPen)

test_check("survPen")
