# mixdir 0.3.0

* Improve error message if underflow in zeta calculation (#1).
  Thanks to @jmelero611.


# mixdir 0.2.0

* Adding reference to accompanying publication
* "Dontrun" examples for plot_defining_features and plot_features
* Added a `NEWS.md` file to track changes to the package.


# mixdir 0.1.0

* Initial Release
