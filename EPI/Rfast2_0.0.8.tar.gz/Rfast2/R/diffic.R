#[export]
diffic <- function(x) {
  Rfast::colmeans(x)
}