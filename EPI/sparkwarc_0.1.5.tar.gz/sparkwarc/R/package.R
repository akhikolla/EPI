#' sparkwarc
#'
#' Sparklyr extension for loading WARC Files into Apache Spark
#'
#' @docType package
#' @import Rcpp
#' @name sparkwarc
NULL
