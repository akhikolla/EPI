an <- as.numeric
ac <- as.character
anc <- function(x) as.numeric(as.character(x))
