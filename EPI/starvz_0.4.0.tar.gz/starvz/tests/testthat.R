library(testthat)
library(starvz)

test_check("starvz")
