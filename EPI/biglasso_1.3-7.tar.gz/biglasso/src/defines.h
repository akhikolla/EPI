#ifndef DEFINES_H
#define DEFINES_H

#include <stdint.h>

// define int to be unsigned 32bit int
#define int uint32_t
#define long_int uint64_t

#endif
