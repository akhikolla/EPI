library(testthat)
library(gtfs2gps)

test_check("gtfs2gps")
