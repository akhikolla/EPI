library(testthat)
library(heatwaveR)

test_check("heatwaveR")
