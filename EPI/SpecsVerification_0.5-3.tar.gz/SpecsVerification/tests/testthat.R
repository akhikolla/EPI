library(testthat)
library(SpecsVerification)

test_check('SpecsVerification')

