library(testthat)
library(malan)

test_check("malan")
