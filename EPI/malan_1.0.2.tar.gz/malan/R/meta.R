.onUnload <- function(libpath) {
  library.dynam.unload("malan", libpath)
}
