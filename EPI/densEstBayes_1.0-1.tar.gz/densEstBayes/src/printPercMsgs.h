#ifndef PRINTPERCMSGS_H
   #define PRINTPERCMSGS_H
   int printPercMsgs(int msgCode,int loopSize,int iLoop,int percCnt);
#endif


