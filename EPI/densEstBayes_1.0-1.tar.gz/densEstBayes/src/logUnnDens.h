#ifndef LOGUNNDENS_H
   #define LOGUNNDENS_H
   double logUnnDens(int j,arma::vec betauj,arma::vec betaunotj,
                     arma::mat Cmat,arma::vec CTy,arma::vec sigsqbetau);
#endif


