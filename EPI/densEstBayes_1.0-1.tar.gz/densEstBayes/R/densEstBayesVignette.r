########## R function: densEstBayesVignette ##########

# For opening up the vignette PDF file for
# the densEstBayes package.

# Last changed: 31 JUL 2020

densEstBayesVignette <- function()
{
   vignette("manual",package="densEstBayes")
}

########## End of densEstBayesVignette ############
