

count_nonconvex <- function(k, options, A.list, b.list,
                            prior = rep(1, length(k))){
  # C++: sampling and counting!
  #  (stepwise not possible!)
  # here: checks of input
}
