
# input: stimulus structure? optional: frequencies?
# output: A-b constraints ; data structure (vector!)
conjoint <- function(){

}
