#include "LinkBase.h"

LinkBase::~LinkBase() 
{
}

LinkBase::LinkBase()
{
}
