#include "FamilyBase.h"

FamilyBase::~FamilyBase()
{
}

FamilyBase::FamilyBase()
{
}


