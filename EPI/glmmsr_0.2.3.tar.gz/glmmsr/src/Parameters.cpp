#include "Parameters.h"

Parameters::Parameters(): GLMMTheta(), GLMMBeta(),
			  GLMMFamily(),
			  sparseBasis(),
			  quadratureRule()
{
}
