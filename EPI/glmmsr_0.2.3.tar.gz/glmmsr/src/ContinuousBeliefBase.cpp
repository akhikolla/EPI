#include "ContinuousBeliefBase.h"

ContinuousBeliefBase::~ContinuousBeliefBase()
{
}

ContinuousBeliefBase::ContinuousBeliefBase()
{
}

ContinuousBeliefBase::ContinuousBeliefBase(const std::vector<int>& items):
  BeliefBase(items)
{
}
