library(testthat)
library(glmmsr)

test_check("glmmsr")
