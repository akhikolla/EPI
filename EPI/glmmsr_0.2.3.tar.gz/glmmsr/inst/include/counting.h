#ifndef GUARD_COUNTING_H
#define GUARD_COUNTING_H

#include<vector>

int choose(int, int);

int findNumGridPoints(int, int);

#endif // GUARD_COUNTING_H
