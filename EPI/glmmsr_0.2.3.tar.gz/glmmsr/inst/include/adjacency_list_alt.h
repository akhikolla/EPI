#ifndef GUARD_ADJACENCY_LIST_ALT_H
#define GUARD_ADJACENCY_LIST_ALT_H

#define BOOST_NO_CXX11_DEFAULTED_FUNCTIONS
#include <boost/graph/adjacency_list.hpp>

#endif //GUARD_ADJACENCY_LIST_ALT_H
