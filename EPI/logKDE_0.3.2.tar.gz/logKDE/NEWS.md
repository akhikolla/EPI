logKDE 0.3.2
=============

Improved documentation.
Updated references.
Unit testing added.

logKDE 0.3.1
=============

Detailed readme added and some bug fixes.


logKDE 0.3.0
=============

Minor updates and improved documentation.


logKDE 0.1.0
=============

First release.
