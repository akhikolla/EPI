library(testthat)
library(logKDE)

test_check("logKDE")
