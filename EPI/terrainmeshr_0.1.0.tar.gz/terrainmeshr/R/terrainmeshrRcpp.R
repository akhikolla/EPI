#' @useDynLib terrainmeshr, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
