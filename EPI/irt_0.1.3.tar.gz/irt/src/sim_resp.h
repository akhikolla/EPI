#ifndef SIMRESP_H
#define SIMRESP_H

#include <Rcpp.h>
// sim_resp
int sim_resp_bare_cpp(double theta, Rcpp::S4 item);
#endif
