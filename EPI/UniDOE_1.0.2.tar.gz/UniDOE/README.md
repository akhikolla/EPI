# Package: UniDOE
### Author: Aijun Zhang and Haoyu Li, Shijie Quan

### Introduction:
This is UniDOE package with c source code. Please see details in * [UniDOE](https://github.com/HAOYU-LI/UniDOE)

### Useful links:
* [Experimental design](https://en.wikipedia.org/wiki/Design_of_experiments) - Intro to design of experiments
* [License](https://github.com/HAOYU-LI/UniDOE/blob/master/LICENSE) - License for this project
* [Maintainer](http://www.statsoft.org/)


