#' @docType data
#'
#' @usage data(UD_CD2)
#'
#' @format NA.
#'
#' @keywords NA.
#'
#' @references
#' (\href{https://CRAN.R-project.org/package=UniDOE}{unidoe})
#'
#' @source \href{https://CRAN.R-project.org/package=UniDOE}}{unidoe}
#'
#' @examples
#' data(UD_CD2)
"UD_CD2"
