#' @docType data
#'
#' @usage data(LHD_MD2)
#'
#' @format NA.
#'
#' @keywords NA.
#'
#' @references
#' (\href{https://CRAN.R-project.org/package=UniDOE}{unidoe})
#'
#' @source \href{https://CRAN.R-project.org/package=UniDOE}}{unidoe}
#'
#' @examples
#' data(LHD_MD2)
"LHD_MD2"
