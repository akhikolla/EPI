#' @docType data
#'
#' @usage data(LHD_CD2)
#'
#' @format NA.
#'
#' @keywords NA.
#'
#' @references
#' (\href{https://CRAN.R-project.org/package=UniDOE}{unidoe})
#'
#' @source \href{https://CRAN.R-project.org/package=UniDOE}}{unidoe}
#'
#' @examples
#' data(LHD_CD2)
"LHD_CD2"
