void srandom(long seed);
void srandomt();//set seed according to current time
double Random();
