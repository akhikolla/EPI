void indexx1(unsigned int n, double arr[], unsigned int indx[]); //double
void indexx2(unsigned int n,int arr[], unsigned int indx[]); //int
