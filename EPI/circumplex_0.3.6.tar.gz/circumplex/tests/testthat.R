library(testthat)
library(circumplex)

test_check("circumplex")
