library("testthat")
library("smurf")

test_check("smurf")
