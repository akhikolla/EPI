library(testthat)
library(SpatialKDE)

test_check("SpatialKDE")
