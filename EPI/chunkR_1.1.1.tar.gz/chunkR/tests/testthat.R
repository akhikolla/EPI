library(testthat)
library(chunkR)

test_check("chunkR")
