library(testthat)
library(exactextractr)

test_check("exactextractr")
