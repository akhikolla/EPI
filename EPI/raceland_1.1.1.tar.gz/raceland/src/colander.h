#ifndef colander_H
#define colander_H
#include "Rcpp.h"

// [[Rcpp::export]]
Rcpp::NumericVector colander(Rcpp::NumericMatrix x, Rcpp::IntegerVector y);

#endif // colander_H
