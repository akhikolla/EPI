
expect_error(plot_realization(real_raster, race_raster, hex = hex_colors))
