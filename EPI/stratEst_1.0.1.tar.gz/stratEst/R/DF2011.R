#' Data of Dal Bo and Frechette (2011)
#'
#' A dataset with observations from the repeated prisoner's dilemma experiment of Dal Bo and Frechette (2011).
#'
#' @format A data frame with 7358 rows and 6 variables:
#' \describe{
#'   \item{treatment}{A factor with six levels which identifies the treatments of the experiment.}
#'   \item{id}{A vector of integers which identifies the participant.}
#'   \item{game}{A vector of integers which identifies the supergame.}
#'   \item{period}{A vector of integers which identifies the period of the supergame.}
#'   \item{choice}{A factor with two levels which is indicates if the participant cooperates (c) or defects (d) in the current period.}
#'   \item{other.choice}{A factor with two levels which indicates if the other participant cooperates (c) or defects (d) in the current period.}
#' }
#' @usage data(DF2011)
#' @source \url{https://www.aeaweb.org/articles?id=10.1257/aer.101.1.411}
#' @references
#' Dal Bo P, Frechette GR (2011). "The Evolution of Cooperation in Infinitely Repeated Games: Experimental Evidence." \emph{American Economic Review}, 101(1), 411-429.
#'
"DF2011"
