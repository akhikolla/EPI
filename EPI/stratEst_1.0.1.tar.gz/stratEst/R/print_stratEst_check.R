#' Print Method for stratEst.check
#' @param x An object of class \code{stratEst.check}.
#' @param ... Further arguments passed to or from other methods.
#' @export
print.stratEst.check <- function( x , ... ){

  c("stratEst.check", NextMethod())

}
