#' Print Method for stratEst.model
#' @param x An object of class \code{stratEst.model}.
#' @param ... Further arguments passed to or from other methods.
#' @export
print.stratEst.model <- function( x , ... ){

  c("stratEst.model", NextMethod())

}
