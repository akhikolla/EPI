library(testthat)
library(stratEst)

test_check("stratEst")
