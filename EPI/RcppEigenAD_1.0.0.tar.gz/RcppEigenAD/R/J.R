
J<-function(f) Curry(f,order=1)

