

setGeneric("%.%",function(f,g) standardGeneric("%.%"))

