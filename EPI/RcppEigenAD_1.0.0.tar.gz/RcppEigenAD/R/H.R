
H<-function(f) Curry(f,order=2)