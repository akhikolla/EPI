

#ifndef ___generics_h___
#define ___generics_h___

#include "./generic/typelist/include/TypeList.h"
#include "./generic/singleton/include/GenericSingleton.h"

#endif
