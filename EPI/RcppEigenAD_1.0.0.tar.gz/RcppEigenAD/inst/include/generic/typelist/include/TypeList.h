

#ifndef __TYPELIST_H__
#define __TYPELIST_H__

#ifdef IBM
#include "TypeList-IBM.h"
#else
#include "TypeList-Normal.h"
#endif


#endif


