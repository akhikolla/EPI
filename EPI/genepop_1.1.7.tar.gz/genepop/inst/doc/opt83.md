### Sub-option 3: Relabeling alleles names
\index{Relabeling alleles}
This sub-option relabels all alleles starting from 1 up to $x$, $x$ being the true number of distinct alleles for each locus. The new file is named `N`*yourdata*. The correspondence between the old and the new numbering is indicated in the file *new\_file\_name*.NUM. This option was originally introduced in Genepop because for some options, the memory space required depends on the highest allele number. I don’t expect this to be a cause of concern now.
