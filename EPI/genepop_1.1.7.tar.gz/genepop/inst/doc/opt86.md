### Sub-option 6: Random sampling of haploid genotypes from diploid ones

This sub-option randomly samples haploid genotypes at diploid loci.[^26] This may be useful for external analyses that require haploid data or that would be biased by Hardy-Weinberg disequilibria.
