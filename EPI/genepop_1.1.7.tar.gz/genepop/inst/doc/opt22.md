### Sub-option 2: create tables
Suboption 2 only generates the above contingency tables and stores them in the file *yourdata*`.TAB`
