Sub-option 1 converts the Genepop input file into the format required by the Fstat\index{Fstat program} program of @Goudet95. The new format is saved in the file *yourdata*`.DAT`.
