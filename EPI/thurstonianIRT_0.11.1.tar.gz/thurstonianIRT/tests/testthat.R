library(testthat)
library(thurstonianIRT)

test_check("thurstonianIRT")
