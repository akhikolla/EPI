### R code from vignette source 'rtkpp-Introduction.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: prelim
###################################################
library(rtkore)
rtkore.version <- packageDescription("rtkore")$Version
rtkore.date <- packageDescription("rtkore")$Date


###################################################
### code chunk number 2: rtkpp-Introduction.Rnw:54-55
###################################################
.Call("stk_version", FALSE, PACKAGE="rtkore")


