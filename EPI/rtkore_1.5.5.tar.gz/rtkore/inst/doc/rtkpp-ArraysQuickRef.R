### R code from vignette source 'rtkpp-ArraysQuickRef.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: prelim
###################################################
library(rtkore)
rtkore.version <- packageDescription("rtkore")$Version
rtkore.date <- packageDescription("rtkore")$Date


