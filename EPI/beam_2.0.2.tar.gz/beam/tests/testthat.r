library(testthat)
library(beam)

test_check("beam")
