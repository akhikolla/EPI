library(testthat)
library(spsurv)

test_check("spsurv")
