## Use to handle the CRAN check NOTE
utils::globalVariables(
  c("AMP", "DEL", "mean_rep")
)
