#ifndef pascal_H
#define pascal_H

double lbinom(int n, int s);

#endif
