Sys.setenv("R_TESTS" = "")
library(testthat)
library(dexter)
test_check("dexter")
