library(testthat)
library(diceR)

test_check("diceR")
