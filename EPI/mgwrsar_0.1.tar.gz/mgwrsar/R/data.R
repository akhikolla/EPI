#' mydata is a simulated data set of a mgwrsar model
#'
#' @author Ghislain Geniaux and Davide Martinetti \email{ghislain.geniaux@@inra.fr}
#' @references \url{https://www.sciencedirect.com/science/article/pii/S0166046216302381}
"mydata"
