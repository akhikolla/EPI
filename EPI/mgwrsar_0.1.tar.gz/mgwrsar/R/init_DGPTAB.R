#' init_DGPTAB
#' to be documented
#' @usage init_DGPTAB()
#' @keywords internal
#' @return  to be documented
init_DGPTAB <-
function(){list(OLS=list(),GWR=list(),MGWR=list(),SAR=list(),MGWRSAR_0_0_kv=list(),MGWRSAR_0_kc_kv=list(),MGWRSAR_1_0_kv=list(),MGWRSAR_1_kc_kv=list(),MGWRSAR_1_kc_0=list())}
