#' set0_conditionXD
#' to be documented
#' @usage set0_conditionXD(XX, ZZ)
#' @param XX  to be documented
#' @param ZZ  to be documented
#' @keywords internal
#' @return to be documented
set0_conditionXD <-
function (XX, ZZ)
.Call("set0_conditionXD", XX, ZZ, PACKAGE = "mgwrsar")
