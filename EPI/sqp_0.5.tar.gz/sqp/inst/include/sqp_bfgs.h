#ifndef __sqp_bfgs_included__        // if include guard for 'sqp_bfgs.h' is undefined
#define __sqp_bfgs_included__        // define include guard for 'sqp_bfgs.h'

#include "sqp.h"




#include "bfgs/sqp_bfgs.h"




#endif                              // end of include guard for 'sqp_bfgs.h'
