#ifndef __sqp_solvers_quadratic_optimizer_class_included__        // if include guard for 'solvers/quadratic_optimizer_class.h' is undefined
#define __sqp_solvers_quadratic_optimizer_class_included__        // define include guard for 'solvers/quadratic_optimizer_class.h'  

#include "sqp.h"

namespace sqp {
namespace solvers{



inline 



};
};

#endif                                                           // end of include guard for 'solvers/quadratic_optimizer_class.h'  
