// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(cpp)]]
#include <sqp.h>

// [[Rcpp::export]]  
void dummy()
{
}

