
// Rcpp Attributes create RcppExports.cpp -- and one of the implemented conventions is
// to, as an option, #include a header file named as package follow by _types.h if present

#ifndef TILEDB_DEPRECATED
  #define TILEDB_DEPRECATED
#endif
