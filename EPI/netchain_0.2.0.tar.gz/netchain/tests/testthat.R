library(testthat)
library(netchain)

test_check("netchain")
