library(testthat)
library(lowpassFilter)

test_check("lowpassFilter")
