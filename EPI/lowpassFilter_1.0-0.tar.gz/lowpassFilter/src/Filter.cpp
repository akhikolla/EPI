#include "Filter.h"

/***************
* class Filter
* abstract class maintaining the filter
* Florian Pein, 2016
***************/
Filter::~Filter() {}
