#' @useDynLib dsmisc
#' @import Rcpp
NULL