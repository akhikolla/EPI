library(testthat)
library(dsmisc)

test_check("dsmisc")
