# dsmisc 0.3.3

* remove of `#include <bits/stdc++.h>` from grpahs_find_subgraphs.cpp because its a) bad style, b) not cross platform compatible and c) wasteful d) actually a dirty hack - thanks to comment from Prof Brian Ripley - also: https://stackoverflow.com/a/46814932/1144966.




# dsmisc 0.3.2

* Initial CRAN release
* Added a `NEWS.md` file to track changes to the package.
