// Copyright (C) 2005  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_MEMBER_FUNCTION_POINTEr_
#define DLIB_MEMBER_FUNCTION_POINTEr_

#include "member_function_pointer/member_function_pointer_kernel_1.h"
#include "member_function_pointer/make_mfp.h"

#endif // DLIB_MEMBER_FUNCTION_POINTEr_ 

