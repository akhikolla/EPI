library(testthat)
library(decido)

test_check("decido")
