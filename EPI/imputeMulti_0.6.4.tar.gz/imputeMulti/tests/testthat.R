library(testthat)
library(imputeMulti)
library(parallel)

# test_check("imputeMulti")
