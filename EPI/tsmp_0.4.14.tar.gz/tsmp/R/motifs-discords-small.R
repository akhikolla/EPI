#' Just a synthetic dataset for testing
#'
#' @docType data
#' @format A `vector` with 875 observations
#' @keywords datasets
"motifs_discords_small"
