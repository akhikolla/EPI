## File Name: starts_vector_with_names.R
## File Version: 0.02

starts_vector_with_names <- function( vec, vec_names )
{
    names(vec) <- vec_names
    return(vec)
}

