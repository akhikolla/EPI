## File Name: digamma2.R
## File Version: 0.06

digamma2 <- function(x, n0, var0)
{
    sirt::dinvgamma2(x=x, n0=n0, var0=var0)
}
