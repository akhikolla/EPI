## File Name: vcov.starts_uni.R
## File Version: 0.02

vcov.starts_uni <- function( object, ...)
{
    return(object$vcov)
}
