## File Name: coef.starts_uni.R
## File Version: 0.02

coef.starts_uni <- function( object, ...)
{
    return(object$coef)
}
