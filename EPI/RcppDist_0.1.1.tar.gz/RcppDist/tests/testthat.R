library(testthat)
library(RcppDist)

test_check("RcppDist")
