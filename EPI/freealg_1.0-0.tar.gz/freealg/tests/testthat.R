library("testthat")
test_check("freealg")
