library(testthat)
library(ipaddress)

test_check("ipaddress")
