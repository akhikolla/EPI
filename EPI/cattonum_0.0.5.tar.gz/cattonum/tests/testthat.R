library(testthat)
library(cattonum)

test_check("cattonum")
