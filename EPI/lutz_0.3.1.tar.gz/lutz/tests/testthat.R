library(testthat)
library(lutz)

test_check("lutz")
