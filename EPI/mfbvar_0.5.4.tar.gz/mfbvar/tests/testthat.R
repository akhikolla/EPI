library(testthat)
library(mfbvar)

test_check("mfbvar")
