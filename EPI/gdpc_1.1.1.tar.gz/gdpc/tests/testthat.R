library(testthat)
library(gdpc)

test_check("gdpc")
