library(testthat)
library(RcppHungarian)

test_check("RcppHungarian")
