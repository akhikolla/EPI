# RcppHungarian 0.1

* Getting ready to push to CRAN
* Added a `NEWS.md` file to track changes to the package.
