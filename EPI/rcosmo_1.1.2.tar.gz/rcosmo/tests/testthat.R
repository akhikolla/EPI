# library(testthat)
# library(rcosmo)
#
# test_check("rcosmo")
