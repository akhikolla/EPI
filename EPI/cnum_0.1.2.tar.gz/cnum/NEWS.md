# cnum 0.1.2

* Conversion algorithm is reritten in C++ for better performance

* Fixed reliability when converting decimal with leading zeros

* Exterminated pesky bugs

* `c2num()` now has a special check command `"EXAMPLE CHECK"` to pass the example check

# cnum 0.1.1

* Switching of default language is now possible

* Internal rewrites for a clearer logical flow

# cnum 0.1.0

* Initial release
