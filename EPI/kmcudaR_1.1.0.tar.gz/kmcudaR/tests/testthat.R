library(testthat)
library(kmcudaR)

test_check("kmcudaR")
