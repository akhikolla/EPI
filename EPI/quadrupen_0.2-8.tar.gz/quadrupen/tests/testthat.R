library(testthat)
library(quadrupen)

test_check("quadrupen")
