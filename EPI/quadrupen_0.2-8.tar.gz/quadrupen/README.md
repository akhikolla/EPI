# quadrupenCRAN

<!-- badges: start -->
[![R build status](https://github.com/jchiquet/quadrupenCRAN/workflows/R-CMD-check/badge.svg)](https://github.com/jchiquet/quadrupenCRAN/actions)
<!-- badges: end -->


CRAN version of the quadrupen R package

[https://CRAN.R-project.org/package=quadrupen](https://CRAN.R-project.org/package=quadrupen)
