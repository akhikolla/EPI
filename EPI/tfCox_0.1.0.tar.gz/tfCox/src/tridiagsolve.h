#pragma once

void tridiagsolve(int n, const double *a, 
    double *b, double *c, double *x, double *cprime);

