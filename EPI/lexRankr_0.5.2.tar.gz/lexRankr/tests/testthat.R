library(testthat)
library(lexRankr)

test_check("lexRankr")
