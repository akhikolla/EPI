QR.ip=function(X,y,tau)
{

a=rq(y~X,tau)
return(a)
}
