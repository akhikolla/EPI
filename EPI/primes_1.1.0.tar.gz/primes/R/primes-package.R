#' @useDynLib primes
#' @importFrom Rcpp sourceCpp
NULL
