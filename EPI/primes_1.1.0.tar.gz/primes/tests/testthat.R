library(testthat)
library(primes)

test_check("primes")
