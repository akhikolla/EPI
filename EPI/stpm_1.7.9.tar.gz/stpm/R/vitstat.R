#' Vital (mortality) statistics.
#' @name vitstat
#' @docType data
#' @author Ilya Y Zhbannikov \email{ilya.zhbannikov@duke.edu}
#' @keywords data
NULL

