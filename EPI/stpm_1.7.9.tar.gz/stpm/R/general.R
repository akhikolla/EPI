#' @import Rcpp
#' @import sas7bdat
#' @import stats
#' @import nloptr
#' @import survival
#' @import tools
#' @importFrom utils head read.csv tail
#' @importFrom MASS ginv
#' @useDynLib stpm, .registration = TRUE
NULL
