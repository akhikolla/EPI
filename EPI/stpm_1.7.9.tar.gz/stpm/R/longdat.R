#' This is the longitudinal dataset.
#' @name longdat
#' @docType data
#' @author Ilya Y Zhbannikov \email{ilya.zhbannikov@duke.edu}
#' @keywords data
NULL

#' This is the longitudinal genetic dataset.
#' @name ex_data
#' @docType data
#' @author Liang He
#' @keywords data
NULL
