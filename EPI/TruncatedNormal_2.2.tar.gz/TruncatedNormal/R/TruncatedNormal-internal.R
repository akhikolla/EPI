#' @importFrom stats "sd" "pnorm" "qnorm" "rnorm" "runif" "dnorm" "rexp"
#' @importFrom alabama "auglag"
NULL
