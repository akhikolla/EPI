library(testthat)
library(TruncatedNormal)

test_check("TruncatedNormal")
