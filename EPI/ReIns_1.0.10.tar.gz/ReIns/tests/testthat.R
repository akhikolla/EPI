library("testthat")
library("ReIns")

# Test ReIns package
test_check("ReIns")
