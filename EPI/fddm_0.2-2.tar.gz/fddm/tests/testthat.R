library(testthat)
library(fddm)

test_check("fddm")
