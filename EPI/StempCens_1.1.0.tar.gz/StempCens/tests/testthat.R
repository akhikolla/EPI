library(testthat)
library(StempCens)

test_check("StempCens")
