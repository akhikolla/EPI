
### News for Package StempCens

<font color='grey'>**Changes in StempCens version 1.1.0**</font>

* New function `EffectiveRange`, it computes the effective range for an isotropic spatial correlation function.

* The `EstStempCens` function allows to consider interval censoring by specifying the limit of detection (LOD).

<font color='grey'>**Changes in StempCens version 0.1.0**</font>

* Initial release.
