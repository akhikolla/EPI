## usethis namespace: start
#' @useDynLib StempCens, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL

