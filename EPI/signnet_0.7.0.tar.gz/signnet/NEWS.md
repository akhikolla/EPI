# signnet 0.7.0

* added `triad_census_signed()`

# signnet 0.6.0

* added `avatar` dataset
* speed up of blockmodeling for larger networks

# signnet 0.5.3

* fixed issue in `complex_walks()`
* fixed faulty calculation of directed `pn_index()`

# signnet 0.5.2

* fixed `stringsAsFactors` issue in `complex_matrices.R`

# signnet 0.5.1

* fixed C++ issue for circular arc graphs
* fixed failing eigen centrality test

# signnet 0.5.0

* added vignettes and tests

# signnet 0.1.0

* initial version


