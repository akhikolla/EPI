#' Signed networks from Avatar: The Last Airbender
#' @description Allies/Enemy relations from Avatar: The Last Airbender

#' @format igraph object
#' @source scraped from Avatar Wiki (https://avatar.fandom.com/wiki/Category:Characters)
"avatar"
