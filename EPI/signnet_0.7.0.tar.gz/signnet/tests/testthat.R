library(testthat)
library(signnet)

test_check("signnet")
