#pragma once

#include <stdio.h>
#include <sys/stat.h>
#include <string>
long fileSize(std::string fn);
