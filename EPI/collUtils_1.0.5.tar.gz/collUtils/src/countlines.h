#pragma once



#include <iostream>
#include <fstream>
#include <algorithm>


using namespace std;

long countlines(std::string fn);




