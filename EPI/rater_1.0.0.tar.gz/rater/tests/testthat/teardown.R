
rm(I, J, K, "ds_fit", "hds_fit", "ccds_fit")
