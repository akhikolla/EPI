library(testthat)
library(rater)

test_check("rater")
