library(testthat)
library(hdme)

test_check("hdme")
