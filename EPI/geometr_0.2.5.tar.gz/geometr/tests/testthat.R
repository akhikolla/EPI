library(testthat)
library(checkmate)
library(raster)
library(sp)
library(sf)

test_check("geometr")

