#' @useDynLib geometr
globalVariables(c("x", "y", "gtTheme", "fid", "gid", "vid", "targetGrob",
                  "include", "L1", "L2", "L3", "is_dup", "is_odd"))