## bigMap 2.3.1. Jun, 2020.

New feature: S2NR-based merging of clusters.

Improved quantile-Map and density-Map plots.

The generic bdm.plot() has been replaced by particular plot functions bdm.ptsne.plot(), bdm.pakde.plot(9 and bdm.wtt.plot().

## bigMap 2.1.0. Feb, 2019.

Solved for staged install.

## bigMap 2.0.0. Jan, 2019.

First submission.
