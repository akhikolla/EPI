## this runs all tests on R CMD CHECK

library(testthat)
test_check("treeclim")
