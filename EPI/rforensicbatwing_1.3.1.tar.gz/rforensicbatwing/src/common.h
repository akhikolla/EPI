#ifndef COMMON_H_
#define COMMON_H_

#include <R.h>
#include <Rinternals.h>

#endif
