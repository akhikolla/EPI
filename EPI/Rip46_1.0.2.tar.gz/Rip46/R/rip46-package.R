#' R utils for IP4 and IP6 addresses
#' @name Rip46
#' @docType package
#' @docType package
#' @useDynLib Rip46
#' @import Rcpp
NULL