/* Usage Example:
 *
 *     #include "csr_matrix_times_vector2.hpp"
 *
 * And place file in `inst/include/` directory.
 * See https://github.com/stan-dev/rstanarm/tree/master/inst/include for more.
 */
