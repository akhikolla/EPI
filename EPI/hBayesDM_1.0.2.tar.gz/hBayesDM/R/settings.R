#' @noRd
if (Sys.getenv('BUILD_ALL') == "true") {
  FLAG_BUILD_ALL <- TRUE
} else {
  FLAG_BUILD_ALL <- FALSE
}
