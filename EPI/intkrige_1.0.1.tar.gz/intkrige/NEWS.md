# intkrige 1.0.1
* Added '[]' based extraction and replacement within intsp and intgrd objects. 
* Changed several class() checks to inheritance() checks to avoid errors in 
  conditionals with class objects of length > 1. 

# intkrige 1.0.0

* Added a `NEWS.md` file to track changes to the package.

