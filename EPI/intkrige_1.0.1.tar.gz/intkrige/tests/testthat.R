library(testthat)
library(intkrige)

test_check("intkrige")
