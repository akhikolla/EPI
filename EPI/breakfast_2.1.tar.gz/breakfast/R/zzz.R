.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Please take a look at the vignette for tips/suggestions/examples of using the breakfast package.")
  #  message("Please take a look at the vignette for tips/suggestions/examples of using the breakfast package.")
}