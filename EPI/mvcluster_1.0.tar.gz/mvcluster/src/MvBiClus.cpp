/*
 * MvBiClus.cpp
 *
 *  Created on: Aug 20, 2015
 *      Author: Javon
 */

#include "MvBiClus.h"
//#include <boost/foreach.hpp>

MvBiClus::MvBiClus(const vector<mat> & datasets)
: MvClus(datasets) {

}

MvBiClus::~MvBiClus() {
	// TODO Auto-generated destructor stubs
}

