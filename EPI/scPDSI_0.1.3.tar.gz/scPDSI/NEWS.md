# scPDSI 0.1.3

* Main function `pdsi()` now can output Palmer hydrological drought index (PHDI) and weighted PDSI (WPLM).

# scPDSI 0.1.2

* Fix the compiling error in solaris platform.

# scPDSI 0.1.1

* Added a function `plot.pdsi` to plot the calculated PDSI time series, can be called directly using `plot()`.
