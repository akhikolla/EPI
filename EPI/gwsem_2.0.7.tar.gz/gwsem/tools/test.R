library(devtools)
devtools::test()
