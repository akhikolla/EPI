library(testthat)
library(gwsem)

test_check("gwsem")
