# News for tvR
### Changes in version 0.3.1
  * added a `NEWS.md` file to track changes to the package.
  * `vignette` is added.
  * input matrix contamination is fixed (thanks to Yang Li).
