// [[Rcpp::export]]
Rcpp::List __FUNCNAME___get_params()
{
  Rcpp::List out;
  __BODY__;
  return out;
}

