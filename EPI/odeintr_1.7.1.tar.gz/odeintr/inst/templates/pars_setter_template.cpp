// [[Rcpp::export]]
void __FUNCNAME___set_params(__PARS__)
{ 
  __BODY__;
}

