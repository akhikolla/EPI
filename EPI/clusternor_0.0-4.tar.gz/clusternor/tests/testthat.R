library(testthat)
library(clusternor)

test_check("clusternor")
