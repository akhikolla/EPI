library(testthat)
library(chillR)

test_check("chillR")
