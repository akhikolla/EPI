library(testthat)
library(prospectr)

test_check("prospectr")
