library(testthat)
library(Rpvt)

test_check("Rpvt")

