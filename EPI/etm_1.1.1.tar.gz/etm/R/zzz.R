#####################################################################
### Some stuffs that have to be somewhere
### Arthur Allignol <arthur.allignol@uni-ulm.de>
#####################################################################

utils::globalVariables(c("entry",
                         "exit",
                         "from",
                         "to",
                         "id",
                         "idd",
                         "masque",
                         "entree",
                         "Haz",
                         "time",
                         "V1",
                         "dhaz"),
                       package = "etm")
                       
                       
