library(testthat)
library(iccbeta)

test_check("iccbeta")
