library(testthat)
library(elfDistr)

test_check("elfDistr")
