
.onUnload <- function (libpath) {
  library.dynam.unload("elfDistr", libpath)
}
