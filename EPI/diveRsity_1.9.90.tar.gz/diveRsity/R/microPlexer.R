# try to include microPlexer app
#' @export
microPlexer <- function(){
  runApp(system.file('microPlexer', package = 'diveRsity'))
}
################################################################################
# END
################################################################################