#' @useDynLib mlmc
#' @importFrom Rcpp sourceCpp

NULL
