library(testthat)
library(SeqNet)

test_check("SeqNet")
