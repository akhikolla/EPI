library(testthat)
library(s2net)

test_check("s2net")
