library(testthat)
library(ccdrAlgorithm)

test_check("ccdrAlgorithm")
