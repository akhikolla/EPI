library(testthat)
library(santoku)

test_check("santoku")
