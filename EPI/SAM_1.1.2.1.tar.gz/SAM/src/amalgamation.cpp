// objective
#include "objective/GLMObjective.cpp"
#include "objective/LinearObjective.cpp"

// solver
#include "solver/actnewton.cpp"
#include "solver/solver_params.cpp"
