overlap <- function(object){
  UseMethod("overlap")
}

overlap.meltt <- function(object){
  object


}