library(ldat)
library(testthat)

test_check("ldat")

