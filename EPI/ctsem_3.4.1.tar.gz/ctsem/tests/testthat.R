library(testthat)
library(ctsem)
pdf(NULL)
 test_check("ctsem")
