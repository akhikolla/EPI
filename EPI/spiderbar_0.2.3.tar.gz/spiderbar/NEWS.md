0.2.3
* fix by Peter Meissner for fetching case
* custom print method now returns the object
* fixed spelling
* ensured there's a roxygen return for every function

0.2.0
* Added crawl delay extraction
* Made all examples local so CRAN doesn't have to hit actual websites

0.1.0 
* Initial release
