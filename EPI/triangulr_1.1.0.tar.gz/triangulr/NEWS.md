# `triangulr` 1.1.0

- Updated `rtri` to use less memory.
- Added optional argument `dqrng` for `rtri` to use the `dqrunif` generator.

# `triangulr` 1.0.0

- Expected shortfall function `estri` was added.
- Moment generating function `mgtri` and characteristic function `ctri` were added.
- Bug Fixes for existing standard functions.

# `triangulr` 0.2.0

- Changed `dtriang`, `ptriang`, `qtriang`, and `rtriang` to `dtri`, `ptri`, `qtri`, and `rtri` respectively.

# `triangulr` 0.1.0

- Standard functions were reimplemented in C++.
