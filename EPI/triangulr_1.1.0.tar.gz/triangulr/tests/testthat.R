library(testthat)
library(triangulr)

test_check("triangulr")
