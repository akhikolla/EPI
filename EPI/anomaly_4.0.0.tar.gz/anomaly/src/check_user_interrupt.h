
#ifndef ___CHECK_USER_INTERRUPT_H___
#define ___CHECK_USER_INTERRUPT_H___

bool check_user_interrupt();

#endif
