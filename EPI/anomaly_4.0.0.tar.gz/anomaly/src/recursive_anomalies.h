#ifndef ___RECURSIVE_ANOMALIES_H___
#define ___RECURSIVE_ANOMALIES_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> recursive_anomalies(SEXP, SEXP, SEXP);

#endif
