#ifndef ___RECURSIVE_MVANOMALIES_H___
#define ___RECURSIVE_MVANOMALIES_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> recursive_mvanomalies(SEXP, SEXP, SEXP,SEXP, SEXP, SEXP,SEXP);

#endif
