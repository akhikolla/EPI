
#ifndef ___MEANANOMALYMV_H___
#define ___MEANANOMALYMV_H___

#include <R.h>
#include <Rinternals.h>
#include <vector>

std::vector<int> MeanAnomalyMV(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);


#endif
