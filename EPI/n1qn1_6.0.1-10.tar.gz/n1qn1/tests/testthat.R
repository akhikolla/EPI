library(testthat)
library(n1qn1)

test_check("n1qn1")
