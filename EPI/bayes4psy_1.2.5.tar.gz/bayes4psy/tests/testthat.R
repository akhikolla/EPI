library(testthat)
library(bayes4psy)

test_check("bayes4psy")
