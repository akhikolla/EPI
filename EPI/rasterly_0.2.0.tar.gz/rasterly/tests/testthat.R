library(testthat)
library(rasterly)

test_check("rasterly")
