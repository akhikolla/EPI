#' @importFrom magrittr '%>%'
#' @export
magrittr::'%>%'

#' @importFrom ggplot2 aes
#' @export
ggplot2::aes
