#' @keywords internal
#' @aliases rasterly-package
"_PACKAGE"

NULL

