library(testthat)
library(hermiter)

test_check("hermiter")
