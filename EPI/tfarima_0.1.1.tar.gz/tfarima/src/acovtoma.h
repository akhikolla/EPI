#ifndef __ARIMA_ACOVTOMA__
#define __ARIMA_ACOVTOMA__

arma::colvec acovtomaC(const arma::colvec &g);

#endif //__ARIMA_ACOVTOMA__
