library(testthat)
library(hopit)

test_check("hopit")
